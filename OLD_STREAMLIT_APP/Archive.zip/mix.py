import streamlit as st
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO

# Fake data
x = np.linspace(0, 10, 200)
y = np.sin(x)

# --- 1. INTERACTIVE PLOTLY PLOT ---
fig_plotly = go.Figure()
fig_plotly.add_trace(go.Scatter(x=x, y=y, mode="lines", name="sin(x)"))
fig_plotly.update_layout(title="Interactive Plot", xaxis_title="X", yaxis_title="Y")
st.plotly_chart(fig_plotly)

# --- 2. HIGH-QUALITY MATPLOTLIB EXPORT ---
def generate_matplotlib_figure():
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(x, y, label="sin(x)", color="black")
    ax.set_title("High-Quality Plot")
    ax.set_xlabel("X axis")
    ax.set_ylabel("Y axis")
    ax.legend()
    return fig

# --- 3. BUTTON TO DOWNLOAD CLEAN SVG ---
fig_export = generate_matplotlib_figure()
buf = BytesIO()
fig_export.savefig(buf, format="svg", bbox_inches="tight")
st.download_button(
    label="📤 Export as SVG",
    data=buf.getvalue(),
    file_name="plot.svg",
    mime="image/svg+xml"
)
