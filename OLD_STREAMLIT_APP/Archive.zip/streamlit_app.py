# streamlit_app.py
import os
import sys
import tempfile
import base64
from io import BytesIO
import uuid

import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots
from scipy.interpolate import make_interp_spline
from scipy.signal import find_peaks
import pandas as pd

from data_readers.chromatogram_reader import ChromatogramReader

# --- Page setup ---
st.set_page_config(page_title="🦎 GeckoPlotter", layout="wide")

# --- Color mapping helper ---
def convert_color_to_hex(color):
    """Convert any color format to valid hex color for Streamlit"""
    if isinstance(color, str) and color.startswith('#'):
        return color  # Already a hex color
    
    if isinstance(color, str) and color.startswith('rgb'):
        # Extract RGB values from string like 'rgb(246, 207, 113)'
        try:
            rgb = color.strip('rgb(').strip(')').split(',')
            r, g, b = [int(c.strip()) for c in rgb]
            return f"#{r:02x}{g:02x}{b:02x}"
        except:
            return "#000000"  # Default to black if parsing fails
    
    # Handle tuple/list color formats
    if isinstance(color, (list, tuple)) and len(color) >= 3:
        r, g, b = int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)
        return f"#{r:02x}{g:02x}{b:02x}"
    
    # Default fallback
    return "#000000"

# --- Session state defaults ---
state = st.session_state
state.setdefault('datasets', [])
state.setdefault('dataset_colors', [])
state.setdefault('integral_colors', px.colors.qualitative.Plotly)
state.setdefault('peaks', [])
state.setdefault('annotations', [])
state.setdefault('smooth_lines', False)
state.setdefault('integrate_to_zero', False)
state.setdefault('last_palette', 'Plotly')
state.setdefault('plot_width', 1200)
state.setdefault('plot_height', 700)
state.setdefault('plot_dpi', 300)
state.setdefault('peak_ids', {})  # Store unique IDs for each peak
state.setdefault('annotation_ids', {})  # Store unique IDs for each annotation
state.setdefault('plot_counter', 0)  # Counter to force plot refresh

# Initialize plot config if needed
if 'plot_config' not in state or not state.plot_config:
    state.plot_config = {
        'title': 'Chromatogram',
        'xaxis_title': 'Time (min)',
        'yaxis_title': 'Value (mAU)',
        'legend_position': {'x': 1.02, 'y': 1}
    }

# Initialize font settings
if 'font_settings' not in state or not state.font_settings:
    state.font_settings = {
        'title_fs': 18,
        'axis_fs': 14,
        'legend_fs': 14,
        'tick_fs': 12,
        'wavelength_fs': 12
    }

# --- Put the title in the sidebar at the top ---
with st.sidebar:
    st.markdown("# 🦎 GeckoPlotter")
    st.header("Controls")
    
    # Data Upload
    with st.expander("Data Upload", expanded=True):
        uploads = st.file_uploader(
            "Upload .txt (chromatogram) or .csv (spectrum)",
            type=['txt','csv'], accept_multiple_files=True
        )
        def load_file(f):
            ext = os.path.splitext(f.name)[1].lower()
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
            tmp.write(f.getbuffer()); tmp.close()

            if ext == '.txt':
                reader = ChromatogramReader()
                if reader.read_file(tmp.name):
                    df = reader.get_data()
                    label = os.path.splitext(f.name)[0]
                    pal = getattr(px.colors.qualitative, state.last_palette)
                    color = pal[len(state.datasets) % len(pal)]
                    # Convert to hex for dataset_colors
                    hex_color = convert_color_to_hex(color)
                    state.dataset_colors.append(hex_color)
                    state.datasets.append({
                        'data_type': 'chromatogram',
                        'chromatogram_data': df,
                        'file_path': f.name,
                        'file_name': label,
                        'wavelength': reader.get_wavelength(),
                        'is_visible': True,
                        'label': label,
                        'color': hex_color
                    })
                    
                    # After loading the first dataset, calculate and set the Y-axis to 110% of max
                    if len(state.datasets) == 1:
                        y_values = df["Value (mAU)"].values
                        y_min = float(y_values.min())
                        y_max = float(y_values.max() * 1.1)  # 110% of max value
                        
                        # Initialize the ranges if not yet set
                        if 'y_min_manual' not in state:
                            state.y_min_manual = y_min
                        if 'y_max_manual' not in state:
                            state.y_max_manual = y_max
                    
                    st.success(f"Loaded {f.name}")
            else:
                st.info(f"CSV support coming soon: {f.name}")

            os.unlink(tmp.name)

        if uploads:
            for u in uploads:
                if not any(d['file_path'] == u.name for d in state.datasets):
                    load_file(u)
                    
        # Dataset Management
        if state.datasets:
            for i, d in enumerate(state.datasets):
                # First row: visibility, color, label
                col_vis, col_color, col_lbl = st.columns([0.1, 0.2, 0.7])
                
                # Visibility checkbox
                d['is_visible'] = col_vis.checkbox("", d['is_visible'], key=f"vis_{i}")
                
                # Color picker - ensure color is in hex format
                saved_color = d.get('color', state.dataset_colors[i])
                hex_color = convert_color_to_hex(saved_color)
                new_color = col_color.color_picker("", hex_color, key=f"col_{i}")
                
                if new_color != hex_color:
                    state.dataset_colors[i] = new_color
                    d['color'] = new_color
                
                # Label
                d['label'] = col_lbl.text_input("Label", d['label'], key=f"lab_{i}")
                
                # Second row: up/down buttons
                up_btn, down_btn = st.columns(2)
                if up_btn.button("↑", key=f"up_{i}") and i > 0:
                    state.datasets[i-1], state.datasets[i] = state.datasets[i], state.datasets[i-1]
                    state.dataset_colors[i-1], state.dataset_colors[i] = state.dataset_colors[i], state.dataset_colors[i-1]
                    st.rerun()
                
                if down_btn.button("↓", key=f"down_{i}") and i < len(state.datasets) - 1:
                    state.datasets[i+1], state.datasets[i] = state.datasets[i], state.datasets[i+1]
                    state.dataset_colors[i+1], state.dataset_colors[i] = state.dataset_colors[i], state.dataset_colors[i+1]
                    st.rerun()
                
                st.markdown("---")
        else:
            st.info("Upload data files to begin.")


    # General Plot Settings
    with st.expander("General Settings", expanded=True):
        # Color Palette Selector
        palette_names = [
            'Plotly', 'D3', 'G10', 'T10',
            'Alphabet', 'Dark24', 'Light24', 'Pastel'
        ]
        selected = st.selectbox(
            "Color Palette", palette_names,
            index=palette_names.index(state.last_palette),
            key="palette_selector"
        )
        if selected != state.last_palette:
            try:
                pal = getattr(px.colors.qualitative, selected)
                for i in range(len(state.dataset_colors)):
                    # Convert to hex to avoid color format issues
                    hex_color = convert_color_to_hex(pal[i % len(pal)])
                    state.dataset_colors[i] = hex_color
                    if i < len(state.datasets):
                        state.datasets[i]['color'] = hex_color
                state.last_palette = selected
            except Exception as e:
                st.error(f"Error changing color palette: {e}")
            
        # Line thickness
        line_width = st.slider("Line Thickness", 0.1, 5.0, 1.5, key="line_width_slider")
        
        # Display Options
        col1, col2 = st.columns(2)
        
        with col1:
            # Plot options
            separate = st.checkbox("Separate Plots", False, key="separate_plots_cb")
            smooth = st.checkbox("Smooth Lines", state.smooth_lines, key="smooth_lines_cb")
            if smooth != state.smooth_lines:
                state.smooth_lines = smooth
        
        with col2:
            # Integration and display
            integrate_zero = st.checkbox(
                "Integrate to Zero (Baseline)",
                state.integrate_to_zero,
                key="integrate_zero_cb"
            )
            state.integrate_to_zero = integrate_zero
            
            show_wavelength = st.checkbox("Show Wavelength Box", True, key="show_wavelength_cb")
        
        # Grid and Legend options
        col1, col2 = st.columns(2)
        with col1:
            show_legend = st.checkbox("Show Legend", True, key="show_legend_cb")
            show_hgrid = st.checkbox("Horizontal Grid", False, key="show_hgrid_cb")
        
        with col2:
            show_vgrid = st.checkbox("Vertical Grid", False, key="show_vgrid_cb")


    # Plot Size & Dimensions
    with st.expander("Plot Dimensions", expanded=False):
        # Plot size
        col1, col2 = st.columns(2)
        with col1:
            plot_width = st.number_input("Width (px)", 
                                        min_value=600, 
                                        max_value=3000, 
                                        value=state.plot_width,
                                        key="plot_width_input")
            state.plot_width = plot_width
            
        with col2:
            plot_height = st.number_input("Height (px)", 
                                         min_value=400, 
                                         max_value=2000, 
                                         value=state.plot_height,
                                         key="plot_height_input")
            state.plot_height = plot_height
            
        # Export DPI
        plot_dpi = st.slider("Export DPI", 
                             min_value=72, 
                             max_value=600, 
                             value=state.plot_dpi,
                             key="plot_dpi_slider")
        state.plot_dpi = plot_dpi


    # Fonts & Labels
    with st.expander("Fonts & Labels", expanded=False):
        # Font sizes - using values from session state
        col1, col2 = st.columns(2)
        with col1:
            # Use state's values, or the defaults if not present
            title_fs = st.number_input("Title Font", 8, 30, 
                                    value=state.font_settings.get('title_fs', 18),
                                    key="title_fs_input")
            state.font_settings['title_fs'] = title_fs
            
            axis_fs = st.number_input("Axis Font", 6, 24, 
                                  value=state.font_settings.get('axis_fs', 14),
                                  key="axis_fs_input")
            state.font_settings['axis_fs'] = axis_fs
        
        with col2:
            legend_fs = st.number_input("Legend Font", 6, 24, 
                                     value=state.font_settings.get('legend_fs', 14),
                                     key="legend_fs_input")
            state.font_settings['legend_fs'] = legend_fs
            
            tick_fs = st.number_input("Tick Font", 6, 24, 
                                   value=state.font_settings.get('tick_fs', 12),
                                   key="tick_fs_input")
            state.font_settings['tick_fs'] = tick_fs
            
        # Wavelength Box font 
        wavelength_fs = st.number_input("Wavelength Font", 6, 24, 
                                     value=state.font_settings.get('wavelength_fs', 12),
                                     key="wavelength_fs_input")
        state.font_settings['wavelength_fs'] = wavelength_fs
        
        # Plot Labels
        title = st.text_input("Plot Title", state.plot_config.get('title', 'Chromatogram'), key="plot_title_input")
        if title != state.plot_config.get('title', ''):
            state.plot_config['title'] = title
        
        col1, col2 = st.columns(2)
        with col1:
            x_label = st.text_input("X-Axis", state.plot_config.get('xaxis_title', 'Time (min)'), key="x_label_input")
            if x_label != state.plot_config.get('xaxis_title', ''):
                state.plot_config['xaxis_title'] = x_label
        with col2:
            y_label = st.text_input("Y-Axis", state.plot_config.get('yaxis_title', 'Value (mAU)'), key="y_label_input") 
            if y_label != state.plot_config.get('yaxis_title', ''):
                state.plot_config['yaxis_title'] = y_label


    # Axis Range Settings
    with st.expander("Axis Ranges", expanded=False):
        # Compute data extents
        if state.datasets:
            all_x = np.hstack([
                d['chromatogram_data']['Time (min)'].values
                for d in state.datasets
                if d['data_type']=='chromatogram'
            ])
            all_y = np.hstack([
                d['chromatogram_data']['Value (mAU)'].values
                for d in state.datasets
                if d['data_type']=='chromatogram'
            ])
            xmin, xmax = float(all_x.min()), float(all_x.max())
            ymin, ymax = float(all_y.min()), float(all_y.max() * 1.1)  # 110% of maximum value
        else:
            xmin, xmax, ymin, ymax = 0.0, 10.0, 0.0, 100.0

        # Setup the session state for sliders if not yet initialized
        if 'x_min_manual' not in state:
            state.x_min_manual = xmin
        if 'x_max_manual' not in state:
            state.x_max_manual = xmax
        if 'y_min_manual' not in state:
            state.y_min_manual = ymin
        if 'y_max_manual' not in state:
            state.y_max_manual = ymax  # This will be 110% of max when data is loaded
        
        # Reset button
        if st.button("Reset Axes", key="reset_axes_btn"):
            if state.datasets:
                # Recalculate y_max to be 110% of the maximum
                all_y = np.hstack([
                    d['chromatogram_data']['Value (mAU)'].values
                    for d in state.datasets
                    if d['data_type']=='chromatogram'
                ])
                state.y_max_manual = float(all_y.max() * 1.1)  # 110% of max
                state.y_min_manual = float(all_y.min())
                
                # Reset x range to data extents
                all_x = np.hstack([
                    d['chromatogram_data']['Time (min)'].values
                    for d in state.datasets
                    if d['data_type']=='chromatogram'
                ])
                state.x_min_manual = float(all_x.min())
                state.x_max_manual = float(all_x.max())
            else:
                state.x_min_manual = 0.0
                state.x_max_manual = 10.0
                state.y_min_manual = 0.0
                state.y_max_manual = 100.0
            st.rerun()
            
        # X-axis range
        x_min = state.x_min_manual
        x_max = state.x_max_manual
        
        # X-range slider
        x_range = st.slider(
            "X-Range", 
            xmin, xmax, 
            (x_min, x_max), 
            key="x_range_slider",
            on_change=lambda: setattr(state, 'slider_changed', True)
        )
        
        # Manual input fields for X
        col1, col2 = st.columns(2)
        x_min_input = col1.number_input(
            "X Min", 
            value=x_min, 
            format="%.3f", 
            key="x_min_input"
        )
        x_max_input = col2.number_input(
            "X Max", 
            value=x_max, 
            format="%.3f", 
            key="x_max_input"
        )
        
        # Update state when manual entries change
        if x_min_input != state.x_min_manual:
            state.x_min_manual = x_min_input
        if x_max_input != state.x_max_manual:
            state.x_max_manual = x_max_input
        
        # Update from slider if it changed
        if state.get('slider_changed', False):
            state.x_min_manual = x_range[0]
            state.x_max_manual = x_range[1]
            state.slider_changed = False
            
        # Y-axis range
        y_min = state.y_min_manual
        y_max = state.y_max_manual
        
        # Y-range slider
        y_range = st.slider(
            "Y-Range", 
            ymin, ymax, 
            (y_min, y_max), 
            key="y_range_slider",
            on_change=lambda: setattr(state, 'y_slider_changed', True)
        )
        
        # Manual input fields for Y
        col1, col2 = st.columns(2)
        y_min_input = col1.number_input(
            "Y Min", 
            value=y_min, 
            format="%.3f", 
            key="y_min_input"
        )
        y_max_input = col2.number_input(
            "Y Max", 
            value=y_max, 
            format="%.3f", 
            key="y_max_input"
        )
        
        # Update state when manual entries change
        if y_min_input != state.y_min_manual:
            state.y_min_manual = y_min_input
        if y_max_input != state.y_max_manual:
            state.y_max_manual = y_max_input
        
        # Update from slider if it changed
        if state.get('y_slider_changed', False):
            state.y_min_manual = y_range[0]
            state.y_max_manual = y_range[1]
            state.y_slider_changed = False
            
        # Add shared Y axis option for separate plots
        if separate:
            shared_y = st.checkbox("Shared Y-Axis Scale", 
                                 state.get('shared_y_scale', False),
                                 help="Use the same Y-axis scale for all plots",
                                 key="shared_y_scale_cb")
            state.shared_y_scale = shared_y


    # Peak Analysis Settings
    with st.expander("Peak Analysis", expanded=False):
        # Auto peak detection
        if state.datasets:
            col1, col2 = st.columns(2)
            with col1:
                peak_threshold = st.slider("Detection Threshold", 0.0, 1.0, 0.1, key="peak_threshold_slider")
                
            with col2:
                peak_dataset_options = [d['label'] for d in state.datasets if d['is_visible']]
                peak_dataset = st.selectbox(
                    "Dataset",
                    options=peak_dataset_options,
                    index=0 if peak_dataset_options else 0,
                    key="peak_dataset_select"
                )
            
            if st.button("Auto-Detect Peaks", key="auto_detect_btn"):
                # Get the selected dataset
                dataset_idx = next((i for i, d in enumerate(state.datasets) 
                                  if d['is_visible'] and d['label'] == peak_dataset), None)
                
                if dataset_idx is not None:
                    df = state.datasets[dataset_idx]['chromatogram_data']
                    x = df["Time (min)"].values
                    y = df["Value (mAU)"].values
                    
                    # Normalize signal for threshold calculation
                    y_norm = (y - y.min()) / (y.max() - y.min()) if y.max() > y.min() else y
                    
                    # Find peaks using scipy
                    peak_indices, _ = find_peaks(y_norm, height=peak_threshold, distance=len(y)//50)
                    
                    # Clear existing peaks
                    state.peaks = []
                    state.peak_ids = {}
                    
                    # Add detected peaks
                    for i, idx in enumerate(peak_indices):
                        # Find boundaries (simple approach - go down both sides until slope changes)
                        left_idx = idx
                        while left_idx > 0 and y_norm[left_idx-1] < y_norm[left_idx]:
                            left_idx -= 1
                        
                        right_idx = idx
                        while right_idx < len(y_norm)-1 and y_norm[right_idx+1] < y_norm[right_idx]:
                            right_idx += 1
                        
                        # Expand a bit more for integration
                        left_idx = max(0, left_idx - 5)
                        right_idx = min(len(y_norm)-1, right_idx + 5)
                        
                        # Create peak
                        peak_id = str(uuid.uuid4())
                        color = convert_color_to_hex(state.integral_colors[i % len(state.integral_colors)])
                        state.peaks.append({
                            'start': float(x[left_idx]),
                            'end': float(x[right_idx]),
                            'color': color,
                            'id': peak_id
                        })
                        state.peak_ids[peak_id] = f"peak_{i+1}"
                    
                    st.success(f"Detected {len(peak_indices)} peaks")
        else:
            st.info("Upload data first")
        
        # Manual peak definition
        # Button to add a peak manually
        if st.button("Add Peak Manually", key="add_peak_btn") and state.datasets:
            peak_id = str(uuid.uuid4())
            default_color = convert_color_to_hex(state.integral_colors[len(state.peaks) % len(state.integral_colors)])
            state.peaks.append({
                'start': state.x_min_manual,
                'end': state.x_max_manual,
                'color': default_color,
                'id': peak_id
            })
            state.peak_ids[peak_id] = f"peak_{len(state.peaks)}"
            st.rerun()
        
        # Show and allow editing of existing peaks
        if state.peaks:
            for i, pk in enumerate(state.peaks):
                peak_id = pk.get('id', str(uuid.uuid4()))
                if peak_id not in state.peak_ids:
                    state.peak_ids[peak_id] = f"peak_{i+1}"
                    pk['id'] = peak_id
                
                st.markdown(f"**{state.peak_ids[peak_id]}**")
                p1, p2 = st.columns(2)
                
                # Generate unique keys using the peak ID
                pk['start'] = p1.number_input(
                    "Min Time", 
                    value=pk['start'], 
                    format="%.3f", 
                    key=f"pk_min_{peak_id}"
                )
                
                pk['end'] = p2.number_input(
                    "Max Time", 
                    value=pk['end'], 
                    format="%.3f", 
                    key=f"pk_max_{peak_id}"
                )
                
                p3, p4 = st.columns(2)
                # Ensure color is in hex format
                hex_color = convert_color_to_hex(pk['color'])
                pk['color'] = p3.color_picker(
                    "Color", 
                    value=hex_color, 
                    key=f"pk_col_{peak_id}"
                )
                
                if p4.button("Remove", key=f"rm_pk_{peak_id}"):
                    state.peaks.remove(pk)
                    state.peak_ids.pop(peak_id, None)
                    st.rerun()
                
                st.markdown("---")


    # Annotations
    with st.expander("Annotations", expanded=False):
        # Add annotation button
        if st.button("Add Annotation", key="add_annotation_btn") and state.datasets:
            annotation_id = str(uuid.uuid4())
            x_mid = (state.x_min_manual + state.x_max_manual) / 2
            y_mid = (state.y_min_manual + state.y_max_manual) / 2
            
            state.annotations.append({
                'type': 'Text',
                'target': 'All',
                'x': x_mid,
                'y': y_mid,
                'text': 'New Annotation',
                'color': '#000000',
                'id': annotation_id
            })
            
            state.annotation_ids[annotation_id] = f"annotation_{len(state.annotations)}"
            st.rerun()
        
        # Show existing annotations
        if state.annotations:
            for i, an in enumerate(state.annotations):
                # Generate a unique ID for this annotation if it doesn't have one
                an_id = an.get('id', str(uuid.uuid4()))
                if an_id not in state.annotation_ids:
                    state.annotation_ids[an_id] = f"annotation_{i+1}"
                    an['id'] = an_id
                
                st.markdown(f"**{state.annotation_ids[an_id]}**")
                t1, t2 = st.columns(2)
                
                # Type and target selection
                an['type'] = t1.selectbox(
                    "Type", ["Text", "Arrow", "Marker"],
                    index=["Text", "Arrow", "Marker"].index(an['type']),
                    key=f"an_t_{an_id}"
                )
                
                # Build list of targets (datasets or "All")
                dataset_options = ['All'] + [d['file_name'] for d in state.datasets]
                target_index = dataset_options.index(an['target']) if an['target'] in dataset_options else 0
                
                an['target'] = t2.selectbox(
                    "Target", 
                    dataset_options,
                    index=target_index, 
                    key=f"an_tar_{an_id}"
                )
                
                # Position inputs
                x1, x2 = st.columns(2)
                an['x'] = x1.number_input("X", value=an['x'], key=f"an_x_{an_id}")
                an['y'] = x2.number_input("Y", value=an['y'], key=f"an_y_{an_id}")
                
                # Text and color
                t3, t4 = st.columns(2)
                an['text'] = t3.text_input("Text", value=an['text'], key=f"an_txt_{an_id}")
                # Convert color to hex if needed
                hex_color = convert_color_to_hex(an['color'])
                an['color'] = t4.color_picker("Color", value=hex_color, key=f"an_col_{an_id}")
                
                # Remove button
                if st.button("Remove", key=f"rm_an_{an_id}"):
                    state.annotations.remove(an)
                    state.annotation_ids.pop(an_id, None)
                    st.rerun()
                
                st.markdown("---")
        else:
            st.info("No annotations yet.")


    # Export Options
    with st.expander("Export Options", expanded=False):
        export_format = st.selectbox(
            "File Format", 
            ["PNG", "SVG", "PDF", "HTML", "CSV"],
            index=0,
            key="export_format_select"
        )
        
        col1, col2 = st.columns(2)
        with col1:
            img_width = st.number_input("Width (px)", 
                                       min_value=600, 
                                       max_value=4000, 
                                       value=state.plot_width,
                                       key="img_width_input")
            
            img_height = st.number_input("Height (px)", 
                                        min_value=400, 
                                        max_value=3000, 
                                        value=state.plot_height,
                                        key="img_height_input")
        
        with col2:
            img_dpi = st.number_input("DPI", 
                                     min_value=72, 
                                     max_value=600, 
                                     value=state.plot_dpi,
                                     key="img_dpi_input")
                                     
            csv_delimiter = st.selectbox("CSV Delimiter", [",", ";", "Tab"], index=0, key="csv_delim_select")
        
        def get_table_download_link(df, filename="data.csv", delimiter=","):
            """Generates a link to download the DataFrame as a CSV file"""
            csv = df.to_csv(index=False, sep=delimiter)
            b64 = base64.b64encode(csv.encode()).decode()
            href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">Download CSV File</a>'
            return href
        
        if st.button("Export", key="export_btn") and state.datasets:
            if export_format == "CSV":
                # Create DataFrame from visible datasets
                visible_dfs = []
                for i, d in enumerate(state.datasets):
                    if d['is_visible']:
                        df = d['chromatogram_data'].copy()
                        df['Dataset'] = d['label']
                        visible_dfs.append(df)
                
                if visible_dfs:
                    combined_df = pd.concat(visible_dfs)
                    delim_map = {",": ",", ";": ";", "Tab": "\t"}
                    st.success("CSV export ready!")
                    st.markdown(
                        get_table_download_link(
                            combined_df, 
                            "GeckoPlotter_export.csv",
                            delim_map[csv_delimiter]
                        ), 
                        unsafe_allow_html=True
                    )
            else:
                st.info(f"To export as {export_format}, use the plot toolbar.")


    # Data Management
    with st.expander("Data Management", expanded=False):
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Clear All Data", key="clear_all_btn"):
                state.datasets.clear()
                state.dataset_colors.clear()
                state.peaks.clear()
                state.peak_ids.clear()
                state.annotations.clear()
                state.annotation_ids.clear()
                st.rerun()
        
        with col2:
            if st.button("Clear Selected", key="clear_selected_btn"):
                # Remove only visible datasets
                to_keep = []
                to_keep_colors = []
                for i, d in enumerate(state.datasets):
                    if not d['is_visible']:
                        to_keep.append(d)
                        to_keep_colors.append(state.dataset_colors[i])
                
                state.datasets = to_keep
                state.dataset_colors = to_keep_colors
                st.rerun()

# Main content area
# Identify values to use - get from state or font settings
x_min = state.x_min_manual
x_max = state.x_max_manual
y_min = state.y_min_manual
y_max = state.y_max_manual
title = state.plot_config.get('title', 'Chromatogram')
x_label = state.plot_config.get('xaxis_title', 'Time (min)')
y_label = state.plot_config.get('yaxis_title', 'Value (mAU)')

# Get font sizes from state.font_settings
title_fs = state.font_settings.get('title_fs', 18)  # Default to larger font if not set
axis_fs = state.font_settings.get('axis_fs', 14)
legend_fs = state.font_settings.get('legend_fs', 14)
tick_fs = state.font_settings.get('tick_fs', 12)
wavelength_fs = state.font_settings.get('wavelength_fs', 12)

# Get datasets to plot
dfiles = [
    (i, d) for i, d in enumerate(state.datasets)
    if d['is_visible'] and d['data_type']=='chromatogram'
]

def apply_layout(fig):
    # Apply configuration
    fig.update_layout(
        showlegend=show_legend,
        legend=dict(
            font=dict(size=legend_fs),
            # Make legend draggable by default
            xanchor='auto',
            yanchor='auto',
            itemclick='toggle',
            itemdoubleclick='toggleothers',
            # Initial position - user can drag elsewhere
            x=state.plot_config.get('legend_position', {'x': 1.02, 'y': 1}).get('x', 1.02),
            y=state.plot_config.get('legend_position', {'x': 1.02, 'y': 1}).get('y', 1)
        ),
        title=dict(text=title, font=dict(size=title_fs)),
        margin=dict(t=60, b=40, l=60, r=120),
        width=state.plot_width,
        height=state.plot_height,
        dragmode='zoom'  # Default to zoom instead of pan
    )
    
    fig.update_xaxes(
        title_text=x_label,
        title_font=dict(size=axis_fs),
        tickfont=dict(size=tick_fs),
        range=[x_min, x_max],
        showgrid=show_hgrid
    )
    
    fig.update_yaxes(
        title_text=y_label,
        title_font=dict(size=axis_fs),
        tickfont=dict(size=tick_fs),
        range=[y_min, y_max],
        showgrid=show_vgrid
    )
    
    if show_wavelength:
        wl_set = []
        for _, d in dfiles:
            w = d.get('wavelength')
            if w:
                text = f"{w} nm" if not str(w).endswith("nm") else w
                if text not in wl_set:
                    wl_set.append(text)
        if wl_set:
            fig.add_annotation(
                x=0, y=1.05, xref='paper', yref='paper',
                text="<br>".join(wl_set),
                showarrow=False, align='left',
                font=dict(size=wavelength_fs),
                bgcolor='white', opacity=0.7
            )
    
    return fig

def create_plotly_combined():
    fig = go.Figure()
    for idx, ds in dfiles:
        df = ds['chromatogram_data']
        x, y = df["Time (min)"].values, df["Value (mAU)"].values
        if state.smooth_lines:
            try:
                xs = np.linspace(x.min(), x.max(), len(x)*3)
                ys = make_interp_spline(x, y, k=3)(xs)
                pxs, pys = xs, ys
            except:
                pxs, pys = x, y
        else:
            pxs, pys = x, y

        # Use the hex color from dataset or state
        line_color = ds.get('color', state.dataset_colors[idx])
        
        fig.add_trace(go.Scatter(
            x=pxs, y=pys, mode="lines",
            name=ds['label'],
            line=dict(color=line_color, width=line_width),
            showlegend=show_legend
        ))

    # peak shading & area
    for p in state.peaks:
        mn, mx, c = p['start'], p['end'], p['color']
        fig.add_vrect(
            x0=mn, x1=mx, 
            fillcolor=c, 
            opacity=0.3, 
            line_width=0,
            layer='below'
        )
        
        if dfiles:  # Check if there's any visible data
            d0 = state.datasets[dfiles[0][0]]['chromatogram_data']
            sel = d0[(d0["Time (min)"]>=mn)&(d0["Time (min)"]<=mx)]
            if len(sel) > 1:
                xs, ys = sel["Time (min)"].values, sel["Value (mAU)"].values
                area = (np.trapz(ys, xs)
                        if state.integrate_to_zero
                        else np.trapz(ys - np.linspace(ys[0], ys[-1], len(ys)), xs))
                fig.add_annotation(
                    x=(mn+mx)/2, y=ys.max()*1.05,
                    text=f"Area: {area:.2f}",
                    showarrow=False, 
                    font=dict(color=c, size=10)
                )

    # Add annotations
    for an in state.annotations:
        if an['target'] == 'All' or any(d['file_name'] == an['target'] for _, d in dfiles):
            if an['type'] == 'Text':
                fig.add_annotation(
                    x=an['x'], y=an['y'],
                    text=an['text'],
                    showarrow=False,
                    font=dict(color=an['color'], size=10)
                )
            elif an['type'] == 'Arrow':
                fig.add_annotation(
                    x=an['x'], y=an['y'],
                    text=an['text'],
                    showarrow=True,
                    arrowhead=2,
                    arrowcolor=an['color'],
                    font=dict(color=an['color'], size=10)
                )
            elif an['type'] == 'Marker':
                fig.add_scatter(
                    x=[an['x']], y=[an['y']],
                    mode='markers+text',
                    text=[an['text']],
                    textposition='top center',
                    marker=dict(color=an['color'], size=10),
                    showlegend=False
                )

    return apply_layout(fig)

def create_plotly_separate():
    n = len(dfiles)
    if n == 0:
        # Return empty figure if no data
        fig = go.Figure()
        return apply_layout(fig)
        
    shared_yaxes = state.get('shared_y_scale', False)
    fig = make_subplots(rows=n, cols=1, 
                        shared_xaxes=True, 
                        shared_yaxes=shared_yaxes,
                        vertical_spacing=0.05)
                        
    for r, (idx, ds) in enumerate(dfiles, start=1):
        df = ds['chromatogram_data']
        x, y = df["Time (min)"].values, df["Value (mAU)"].values
        if state.smooth_lines:
            try:
                xs = np.linspace(x.min(), x.max(), len(x)*3)
                ys = make_interp_spline(x, y, k=3)(xs)
                pxs, pys = xs, ys
            except:
                pxs, pys = x, y
        else:
            pxs, pys = x, y

        # Use the hex color from dataset or state
        line_color = ds.get('color', state.dataset_colors[idx])
            
        # Always show the legend for each trace in separate mode
        fig.add_trace(go.Scatter(
            x=pxs, y=pys, mode="lines",
            name=ds['label'],
            line=dict(color=line_color, width=line_width),
            showlegend=show_legend
        ), row=r, col=1)

        # Add annotations for this dataset
        for an in state.annotations:
            if an['target'] == 'All' or an['target'] == ds['file_name']:
                if an['type'] == 'Text':
                    fig.add_annotation(
                        x=an['x'], y=an['y'],
                        text=an['text'],
                        showarrow=False,
                        font=dict(color=an['color'], size=10),
                        row=r, col=1
                    )
                elif an['type'] == 'Arrow':
                    fig.add_annotation(
                        x=an['x'], y=an['y'],
                        text=an['text'],
                        showarrow=True,
                        arrowhead=2,
                        arrowcolor=an['color'],
                        font=dict(color=an['color'], size=10),
                        row=r, col=1
                    )
                elif an['type'] == 'Marker':
                    fig.add_scatter(
                        x=[an['x']], y=[an['y']],
                        mode='markers+text',
                        text=[an['text']],
                        textposition='top center',
                        marker=dict(color=an['color'], size=10),
                        showlegend=False,
                        row=r, col=1
                    )

        # Add peak shading for this dataset
        for p in state.peaks:
            mn, mx, c = p['start'], p['end'], p['color']
            fig.add_vrect(
                x0=mn, x1=mx, 
                fillcolor=c, opacity=0.3, 
                line_width=0,
                row=r, col=1,
                layer='below'
            )
            # Calculate area for each dataset
            sel = df[(df["Time (min)"]>=mn)&(df["Time (min)"]<=mx)]
            if len(sel) > 1:
                xs, ys = sel["Time (min)"].values, sel["Value (mAU)"].values
                area = (np.trapz(ys, xs)
                        if state.integrate_to_zero
                        else np.trapz(ys - np.linspace(ys[0], ys[-1], len(ys)), xs))
                fig.add_annotation(
                    x=(mn+mx)/2, y=ys.max()*1.05,
                    text=f"Area: {area:.2f}",
                    showarrow=False, 
                    font=dict(color=c, size=8),
                    row=r, col=1
                )

        fig.update_xaxes(showgrid=show_hgrid, row=r, col=1)
        fig.update_yaxes(showgrid=show_vgrid, row=r, col=1)
        
        # Add y-axis title to each subplot
        fig.update_yaxes(title_text=y_label, title_font=dict(size=axis_fs), row=r, col=1)
        
        # Only add x-axis title to bottom subplot
        if r == n:
            fig.update_xaxes(
                title_text=x_label, 
                title_font=dict(size=axis_fs),
                row=r, col=1
            )
    
    # Apply common settings and x/y ranges to all subplots
    for r in range(1, n+1):
        fig.update_xaxes(range=[x_min, x_max], row=r, col=1)
        fig.update_yaxes(range=[y_min, y_max], row=r, col=1)
    
    # Apply final layout settings
    return apply_layout(fig)

# Function to handle plot interactions and save them to state
def handle_plot_event(chart):
    """
    Store any changes from plot interaction to the state.
    This ensures interactive edits are saved.
    """
    if 'last_active_plotly' in st._state:
        plotly_data = st._state['last_active_plotly']
        if plotly_data and 'relayoutData' in plotly_data:
            relayout_data = plotly_data['relayoutData']
            if relayout_data:
                # Store legend position if changed via dragging
                if 'legend.x' in relayout_data and 'legend.y' in relayout_data:
                    state.plot_config['legend_position'] = {
                        'x': relayout_data['legend.x'],
                        'y': relayout_data['legend.y']
                    }
                
                # Store axis ranges if changed in the plot
                if 'xaxis.range[0]' in relayout_data and 'xaxis.range[1]' in relayout_data:
                    state.x_min_manual = float(relayout_data['xaxis.range[0]'])
                    state.x_max_manual = float(relayout_data['xaxis.range[1]'])
                    
                if 'yaxis.range[0]' in relayout_data and 'yaxis.range[1]' in relayout_data:
                    state.y_min_manual = float(relayout_data['yaxis.range[0]'])
                    state.y_max_manual = float(relayout_data['yaxis.range[1]'])

# Render plot
if not state.datasets:
    st.info("Upload chromatogram files to begin plotting.")
else:
    # Create plot figure
    fig = create_plotly_separate() if separate else create_plotly_combined()
    
    # Configure the plot with zoom as default mode instead of pan
    config = {
        'displayModeBar': True,
        'editable': True,  # Enable editing text elements
        'modeBarButtonsToAdd': ['drawline', 'drawopenpath', 'eraseshape'],
        'toImageButtonOptions': {
            'format': 'png',
            'filename': 'geckoplotter_export',
            'height': state.plot_height,
            'width': state.plot_width,
            'scale': state.plot_dpi / 72
        }
    }
    
    # Display the plot and capture the return value for event handling
    chart = st.plotly_chart(
        fig,
        use_container_width=True,
        config=config,
        key=f"plot_{state.plot_counter}"
    )
    
    # Handle any plot interactions (zooming, panning, etc.)
    handle_plot_event(chart)
    
    # Update counter for next time
    state.plot_counter += 1

# Data tables and analysis - use expanders to save space
col1, col2 = st.columns(2)
with col1:
    if state.datasets:
        with st.expander("Data Tables", expanded=False):
            for i, d in enumerate(state.datasets):
                if d['is_visible']:
                    st.markdown(f"**{d['label']}**")
                    st.dataframe(d['chromatogram_data'], height=200)

with col2:
    if state.peaks:
        with st.expander("Peak Analysis Results", expanded=False):
            peak_data = []
            for i, p in enumerate(state.peaks):
                # For each dataset, calculate the peak area
                for j, d in enumerate(state.datasets):
                    if d['is_visible'] and d['data_type'] == 'chromatogram':
                        df = d['chromatogram_data']
                        sel = df[(df["Time (min)"] >= p['start']) & (df["Time (min)"] <= p['end'])]
                        if len(sel) > 1:
                            xs, ys = sel["Time (min)"].values, sel["Value (mAU)"].values
                            area = (np.trapz(ys, xs)
                                    if state.integrate_to_zero
                                    else np.trapz(ys - np.linspace(ys[0], ys[-1], len(ys)), xs))
                            max_y = ys.max()
                            max_x = xs[np.argmax(ys)]
                            
                            peak_id = p.get('id', f"peak_{i+1}")
                            peak_label = state.peak_ids.get(peak_id, f"Peak {i+1}")
                            
                            peak_data.append({
                                "Peak": peak_label,
                                "Dataset": d['label'],
                                "Start (min)": p['start'],
                                "End (min)": p['end'],
                                "Max (min)": max_x,
                                "Max Value (mAU)": max_y,
                                "Area": area
                            })
            
            if peak_data:
                st.dataframe(pd.DataFrame(peak_data))
                
                # Export peak data option
                if st.button("Export Peak Data", key="export_peak_btn"):
                    peak_df = pd.DataFrame(peak_data)
                    csv = peak_df.to_csv(index=False)
                    b64 = base64.b64encode(csv.encode()).decode()
                    href = f'<a href="data:file/csv;base64,{b64}" download="peak_data.csv">Download Peak Data CSV</a>'
                    st.markdown(href, unsafe_allow_html=True)

# Footer - small and unobtrusive
st.markdown("""<div style="text-align: center; opacity: 0.7; font-size: 0.8em; margin-top: 20px;">
GeckoPlotter Web v0.3.0 | © 2025 | 
<a href="https://github.com/yourusername/geckoplotter" target="_blank">GitHub</a> | 
<a href="#" onclick="alert('Documentation coming soon!')">Docs</a> | 
<a href="mailto:support@geckoplotter.example.com">Support</a>
</div>""", unsafe_allow_html=True)