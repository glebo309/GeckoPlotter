import streamlit as st
import os
import py3Dmol

# Minimal UI and layout configuration
st.set_page_config(page_title="Molecule Viewer", layout="wide")

# Hide Streamlit menu and footer
hide_streamlit_style = """
    <style>
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        .stApp {
            margin: 0;
            padding: 0;
        }
        .stDeployButton {display:none;}
        .stToolbar {display:none;}
        .stStatusWidget {display:none;}
        header {display:none;}
    </style>
"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)

# Load PDB files
pdb_dir = "./pdb"
os.makedirs(pdb_dir, exist_ok=True)
pdb_files = [f for f in os.listdir(pdb_dir) if f.endswith(".pdb")]

if not pdb_files:
    st.error("No PDB files found")
    st.stop()

# File selection with minimal UI
selected_file = st.selectbox("", pdb_files, label_visibility="collapsed")
with open(os.path.join(pdb_dir, selected_file), "r") as f:
    pdb_data = f.read()

# Simple spin control with minimal UI
spin_enabled = st.checkbox("Spin", value=False, label_visibility="collapsed")

# Generate viewer HTML
view = py3Dmol.view(width=800, height=500)
view.addModel(pdb_data, 'pdb')
view.setStyle({'cartoon': {'color': 'spectrum'}})
view.zoomTo()
html = view._make_html()

# Inject spinning control
if spin_enabled:
    html += """
    <script>
    setTimeout(function() {
        let viewer = window.viewer_0;
        viewer.setSpin(true);
        viewer.setSpinSpeed(0.3);
        viewer.render();
    }, 100);
    </script>
    """
else:
    html += """
    <script>
    setTimeout(function() {
        let viewer = window.viewer_0;
        viewer.setSpin(false);
        viewer.render();
    }, 100);
    </script>
    """

# Show viewer without any additional UI
st.components.v1.html(html, height=520)