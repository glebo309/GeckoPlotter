import streamlit as st
import os
import py3Dmol

st.set_page_config(page_title="🧬 Toggle Spin Viewer", layout="wide")
st.title("🌀 Toggleable Spinning Molecule")

# Load PDB files
pdb_dir = "./pdb"
os.makedirs(pdb_dir, exist_ok=True)
pdb_files = [f for f in os.listdir(pdb_dir) if f.endswith(".pdb")]

if not pdb_files:
    st.error("No PDB files in ./pdb")
    st.stop()

selected_file = st.selectbox("Choose a PDB file:", pdb_files)
with open(os.path.join(pdb_dir, selected_file), "r") as f:
    pdb_data = f.read()

# State
if "spin_enabled" not in st.session_state:
    st.session_state.spin_enabled = False

if st.button("🌀 Toggle Spin"):
    st.session_state.spin_enabled = not st.session_state.spin_enabled

# Generate viewer HTML
view = py3Dmol.view(width=800, height=500)
view.addModel(pdb_data, 'pdb')
view.setStyle({'cartoon': {'color': 'spectrum'}})
view.zoomTo()
html = view._make_html()

# Inject working spin AFTER render
if st.session_state.spin_enabled:
    html += """
    <script>
    setTimeout(function() {
        let viewer = window.viewer_0;
        viewer.setSpin(true);
        viewer.setSpinSpeed(0.3);
        viewer.render();
    }, 100);
    </script>
    """
else:
    html += """
    <script>
    setTimeout(function() {
        let viewer = window.viewer_0;
        viewer.setSpin(false);
        viewer.render();
    }, 100);
    </script>
    """

# Show viewer
st.components.v1.html(html, height=520)

# Show current state
st.caption(f"Spin is {'ON' if st.session_state.spin_enabled else 'OFF'}")
