# Fixed version of test_theme.py
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd
from plotly.subplots import make_subplots

def generate_sample_data():
    """Generate sample data for demonstration"""
    # Generate x values
    x = np.linspace(0, 10, 100)
    
    # Generate some peaks with noise
    y1 = 2.0 * np.exp(-((x - 3) ** 2) / 0.5) + 0.2 * np.random.randn(len(x))
    y2 = 1.5 * np.exp(-((x - 6) ** 2) / 0.3) + 0.1 * np.random.randn(len(x))
    y3 = 1.0 * np.exp(-((x - 8) ** 2) / 0.2) + 0.05 * np.random.randn(len(x))
    
    # Create a baseline with slight drift
    baseline = 0.1 * x / 10
    
    # Add baseline to signals
    y1 += baseline
    y2 += baseline
    y3 += baseline
    
    return x, y1, y2, y3, baseline


def apply_plotly_theme(fig, theme_name, wide_format=True):
    """Apply a specific theme to a plotly figure with optional wide format"""
    
    # Set wide format if requested
    if wide_format:
        fig.update_layout(
            width=1000,  # Wider
            height=450,  # Shorter for wide aspect ratio
            margin=dict(l=50, r=50, t=60, b=60)
        )
    
    # Apply the specific theme
    if theme_name == "excel_classic":
        # Excel 2003-style theme
        fig.update_layout(
            font=dict(family="Arial", size=12, color="black"),
            plot_bgcolor="#E9E9E9",
            paper_bgcolor="white",
            title_font=dict(size=14, color="black"),
            legend=dict(
                font=dict(size=11),
                bgcolor="#E9E9E9",
                bordercolor="black",
                borderwidth=1
            ),
            margin=dict(l=50, r=50, t=60, b=60)
        )
        fig.update_xaxes(
            showline=True, linewidth=1, linecolor='black', 
            gridcolor='white', gridwidth=1.5,
            tickfont=dict(size=10),
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=1, linecolor='black', 
            gridcolor='white', gridwidth=1.5,
            tickfont=dict(size=10),
            minor_showgrid=False
        )
        # Add box around the plot
        fig.update_layout(
            shapes=[
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="black", width=1)
                )
            ]
        )
        
    elif theme_name == "journal_box":
        # Scientific journal with prominent box
        fig.update_layout(
            font=dict(family="Arial", size=14, color="black"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            title_font=dict(size=16, color="black"),
            legend=dict(
                font=dict(size=12),
                bgcolor="white",
                bordercolor="black",
                borderwidth=1
            ),
            margin=dict(l=60, r=60, t=80, b=60)
        )
        fig.update_xaxes(
            showline=True, linewidth=1.5, linecolor='black', 
            gridcolor='lightgray', gridwidth=0.5,
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=1.5, linecolor='black', 
            gridcolor='lightgray', gridwidth=0.5,
            minor_showgrid=False
        )
        # Add thick box around the plot
        fig.update_layout(
            shapes=[
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="black", width=2)
                )
            ]
        )
    
    elif theme_name == "retro_terminal":
        # Retro computer terminal style
        fig.update_layout(
            font=dict(family="Courier New", size=14, color="#33FF33"),
            plot_bgcolor="black",
            paper_bgcolor="black",
            title_font=dict(size=16, color="#33FF33"),
            legend=dict(
                font=dict(size=12, color="#33FF33"),
                bgcolor="black",
                bordercolor="#33FF33",
                borderwidth=1
            ),
            margin=dict(l=60, r=60, t=80, b=60)
        )
        fig.update_xaxes(
            showline=True, linewidth=1, linecolor='#33FF33', 
            gridcolor='#003300', gridwidth=1,
            title_font=dict(color="#33FF33"),
            tickfont=dict(color="#33FF33"),
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=1, linecolor='#33FF33', 
            gridcolor='#003300', gridwidth=1,
            title_font=dict(color="#33FF33"),
            tickfont=dict(color="#33FF33"),
            minor_showgrid=False
        )
        # Update trace colors for visibility on dark background
        for trace in fig.data:
            if trace.line:
                if trace.line.color == 'blue':
                    trace.line.color = '#00FFFF'  # Cyan
                elif trace.line.color == 'red':
                    trace.line.color = '#FF5555'  # Bright red
                elif trace.line.color == 'green':
                    trace.line.color = '#33FF33'  # Bright green
                elif trace.line.color == 'black':
                    trace.line.color = '#FFFFFF'  # White
    
    elif theme_name == "high_contrast":
        # High contrast for accessibility
        fig.update_layout(
            font=dict(family="Arial", size=16, color="black"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            title_font=dict(size=20, color="black"),
            legend=dict(
                font=dict(size=16, color="black"),
                bgcolor="white",
                bordercolor="black",
                borderwidth=2
            ),
            margin=dict(l=70, r=70, t=90, b=70)
        )
        fig.update_xaxes(
            showline=True, linewidth=2, linecolor='black', 
            gridcolor='lightgray', gridwidth=1,
            title_font=dict(size=18),
            tickfont=dict(size=16),
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=2, linecolor='black', 
            gridcolor='lightgray', gridwidth=1,
            title_font=dict(size=18),
            tickfont=dict(size=16),
            minor_showgrid=False
        )
        # Update trace colors for high contrast
        for trace in fig.data:
            if trace.line:
                if trace.line.color == 'blue':
                    trace.line.color = '#0000FF'  # Pure blue
                    trace.line.width = 3
                elif trace.line.color == 'red':
                    trace.line.color = '#FF0000'  # Pure red
                    trace.line.width = 3
                elif trace.line.color == 'green':
                    trace.line.color = '#008000'  # Pure green
                    trace.line.width = 3
                elif trace.line.color == 'black':
                    trace.line.color = '#000000'  # Black
                    trace.line.width = 3
        # Add thick box around the plot
        fig.update_layout(
            shapes=[
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="black", width=3)
                )
            ]
        )

    elif theme_name == "minimalist_box":
        # Ultra minimalist with subtle box
        fig.update_layout(
            font=dict(family="Helvetica", size=12, color="#333333"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            title_font=dict(size=14, color="#333333"),
            legend=dict(
                font=dict(size=10, color="#333333"),
                bgcolor="white",
                bordercolor="white",
            ),
            margin=dict(l=40, r=40, t=50, b=40)
        )
        fig.update_xaxes(
            showline=True, linewidth=0.5, linecolor='#333333', 
            gridcolor='white',
            title_font=dict(size=12),
            tickfont=dict(size=10),
            minor_showgrid=False,
            showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=0.5, linecolor='#333333', 
            gridcolor='white',
            title_font=dict(size=12),
            tickfont=dict(size=10),
            minor_showgrid=False,
            showgrid=False
        )
        # Add subtle box around the plot
        fig.update_layout(
            shapes=[
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="#CCCCCC", width=0.5)
                )
            ]
        )
    
    elif theme_name == "pnas_style":
        # PNAS (Proceedings of the National Academy of Sciences) style
        fig.update_layout(
            font=dict(family="Arial", size=14, color="black"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            title_font=dict(size=16, color="black"),
            legend=dict(
                font=dict(size=12),
                bgcolor="white",
                bordercolor="white",
            ),
            margin=dict(l=60, r=60, t=80, b=60)
        )
        fig.update_xaxes(
            showline=True, linewidth=1.5, linecolor='black', 
            gridcolor='#EEEEEE', gridwidth=0.5,
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=1.5, linecolor='black', 
            gridcolor='#EEEEEE', gridwidth=0.5,
            minor_showgrid=False
        )
        # Add box around the plot
        fig.update_layout(
            shapes=[
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="black", width=1.5)
                )
            ]
        )
    
    elif theme_name == "neon_synthwave":
        # Outlandish neon synthwave style
        fig.update_layout(
            font=dict(family="Helvetica", size=14, color="#FF00FF"),
            plot_bgcolor="#120052",
            paper_bgcolor="#0C0032",
            title_font=dict(size=18, color="#FF00FF"),
            legend=dict(
                font=dict(size=12, color="#FF00FF"),
                bgcolor="#120052",
                bordercolor="#FF00FF",
                borderwidth=1
            ),
            margin=dict(l=60, r=60, t=80, b=60)
        )
        fig.update_xaxes(
            showline=True, linewidth=1, linecolor='#FF00FF', 
            gridcolor='#1A0066', gridwidth=1,
            title_font=dict(color="#FF00FF"),
            tickfont=dict(color="#FF00FF"),
            minor_showgrid=False
        )
        fig.update_yaxes(
            showline=True, linewidth=1, linecolor='#FF00FF', 
            gridcolor='#1A0066', gridwidth=1,
            title_font=dict(color="#FF00FF"),
            tickfont=dict(color="#FF00FF"),
            minor_showgrid=False
        )
        # Update trace colors
        for i, trace in enumerate(fig.data):
            if trace.line:
                if i == 0:
                    trace.line.color = '#00FFFF'  # Cyan
                    trace.line.width = 2.5
                elif i == 1:
                    trace.line.color = '#FF00FF'  # Magenta
                    trace.line.width = 2.5
                elif i == 2:
                    trace.line.color = '#FFFF00'  # Yellow
                    trace.line.width = 2.5
                else:
                    trace.line.color = '#FFFFFF'  # White
        # Add glow effect with multiple boxes
        fig.update_layout(
            shapes=[
                # Outer glow
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=-0.02, y0=-0.02, x1=1.02, y1=1.02,
                    line=dict(color="#FF00FF", width=2),
                    fillcolor="rgba(0,0,0,0)"
                ),
                # Inner glow
                dict(
                    type="rect",
                    xref="paper", yref="paper",
                    x0=0, y0=0, x1=1, y1=1,
                    line=dict(color="#00FFFF", width=1),
                    fillcolor="rgba(0,0,0,0)"
                ),
            ]
        )
    
    else:
        # Apply built-in Plotly themes or the other existing themes
        if theme_name in ["plotly", "plotly_white", "plotly_dark", "ggplot2", "seaborn", "simple_white"]:
            fig.update_layout(template=theme_name)
        # Add the other themes you've already defined (scientific, nature_journal, etc.)
        # ...

    return fig



def create_chromatogram_plot(theme_name):
    """Create a realistic chromatogram-like plot with the specified theme"""
    # Generate more realistic data
    x = np.linspace(0, 10, 500)  # More data points for smoother curves
    
    # Create more realistic chromatogram peaks with proper shape
    def gaussian_peak(x, amplitude, center, width):
        return amplitude * np.exp(-((x - center) ** 2) / (2 * width ** 2))
    
    # Generate base chromatogram with multiple peaks
    y1 = (
        gaussian_peak(x, 1.0, 3.0, 0.15) + 
        gaussian_peak(x, 0.3, 4.2, 0.08) + 
        gaussian_peak(x, 0.5, 6.3, 0.12) +
        gaussian_peak(x, 0.8, 7.8, 0.10)
    )
    
    y2 = (
        gaussian_peak(x, 0.8, 3.0, 0.15) + 
        gaussian_peak(x, 0.4, 4.2, 0.08) + 
        gaussian_peak(x, 0.7, 6.3, 0.12) +
        gaussian_peak(x, 0.6, 7.8, 0.10)
    )
    
    y3 = (
        gaussian_peak(x, 0.7, 3.0, 0.15) + 
        gaussian_peak(x, 0.5, 4.2, 0.08) + 
        gaussian_peak(x, 0.3, 6.3, 0.12) +
        gaussian_peak(x, 0.9, 7.8, 0.10)
    )
    
    # Add slight baseline drift
    baseline = 0.02 * x + 0.01 * np.sin(x)
    
    # Add very subtle noise
    noise_level = 0.005
    y1 = y1 + baseline + noise_level * np.random.randn(len(x))
    y2 = y2 + baseline + noise_level * np.random.randn(len(x))
    y3 = y3 + baseline + noise_level * np.random.randn(len(x))
    
    # Create figure
    fig = go.Figure()
    
    # Add traces for each sample
    fig.add_trace(go.Scatter(
        x=x, y=y1,
        mode='lines',
        name='Sample 1',
        line=dict(color='blue', width=1.5)
    ))
    
    fig.add_trace(go.Scatter(
        x=x, y=y2,
        mode='lines',
        name='Sample 2',
        line=dict(color='red', width=1.5)
    ))
    
    fig.add_trace(go.Scatter(
        x=x, y=y3,
        mode='lines',
        name='Sample 3',
        line=dict(color='green', width=1.5)
    ))
    
    # Add baseline
    fig.add_trace(go.Scatter(
        x=x, y=baseline,
        mode='lines',
        name='Baseline',
        line=dict(color='black', width=1, dash='dash'),
        showlegend=True
    ))
    
    # Update layout
    fig.update_layout(
        title='Chromatogram Analysis',
        xaxis_title='Retention Time (min)',
        yaxis_title='Signal (a.u.)',
        legend_title='Samples',
        hovermode='closest'
    )
    
    # Apply the specified theme
    fig = apply_plotly_theme(fig, theme_name)
    
    return fig

def create_calibration_plot(theme_name):
    """Create a calibration curve plot with the specified theme"""
    # Generate sample calibration data
    concentrations = np.array([0, 1, 2, 5, 10, 20, 50, 100])
    areas = 2.5 * concentrations + 1.2 + np.random.normal(0, 0.8, len(concentrations))
    
    # Create linear fit
    m, b = np.polyfit(concentrations, areas, 1)
    fit_line = m * concentrations + b
    r_squared = np.corrcoef(concentrations, areas)[0, 1]**2
    
    # Create figure
    fig = go.Figure()
    
    # Add calibration points
    fig.add_trace(go.Scatter(
        x=concentrations, 
        y=areas,
        mode='markers',
        name='Calibration Standards',
        marker=dict(color='blue', size=10)
    ))
    
    # Add fit line
    fig.add_trace(go.Scatter(
        x=concentrations, 
        y=fit_line,
        mode='lines',
        name=f'Fit: y = {m:.3f}x + {b:.3f} (R² = {r_squared:.4f})',
        line=dict(color='red', width=2)
    ))
    
    # Add annotation for the equation
    fig.add_annotation(
        xref="paper", yref="paper",
        x=0.05, y=0.95,
        text=f"y = {m:.3f}x + {b:.3f}<br>R² = {r_squared:.4f}",
        showarrow=False,
        font=dict(size=14),
        align="left",
        bgcolor="rgba(255, 255, 255, 0.8)",
        bordercolor="black",
        borderwidth=1
    )
    
    # Update layout
    fig.update_layout(
        title='Calibration Curve',
        xaxis_title='Concentration (μg/mL)',
        yaxis_title='Area (a.u.)',
        legend_title='Data',
        hovermode='closest'
    )
    
    # Apply the specified theme
    fig = apply_plotly_theme(fig, theme_name)
    
    return fig

def create_stacked_plots(theme_name):
    """Create stacked plots similar to chromatogram analysis with the specified theme"""
    # Generate sample data
    x, y1, y2, y3, baseline = generate_sample_data()
    
    # Create subplots
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True)
    
    # Add traces for each sample in separate subplots
    fig.add_trace(
        go.Scatter(
            x=x, y=y1,
            mode='lines',
            name='Sample 1',
            line=dict(color='blue', width=1.5)
        ),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Scatter(
            x=x, y=y2,
            mode='lines',
            name='Sample 2',
            line=dict(color='red', width=1.5)
        ),
        row=2, col=1
    )
    
    fig.add_trace(
        go.Scatter(
            x=x, y=y3,
            mode='lines',
            name='Sample 3',
            line=dict(color='green', width=1.5)
        ),
        row=3, col=1
    )
    
    # Update layout
    fig.update_layout(
        title='Stacked Chromatograms',
        legend_title='Samples',
        hovermode='closest',
        height=600  # Taller to accommodate stacked plots
    )
    
    # Update axes
    fig.update_xaxes(title_text='Retention Time (min)', row=3, col=1)
    fig.update_yaxes(title_text='Signal (a.u.)', row=1, col=1)
    fig.update_yaxes(title_text='Signal (a.u.)', row=2, col=1)
    fig.update_yaxes(title_text='Signal (a.u.)', row=3, col=1)
    
    # Apply the specified theme
    fig = apply_plotly_theme(fig, theme_name)
    
    return fig

def main():
    st.title("Plotly Theme Showcase for Scientific Publications")
    
    st.write("""
    This application demonstrates various Plotly themes suitable for scientific publications,
    ranging from modern minimalist to traditional scientific paper styles.
    Choose a theme and plot type to see how your chromatography data could look in publications.
    """)
    
    # Theme selector - FIXED: Added missing comma between "origin_pro" and "excel_classic"
    theme_options = [
        "plotly",
        "plotly_white",
        "plotly_dark",
        "ggplot2",
        "seaborn",
        "simple_white",
        "scientific",
        "nature_journal",
        "jacs",
        "matlab_classic",
        "origin_pro",  # Added comma here
        "excel_classic",
        "journal_box",
        "retro_terminal",
        "high_contrast",
        "minimalist_box",
        "pnas_style",
        "neon_synthwave"
    ]
    
    theme_descriptions = {
        "plotly": "Default Plotly theme - modern and clean",
        "plotly_white": "Clean white background with minimal grid",
        "plotly_dark": "Dark mode for presentations",
        "ggplot2": "Inspired by R's ggplot2 package",
        "seaborn": "Based on Python's Seaborn visualization library",
        "simple_white": "Minimalist white background",
        "scientific": "Traditional scientific publication style",
        "nature_journal": "Inspired by Nature journal style",
        "jacs": "Journal of the American Chemical Society style",
        "matlab_classic": "Classic MATLAB plotting style",
        "origin_pro": "Inspired by OriginPro software",
        # Add descriptions for new themes
        "excel_classic": "Classic Excel-style plots with gray background and grid",
        "journal_box": "Scientific journal style with prominent black box border",
        "retro_terminal": "Green-on-black terminal style like old computers",
        "high_contrast": "Accessibility-focused with large fonts and strong colors",
        "minimalist_box": "Ultra-clean design with subtle box outline",
        "pnas_style": "Proceedings of the National Academy of Sciences style",
        "neon_synthwave": "Bold neon colors with glowing outlines"
    }
        
    col1, col2 = st.columns([1, 2])
    
    with col1:
        selected_theme = st.selectbox(
            "Select Theme",
            options=theme_options,
            format_func=lambda x: f"{x} - {theme_descriptions[x]}"
        )
        
        plot_type = st.radio(
            "Select Plot Type",
            ["Chromatogram", "Calibration Curve", "Stacked Plots"]
        )
        
        st.markdown("### Theme Details")
        st.markdown(f"**{selected_theme}**: {theme_descriptions[selected_theme]}")
        
        if selected_theme == "scientific":
            st.markdown("""
            **Scientific Theme Features:**
            - Black axes with thin gridlines
            - Arial fonts for readability
            - Suitable for journal submissions
            - Black & white friendly
            """)
            
        elif selected_theme == "nature_journal":
            st.markdown("""
            **Nature Journal Theme Features:**
            - Clean, minimalist design
            - Emphasized axis lines
            - Larger fonts for readability
            - Optimized for publication quality
            """)
            
        elif selected_theme == "jacs":
            st.markdown("""
            **JACS Theme Features:**
            - Times New Roman fonts (journal standard)
            - Thicker axis lines
            - Publication-ready formatting
            - ACS journal compatible
            """)
            
        elif selected_theme == "matlab_classic":
            st.markdown("""
            **MATLAB Classic Theme Features:**
            - Gray background with white grid
            - Bold colors for traces
            - Familiar to MATLAB users
            - Good for presentations
            """)
            
        elif selected_theme == "origin_pro":
            st.markdown("""
            **Origin Pro Theme Features:**
            - Minor grid lines for precision
            - Clean white background
            - Optimized for data analysis
            - Publication-quality formatting
            """)
        
        # Additional theme descriptions
        elif selected_theme == "excel_classic":
            st.markdown("""
            **Excel Classic Theme Features:**
            - Gray background with white grid
            - Simple Arial fonts
            - Box outline around the entire plot
            - Familiar to Excel users
            """)
            
        elif selected_theme == "journal_box":
            st.markdown("""
            **Journal Box Theme Features:**
            - Bold black box around the plot
            - Clean white background
            - Professional scientific appearance
            - Perfect for publication figures
            """)
            
        elif selected_theme == "retro_terminal":
            st.markdown("""
            **Retro Terminal Theme Features:**
            - Green text on black background
            - Monospace fonts (Courier New)
            - Inspired by vintage computer terminals
            - Great for tech presentations
            """)

        elif selected_theme == "high_contrast":
            st.markdown("""
            **High Contrast Theme Features:**
            - Extra large fonts and line widths
            - Maximum readability for presentations
            - Accessibility focused design
            - Bold border and pure colors
            """)

        elif selected_theme == "minimalist_box":
            st.markdown("""
            **Minimalist Box Theme Features:**
            - Ultra clean design with minimal elements
            - Subtle gray box outline
            - No grid lines
            - Focus on the data visualization
            """)

        elif selected_theme == "pnas_style":
            st.markdown("""
            **PNAS Style Theme Features:**
            - Clean scientific journal style
            - Professional appearance for publications
            - High-quality formatting standards
            - Subtle gridlines with emphasis on data
            """)

        elif selected_theme == "neon_synthwave":
            st.markdown("""
            **Neon Synthwave Theme Features:**
            - Bold pink, cyan and yellow neon colors
            - Dark background with glowing effects
            - Retro-futuristic aesthetic
            - Eye-catching presentation style
            """)
   


    with col2:
        # Add wide format checkbox
        wide_format = st.checkbox("Wide Format", value=True)
        
        if plot_type == "Chromatogram":
            fig = create_chromatogram_plot(selected_theme)
            # Apply the theme with wide format
            fig = apply_plotly_theme(fig, selected_theme, wide_format=wide_format)
            st.plotly_chart(fig, use_container_width=True)
            
        elif plot_type == "Calibration Curve":
            fig = create_calibration_plot(selected_theme)
            # Apply the theme with wide format
            fig = apply_plotly_theme(fig, selected_theme, wide_format=wide_format)
            st.plotly_chart(fig, use_container_width=True)
            
        elif plot_type == "Stacked Plots":
            fig = create_stacked_plots(selected_theme)
            # Apply the theme with wide format
            fig = apply_plotly_theme(fig, selected_theme, wide_format=wide_format)
            st.plotly_chart(fig, use_container_width=True)
            

    # Code to implement the theme
    st.markdown("### Implementation Code")
    
    with st.expander("Show code for implementing this theme"):
        # In the show code expander, add the new themes:
        if selected_theme in ["scientific", "nature_journal", "jacs", "matlab_classic", 
                            "origin_pro", "excel_classic", "journal_box", "retro_terminal", 
                            "high_contrast", "minimalist_box", "pnas_style", "neon_synthwave"]:
      
            theme_function = """
def apply_theme_to_figure(fig):
    """
            
            if selected_theme == "scientific":
                theme_function += """
    # Scientific publication theme
    fig.update_layout(
        font=dict(family="Arial", size=14, color="black"),
        plot_bgcolor="white",
        paper_bgcolor="white",
        title_font=dict(size=16, color="black", family="Arial"),
        legend=dict(
            font=dict(size=12, color="black"),
            bgcolor="white",
            bordercolor="black",
            borderwidth=1
        ),
        margin=dict(l=80, r=50, t=60, b=80)
    )
    fig.update_xaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    fig.update_yaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    return fig
"""
            elif selected_theme == "nature_journal":
                theme_function += """
    # Nature journal theme
    fig.update_layout(
        font=dict(family="Arial", size=14, color="black"),
        plot_bgcolor="white",
        paper_bgcolor="white",
        title_font=dict(size=16, color="black", family="Arial", weight="bold"),
        legend=dict(
            font=dict(size=12, color="black"),
            bgcolor="white",
            bordercolor="white",
        ),
        margin=dict(l=60, r=20, t=40, b=60)
    )
    fig.update_xaxes(
        showline=True, linewidth=1.5, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    fig.update_yaxes(
        showline=True, linewidth=1.5, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    return fig
"""
            elif selected_theme == "jacs":
                theme_function += """
    # JACS theme
    fig.update_layout(
        font=dict(family="Times New Roman", size=14, color="black"),
        plot_bgcolor="white",
        paper_bgcolor="white",
        title_font=dict(size=16, color="black", family="Times New Roman"),
        legend=dict(
            font=dict(size=12, color="black", family="Times New Roman"),
            bgcolor="white",
            bordercolor="black",
            borderwidth=1
        ),
        margin=dict(l=80, r=50, t=60, b=80)
    )
    fig.update_xaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black", family="Times New Roman"),
        tickfont=dict(size=12, color="black", family="Times New Roman"),
        minor_showgrid=False
    )
    fig.update_yaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='lightgray', gridwidth=0.5,
        title_font=dict(size=14, color="black", family="Times New Roman"),
        tickfont=dict(size=12, color="black", family="Times New Roman"),
        minor_showgrid=False
    )
    return fig
"""
            elif selected_theme == "matlab_classic":
                theme_function += """
    # MATLAB classic theme
    fig.update_layout(
        font=dict(family="Arial", size=14, color="black"),
        plot_bgcolor="#EEE",
        paper_bgcolor="white",
        title_font=dict(size=16, color="black"),
        legend=dict(
            font=dict(size=12, color="black"),
            bgcolor="#EEE",
            bordercolor="black",
            borderwidth=1
        ),
        margin=dict(l=80, r=50, t=60, b=80)
    )
    fig.update_xaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='white', gridwidth=1.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    fig.update_yaxes(
        showline=True, linewidth=1, linecolor='black', 
        gridcolor='white', gridwidth=1.5,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=False
    )
    return fig
"""
            elif selected_theme == "origin_pro":
                theme_function += """
    # Origin Pro theme
    fig.update_layout(
        font=dict(family="Arial", size=14, color="black"),
        plot_bgcolor="white",
        paper_bgcolor="white",
        title_font=dict(size=16, color="black", family="Arial"),
        legend=dict(
            font=dict(size=12, color="black"),
            bgcolor="white",
            bordercolor="black",
            borderwidth=1
        ),
        margin=dict(l=80, r=50, t=60, b=80)
    )
    fig.update_xaxes(
        showline=True, linewidth=1.5, linecolor='black', 
        gridcolor='#DDDDDD', gridwidth=1,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=True,
        minor_gridcolor="#EEEEEE",
        minor_gridwidth=0.5
    )
    fig.update_yaxes(
        showline=True, linewidth=1.5, linecolor='black', 
        gridcolor='#DDDDDD', gridwidth=1,
        title_font=dict(size=14, color="black"),
        tickfont=dict(size=12, color="black"),
        minor_showgrid=True,
        minor_gridcolor="#EEEEEE",
        minor_gridwidth=0.5
    )
    return fig
"""
            # After the existing theme-specific descriptions
            elif selected_theme == "excel_classic":
                st.markdown("""
                **Excel Classic Theme Features:**
                - Gray background with white grid
                - Simple Arial fonts
                - Box outline around the entire plot
                - Familiar to Excel users
                """)
                
            elif selected_theme == "journal_box":
                st.markdown("""
                **Journal Box Theme Features:**
                - Bold black box around the plot
                - Clean white background
                - Professional scientific appearance
                - Perfect for publication figures
                """)
                
            elif selected_theme == "retro_terminal":
                st.markdown("""
                **Retro Terminal Theme Features:**
                - Green text on black background
                - Monospace fonts (Courier New)
                - Inspired by vintage computer terminals
                - Great for tech presentations
                """)

            elif selected_theme == "high_contrast":
                st.markdown("""
                **High Contrast Theme Features:**
                - Extra large fonts and line widths
                - Maximum readability for presentations
                - Accessibility focused design
                - Bold border and pure colors
                """)

            elif selected_theme == "minimalist_box":
                st.markdown("""
                **Minimalist Box Theme Features:**
                - Ultra clean design with minimal elements
                - Subtle gray box outline
                - No grid lines
                - Focus on the data visualization
                """)

            elif selected_theme == "pnas_style":
                st.markdown("""
                **PNAS Style Theme Features:**
                - Clean scientific journal style
                - Professional appearance for publications
                - High-quality formatting standards
                - Subtle gridlines with emphasis on data
                """)

            elif selected_theme == "neon_synthwave":
                st.markdown("""
                **Neon Synthwave Theme Features:**
                - Bold pink, cyan and yellow neon colors
                - Dark background with glowing effects
                - Retro-futuristic aesthetic
                - Eye-catching presentation style
                """)

            st.code(theme_function, language="python")
        else:
            st.code(f"# Built-in Plotly theme\nfig.update_layout(template='{selected_theme}')")
    
    st.markdown("### How to Use")
    st.markdown("""
    To use these themes in your GeckoPlotter application:

    1. Copy the desired theme implementation code
    2. Add it to your `ui/plot_settings.py` file as a new function
    3. Update your `apply_plot_settings` function to use the theme
    4. Add a dropdown in the UI to select between different themes
    
    This will allow you to quickly switch between publication-ready styles for your plots.
    """)

if __name__ == "__main__":
    main()