import streamlit as st
import numpy as np
import plotly.graph_objects as go
from scipy.signal import find_peaks, savgol_filter
from scipy.integrate import trapezoid
from scipy.optimize import curve_fit
from scipy import stats
import pandas as pd
import copy
import json
import re

st.set_page_config(page_title="🔬 Chromatogram Peak Detection", layout="wide")
st.title("Interactive Chromatogram Peak Detection")

# Initialize session state for storing selected peaks
if 'selected_peaks' not in st.session_state:
    st.session_state.selected_peaks = {}  # Dictionary with chromatogram ID as key

# Define a nicer color palette for peaks and chromatograms
def get_color_from_palette(index, alpha=1.0):
    """Return a color from a predefined palette based on index"""
    palette = [
        (0, 123, 255),     # Blue
        (220, 53, 69),     # Red
        (40, 167, 69),     # Green
        (255, 193, 7),     # Yellow/amber 
        (111, 66, 193),    # Purple
        (23, 162, 184),    # Teal
        (255, 99, 132),    # Pink
        (54, 162, 235),    # Light blue
        (255, 159, 64),    # Orange
        (75, 192, 192),    # Light green
        (153, 102, 255),   # Lavender
        (231, 233, 237)    # Grey
    ]
    
    color = palette[index % len(palette)]
    return f"rgba({color[0]}, {color[1]}, {color[2]}, {alpha})"


# Function to calculate R² from standard points and prediction function
def calculate_r_squared_from_standards(x_values, predict_area):
    """Calculate R² from standard points and prediction function"""
    if len(x_values) < 2:
        return 1.0  # Default for insufficient data
    
    x_array = np.array(list(x_values))
    y_actual = np.array([predict_area(x) for x in x_array])
    y_mean = np.mean(y_actual)
    
    # Total sum of squares
    ss_tot = np.sum((y_actual - y_mean)**2)
    if ss_tot == 0:
        return 1.0  # No variation in data
    
    # Get predicted values using the same function
    y_pred = np.array([predict_area(x) for x in x_array])
    
    # Residual sum of squares
    ss_res = np.sum((y_actual - y_pred)**2)
    
    # Calculate R²
    return 1 - (ss_res / ss_tot)







###  ___________________________- ###
###  ___________________________- ###
###  ___________________________- ###



# 1. Function to test and validate an imported JSON calibration file

def validate_calibration_json(json_data):

    # Check basic required structure
    if 'standards' not in json_data:
        return False, "Missing 'standards' field"
        
    # Check if there are any calibration models
    has_models = 'calibration_models' in json_data and len(json_data['calibration_models']) > 0
    
    # Validate models if present
    if has_models:
        for group_id, model in json_data['calibration_models'].items():
            required_fields = ['name', 'rt', 'model_type', 'formula', 'units']
            for field in required_fields:
                if field not in model:
                    return False, f"Model {group_id} missing required field: {field}"
            
            # Check parameters based on model type
            if 'parameters' not in model:
                return False, f"Model {group_id} missing parameters"
                
            params = model['parameters']
            model_type = model['model_type']
            
            if model_type == 'linear':
                if 'slope' not in params:
                    return False, f"Linear model {group_id} missing slope parameter"
            elif model_type == 'quadratic':
                for p in ['a', 'b']:  # c might be 0 for force_zero
                    if p not in params:
                        return False, f"Quadratic model {group_id} missing parameter: {p}"
            elif model_type == 'power law':
                for p in ['a', 'b']:
                    if p not in params:
                        return False, f"Power law model {group_id} missing parameter: {p}"
    
    # Validate standards
    for group_id, standards in json_data['standards'].items():
        if 'name' not in standards:
            return False, f"Standards group {group_id} missing name"
        
        # Check if there are at least some concentration values (other than name)
        conc_values = {k: v for k, v in standards.items() if k != 'name' and isinstance(v, (int, float))}
        if len(conc_values) < 1:
            return False, f"Standards group {group_id} has no concentration values"
    
    return True, "Valid calibration data"


# 2. Function to reconstruct proper calibration functions from parameters


def create_calibration_functions(model_type, params, force_zero=False):

    if model_type == 'linear':
        slope = params.get('slope', 1.0)
        intercept = params.get('intercept', 0.0) if not force_zero else 0.0
        
        def predict_area(concentration):
            return slope * concentration + intercept
        
        def predict_concentration(area):
            return (area - intercept) / slope if slope != 0 else 0
            
    elif model_type == 'quadratic':
        a = params.get('a', 0.0)
        b = params.get('b', 0.0)
        c = params.get('c', 0.0) if not force_zero else 0.0
        
        def predict_area(concentration):
            return a * concentration**2 + b * concentration + c
        
        def predict_concentration(area):
            if a == 0:  # Linear case
                return (area - c) / b if b != 0 else 0
            
            # Quadratic formula: x = (-b ± sqrt(b² - 4a(c - area))) / 2a
            discriminant = b**2 - 4 * a * (c - area)
            if discriminant < 0:
                return 0  # No real solution
            
            # Choose the smallest positive concentration
            conc1 = (-b + np.sqrt(discriminant)) / (2 * a)
            conc2 = (-b - np.sqrt(discriminant)) / (2 * a)
            
            if conc1 > 0 and conc2 > 0:
                return min(conc1, conc2)
            elif conc1 > 0:
                return conc1
            elif conc2 > 0:
                return conc2
            else:
                return 0  # No positive solution
                
    elif model_type == 'power law':
        a = params.get('a', 1.0)
        b = params.get('b', 1.0)
        
        def predict_area(concentration):
            return a * concentration**b
        
        def predict_concentration(area):
            return (area / a)**(1 / b) if a != 0 and b != 0 else 0
            
    else:
        # Default to linear model if unknown type
        def predict_area(concentration):
            return concentration
        
        def predict_concentration(area):
            return area
            
    return predict_area, predict_concentration



# 3. Function to extract standard concentrations from JSON data
def extract_standards_from_json(json_data, group_id):

    standards = {}
    
    # Check if the group exists in standards
    if 'standards' in json_data and group_id in json_data['standards']:
        standards_data = json_data['standards'][group_id]
        
        # Extract standard concentrations (skip the name field)
        for k, v in standards_data.items():
            if k != 'name' and isinstance(v, (int, float)):
                standards[k] = v
                
    # Also check if there are standards in the calibration model
    if ('calibration_models' in json_data and 
        group_id in json_data['calibration_models'] and
        'standards' in json_data['calibration_models'][group_id]):
        
        model_standards = json_data['calibration_models'][group_id]['standards']
        for k, v in model_standards.items():
            if isinstance(v, (int, float)):
                standards[k] = v
                
    return standards



# Streamlit Code for File Upload and Import


# --- Streamlit Code for File Upload and Import (main app) ---
uploaded_file = st.file_uploader("Upload Calibration JSON", type=['json'], key="main_calibration_uploader")

if uploaded_file is not None:
    try:
        # Read the file content
        json_data = uploaded_file.read().decode('utf-8-sig')
        
        if not json_data.strip():  # Check if the file is not empty after decoding
            st.error("The file is empty!")
        
        # Parse the JSON data
        imported_data = json.loads(json_data)
        
        # Validate the JSON structure
        is_valid, message = validate_calibration_json(imported_data)
        if not is_valid:
            st.error(f"Invalid calibration file: {message}")
        else:
            st.success("File is valid!")
            
            # Extract group IDs from the calibration_models
            available_groups = list(imported_data.get("calibration_models", {}).keys())
            
            if not available_groups:
                st.warning("No calibration models found in the file.")
            else:
                # Allow user to select which group to use
                group_id = st.selectbox(
                    "Select Calibration Group",
                    options=available_groups,
                    format_func=lambda x: imported_data["calibration_models"][x].get("name", x)
                )
                
                # Extract the model data
                model_data = imported_data["calibration_models"][group_id]
                st.write(f"Selected model: {model_data['name']}")
                
                # Extract calibration functions
                model_type = model_data.get("model_type", "linear")
                params = model_data.get("parameters", {})
                force_zero = model_data.get("force_zero", False)
                predict_area, predict_concentration = create_calibration_functions(model_type, params, force_zero)
                
                # Extract standards data
                standards = {}
                if "standards" in model_data:
                    standards = model_data["standards"]
                elif group_id in imported_data.get("standards", {}):
                    standards = {k: v for k, v in imported_data["standards"][group_id].items() if k != 'name'}
                
                # Display calibration parameters
                st.write(f"Model type: {model_type}")
                st.write(f"Formula: {model_data.get('formula', 'Not available')}")
                st.write(f"R²: {model_data.get('r_squared', 'Not available')}")
                
                # Create a scatter plot of calibration standards
                if standards:
                    # Create data for the plot
                    x_data = []  # Concentrations
                    y_data = []  # Areas
                    
                    for sample_id, concentration in standards.items():
                        if isinstance(concentration, (int, float)):
                            # Calculate expected area
                            area = predict_area(concentration)
                            x_data.append(concentration)
                            y_data.append(area)
                    
                    if x_data:
                        # Plot calibration standards
                        import plotly.graph_objects as go
                        
                        # Create plot
                        fig = go.Figure()
                        
                        # Add scatter points
                        fig.add_trace(go.Scatter(
                            x=x_data,
                            y=y_data,
                            mode='markers',
                            name='Calibration Standards',
                            marker=dict(color='blue', size=10)
                        ))
                        
                        # Add line for calibration curve
                        x_curve = np.linspace(0, max(x_data) * 1.1, 100)
                        y_curve = [predict_area(x) for x in x_curve]
                        
                        fig.add_trace(go.Scatter(
                            x=x_curve,
                            y=y_curve,
                            mode='lines',
                            name='Calibration Curve',
                            line=dict(color='red', width=2)
                        ))
                        
                        # Set plot layout
                        units = model_data.get('units', 'µg/mL')
                        fig.update_layout(
                            title=f"Calibration Curve: {model_data['name']}",
                            xaxis_title=f"Concentration ({units})",
                            yaxis_title="Area (a.u.·min)",
                            hovermode="closest"
                        )
                        
                        # Display the plot
                        st.plotly_chart(fig)
                    else:
                        st.warning("No valid calibration standards found.")
                else:
                    st.warning("No standards data found for this calibration model.")
                
                # Add button to import into the app
                if st.button("Use This Calibration Model"):
                    # Save the model to session state
                    if 'calibration_models' not in st.session_state:
                        st.session_state.calibration_models = {}
                    
                    # Store the model with functions
                    st.session_state.calibration_models[group_id] = {
                        'name': model_data['name'],
                        'rt': model_data['rt'],
                        'model_type': model_type,
                        'force_zero': force_zero,
                        'predict_concentration': predict_concentration,
                        'predict_area': predict_area,
                        'r_squared': model_data.get('r_squared', 1.0),
                        'formula': model_data.get('formula', ''),
                        'units': model_data.get('units', 'µg/mL'),
                        'parameters': params,
                        'standards': standards
                    }
                    
                    # Also store the standards data
                    if 'calibration_data' not in st.session_state:
                        st.session_state.calibration_data = {
                            'standards': {},
                            'model_type': model_type,
                            'force_zero': force_zero,
                            'units': model_data.get('units', 'µg/mL')
                        }
                    
                    if 'standards' in imported_data and group_id in imported_data['standards']:
                        st.session_state.calibration_data['standards'][group_id] = imported_data['standards'][group_id]
                    
                    st.success(f"Calibration model '{model_data['name']}' imported and ready to use!")
                    st.rerun()
    
    except Exception as e:
        st.error(f"Error importing calibration file: {str(e)}")
        st.exception(e)  # This will show the full traceback for debugging


# Initialize with one default chromatogram
if 'chromatograms' not in st.session_state:
    st.session_state.chromatograms = {
        0: {
            'name': 'Sample 1',
            'x': np.linspace(0, 10, 500),
            'y': None,  # Will be generated below
            'color': get_color_from_palette(0),
            'visible': True
        }
    }

if 'next_peak_id' not in st.session_state:
    st.session_state.next_peak_id = 0

if 'active_chromatogram' not in st.session_state:
    st.session_state.active_chromatogram = 0

if 'view_mode' not in st.session_state:
    st.session_state.view_mode = "Sample Results"  # or "Peak Results"

# Initialize advanced settings in session state for persistence
if 'settings' not in st.session_state:
    st.session_state.settings = {
        'snr': 3.0,  # Signal-to-noise ratio
        'slope_threshold': 0.01,  # 1% - much looser for finding more of the peak
        'baseline_iterations': 50,  # For baseline detection
        'percentile': 5,  # For baseline estimation
        'extension_factor': 1.5,  # How much to extend peak boundaries
        'show_peak_markers': False
    }

# Initialize calibration data in session state if not present
if 'calibration_data' not in st.session_state:
    st.session_state.calibration_data = {
        'standards': {},  # Dict to store standard concentrations for peak groups
        'model_type': 'linear',  # Default model type
        'force_zero': False,  # Force through zero option
        'units': 'µg/mL'  # Default units
    }

# Initialize storage for calibration models
if 'calibration_models' not in st.session_state:
    st.session_state.calibration_models = {}

# Store auto-threshold for each chromatogram
if 'auto_thresholds' not in st.session_state:
    st.session_state.auto_thresholds = {}

# Generate synthetic data for each chromatogram if not already generated
for chrom_id, chrom_data in st.session_state.chromatograms.items():
    if chrom_data['y'] is None:
        x = chrom_data['x']
        amplitude_modifier = 1.0 if chrom_id == 0 else 0.8 + np.random.random() * 0.4
        time_shift = 0 if chrom_id == 0 else np.random.random() * 0.3
        
        # Generate slightly different chromatograms for each sample
        y = (
            amplitude_modifier * 800 * np.exp(-((x - (5 + time_shift)) ** 2) / 0.02)
            + amplitude_modifier * 200 * np.exp(-((x - (7 - time_shift)) ** 2) / 0.005)
            + 10 * np.sin(5 * x)
            + np.random.normal(0, 2, len(x))
        )
        
        st.session_state.chromatograms[chrom_id]['y'] = y
        
        # Initialize empty peaks list for this chromatogram
        if chrom_id not in st.session_state.selected_peaks:
            st.session_state.selected_peaks[chrom_id] = []

# --- Chromatogram Management ---
st.sidebar.header("Chromatogram Management")

# Add a new chromatogram
def add_new_chromatogram():
    new_id = max(st.session_state.chromatograms.keys()) + 1 if st.session_state.chromatograms else 0
    st.session_state.chromatograms[new_id] = {
        'name': f'Sample {new_id + 1}',
        'x': np.linspace(0, 10, 500),
        'y': None,  # Will be generated on next run
        'color': get_color_from_palette(new_id),
        'visible': True
    }
    st.session_state.active_chromatogram = new_id

if st.sidebar.button("Add New Chromatogram"):
    add_new_chromatogram()
    st.rerun()

# Select active chromatogram (interactive clickable labels)
st.sidebar.subheader("Samples")
sample_cols = st.sidebar.columns(2)  # Two columns for labels
for i, (chrom_id, chrom_data) in enumerate(st.session_state.chromatograms.items()):
    col_idx = i % 2
    with sample_cols[col_idx]:
        # Use differently styled buttons for active vs. inactive
        if chrom_id == st.session_state.active_chromatogram:
            st.markdown(f"**<span style='color:{chrom_data['color'].replace('1.0', '1.0')}'>● {chrom_data['name']}</span>**", unsafe_allow_html=True)
        else:
            # Make clickable button
            if st.button(f"{chrom_data['name']}", key=f"select_chrom_{chrom_id}"):
                st.session_state.active_chromatogram = chrom_id
                st.rerun()
                
# Keep selectbox as a fallback, but hide it if we have few samples
if len(st.session_state.chromatograms) > 4:
    # Select active chromatogram (dropdown for many samples)
    chrom_options = {chrom_id: chrom_data['name'] for chrom_id, chrom_data in st.session_state.chromatograms.items()}
    active_chrom_selection = st.sidebar.selectbox(
        "Active Chromatogram", 
        options=list(chrom_options.keys()),
        format_func=lambda x: chrom_options[x],
        index=list(chrom_options.keys()).index(st.session_state.active_chromatogram),
        key="active_chrom_selectbox"
    )
    st.session_state.active_chromatogram = active_chrom_selection

# Get active chromatogram ID for consistent use throughout the code
active_chrom = st.session_state.active_chromatogram

# Rename active chromatogram
new_name = st.sidebar.text_input(
    "Rename Chromatogram", 
    value=st.session_state.chromatograms[active_chrom]['name']
)
if new_name != st.session_state.chromatograms[active_chrom]['name']:
    st.session_state.chromatograms[active_chrom]['name'] = new_name

# Toggle visibility of chromatograms
st.sidebar.subheader("Visible Chromatograms")
for chrom_id, chrom_data in st.session_state.chromatograms.items():
    chrom_data['visible'] = st.sidebar.checkbox(
        chrom_data['name'], 
        value=chrom_data['visible'],
        key=f"visible_{chrom_id}"
    )

# Remove active chromatogram
if len(st.session_state.chromatograms) > 1:
    if st.sidebar.button(f"Remove {st.session_state.chromatograms[active_chrom]['name']}"):
        # Remove the chromatogram
        del st.session_state.chromatograms[active_chrom]
        if active_chrom in st.session_state.selected_peaks:
            del st.session_state.selected_peaks[active_chrom]
            
        # Set active chromatogram to the first available
        st.session_state.active_chromatogram = next(iter(st.session_state.chromatograms.keys()))
        st.rerun()

# --- 2) Signal preprocessing ---
st.sidebar.header("Signal Processing")
smoothing = st.sidebar.slider('Signal smoothing', min_value=0, max_value=15, value=8, step=2)

# --- 3) SNIP Baseline Correction ---
def snip_baseline(y, iterations=100):
    """Statistical-Sensitive Non-linear Iterative Peak-clipping algorithm"""
    signal = np.copy(y)
    for i in range(iterations):
        for j in range(1, len(signal) - 1):
            signal[j] = min(signal[j], (signal[j-1] + signal[j+1]) / 2)
    return signal

# Process each chromatogram
preprocessed_data = {}
for chrom_id, chrom_data in st.session_state.chromatograms.items():
    x = chrom_data['x']
    y = chrom_data['y']
    
    # Apply Savitzky-Golay filter for smoothing
    if smoothing > 0:
        # Make sure smoothing window is odd
        if smoothing % 2 == 0:
            smoothing += 1
        y_smooth = savgol_filter(y, window_length=smoothing, polyorder=2)
    else:
        y_smooth = y
    
    # Apply baseline correction
    baseline = snip_baseline(y_smooth, iterations=st.session_state.settings['baseline_iterations'])
    y_corrected = y_smooth - baseline
    
    # Store processed data
    preprocessed_data[chrom_id] = {
        'x': x,
        'y': y,
        'y_smooth': y_smooth,
        'baseline': baseline,
        'y_corrected': y_corrected
    }
    
    # Initialize auto-threshold if needed (5% of max by default)
    if chrom_id not in st.session_state.auto_thresholds:
        st.session_state.auto_thresholds[chrom_id] = float(np.max(y_corrected) * 0.05)

# --- 4) Peak detection function ---
def detect_peak_near_click(x_coord, search_radius=0.5, preserve_color=None, chrom_id=None):
    """Find the nearest peak to the clicked coordinate"""
    if chrom_id is None:
        chrom_id = st.session_state.active_chromatogram
        
    # Get processed data for this chromatogram
    x = preprocessed_data[chrom_id]['x']
    y_corrected = preprocessed_data[chrom_id]['y_corrected']
    y_smooth = preprocessed_data[chrom_id]['y_smooth']
    
    # Find index closest to click
    click_idx = np.abs(x - x_coord).argmin()
    
    # Define search window around click
    window_size = int(search_radius / (x[1] - x[0]))
    left_idx = max(0, click_idx - window_size)
    right_idx = min(len(y_corrected) - 1, click_idx + window_size)
    
    # Find the highest peak in the window
    search_window = y_corrected[left_idx:right_idx+1]
    if len(search_window) == 0:
        return None
    
    local_max_idx = np.argmax(search_window)
    peak_idx = left_idx + local_max_idx
    
    # Get peak properties
    peak_height = y_corrected[peak_idx]
    peak_time = x[peak_idx]
    
    # Determine peak boundaries using a very low slope threshold
    slope_threshold = st.session_state.settings['slope_threshold']
    
    # Look for significant slope change going left
    start_idx = peak_idx
    while start_idx > 0:
        # Calculate slope relative to peak height
        slope = (y_corrected[start_idx] - y_corrected[start_idx-1]) / (x[start_idx] - x[start_idx-1])
        slope_percent = abs(slope / peak_height)
        
        # Stop when slope drops below threshold or signal drops below 1% of peak height
        if slope_percent < slope_threshold or y_corrected[start_idx] < peak_height * 0.01:
            break
        start_idx -= 1
    
    # Look for significant slope change going right
    end_idx = peak_idx
    while end_idx < len(y_corrected) - 1:
        # Calculate slope relative to peak height
        slope = (y_corrected[end_idx] - y_corrected[end_idx+1]) / (x[end_idx+1] - x[end_idx])
        slope_percent = abs(slope / peak_height)
        
        # Stop when slope drops below threshold or signal drops below 1% of peak height
        if slope_percent < slope_threshold or y_corrected[end_idx] < peak_height * 0.01:
            break
        end_idx += 1
    
    # Extend the boundaries to capture more of the peak
    extension = int((end_idx - start_idx) * (st.session_state.settings['extension_factor'] - 1) / 2)
    start_idx = max(0, start_idx - extension)
    end_idx = min(len(y_corrected) - 1, end_idx + extension)
    
    # Calculate width at half height
    half_height = peak_height / 2
    
    # Find left half-height point
    left_hh_idx = peak_idx
    while left_hh_idx > start_idx:
        if y_corrected[left_hh_idx] < half_height:
            # Found point below half height, interpolate
            x1, x2 = x[left_hh_idx], x[left_hh_idx + 1]
            y1, y2 = y_corrected[left_hh_idx], y_corrected[left_hh_idx + 1]
            x_left_hh = x1 + (half_height - y1) * (x2 - x1) / (y2 - y1)
            break
        left_hh_idx -= 1
    else:
        x_left_hh = x[start_idx]
    
    # Find right half-height point
    right_hh_idx = peak_idx
    while right_hh_idx < end_idx:
        if y_corrected[right_hh_idx] < half_height:
            # Found point below half height, interpolate
            x1, x2 = x[right_hh_idx - 1], x[right_hh_idx]
            y1, y2 = y_corrected[right_hh_idx - 1], y_corrected[right_hh_idx]
            x_right_hh = x1 + (half_height - y1) * (x2 - x1) / (y2 - y1)
            break
        right_hh_idx += 1
    else:
        x_right_hh = x[end_idx]
    
    width_hh = abs(x_right_hh - x_left_hh)
    
    # Calculate area by numerical integration
    area = trapezoid(y_corrected[start_idx:end_idx+1], x[start_idx:end_idx+1])
    
    # Generate a color for this peak
    if preserve_color is None:
        # Use nicer colors from the palette
        color_idx = st.session_state.next_peak_id % 12  # Use modulo to cycle through colors
        color_rgba = get_color_from_palette(color_idx, 0.4)  # Use alpha 0.4 by default
        rgba_parts = color_rgba.replace("rgba(", "").replace(")", "").split(",")
        
        # Extract RGB components and convert to integers
        r = int(rgba_parts[0].strip())
        g = int(rgba_parts[1].strip())
        b = int(rgba_parts[2].strip())
        
        # Generate hex color and set opacity
        color_hex = f"#{r:02x}{g:02x}{b:02x}"
        rgba_color = f"rgba({r}, {g}, {b}, 0.4)"
        opacity = 0.4
        user_changed_color = False
    else:
        color_hex = preserve_color['color_hex']
        rgba_color = preserve_color['color']
        opacity = preserve_color['opacity']
        user_changed_color = preserve_color['user_changed_color']
    
    # Create peak info
    peak_info = {
        "id": st.session_state.next_peak_id,
        "peak_idx": peak_idx,
        "Midpoint (min)": peak_time,
        "Height (a.u.)": peak_height,
        "Area (a.u.·min)": area,
        "Min Time (min)": x[start_idx],
        "Max Time (min)": x[end_idx],
        "Width (min)": x[end_idx] - x[start_idx],
        "Width at Half-Height (min)": width_hh,
        "Start Index": start_idx,
        "End Index": end_idx,
        "color": rgba_color,
        "color_hex": color_hex,
        "opacity": opacity,
        "user_changed_color": user_changed_color,
        "name": f"Peak {st.session_state.next_peak_id}"  # Add a name field
    }
    
    return peak_info

# --- 5) Advanced Settings with auto-update callbacks ---
with st.sidebar.expander("Advanced Settings", expanded=False):
    st.subheader("Peak Detection Settings")
    
    # Use callbacks on every parameter to auto-update
    def update_snr():
        old_settings = copy.deepcopy(st.session_state.settings)
        st.session_state.settings['snr'] = st.session_state.snr_slider
        recalculate_all_peaks(old_settings)
        
    def update_slope():
        old_settings = copy.deepcopy(st.session_state.settings)
        st.session_state.settings['slope_threshold'] = st.session_state.slope_slider / 100
        recalculate_all_peaks(old_settings)
        
    def update_baseline_iterations():
        old_settings = copy.deepcopy(st.session_state.settings)
        st.session_state.settings['baseline_iterations'] = st.session_state.baseline_slider
        # Will trigger rerun which will recalculate baseline and peaks
        
    def update_percentile():
        old_settings = copy.deepcopy(st.session_state.settings)
        st.session_state.settings['percentile'] = st.session_state.percentile_slider
        recalculate_all_peaks(old_settings)
        
    def update_extension():
        old_settings = copy.deepcopy(st.session_state.settings)
        st.session_state.settings['extension_factor'] = st.session_state.extension_slider
        recalculate_all_peaks(old_settings)
    
    def update_markers():
        st.session_state.settings['show_peak_markers'] = st.session_state.marker_checkbox
    
    # Add sliders with callbacks
    st.slider('Signal-to-noise ratio', min_value=1.0, max_value=10.0, 
              value=st.session_state.settings['snr'], step=0.5,
              key="snr_slider", on_change=update_snr,
              help="Lower values detect more of the peak (2-3 recommended)")
    
    st.slider('Slope threshold (%)', min_value=0.5, max_value=20.0, 
              value=st.session_state.settings['slope_threshold'] * 100, step=0.5,
              key="slope_slider", on_change=update_slope,
              help="Lower values include more of the peak (1-3% recommended)")
    
    st.slider('Baseline iterations', min_value=10, max_value=200, 
              value=st.session_state.settings['baseline_iterations'], step=10,
              key="baseline_slider", on_change=update_baseline_iterations,
              help="More iterations for better baseline detection (50 recommended)")
    
    st.slider('Baseline percentile', min_value=1, max_value=20, 
              value=st.session_state.settings['percentile'], step=1,
              key="percentile_slider", on_change=update_percentile,
              help="Percentile used for baseline estimation (5 recommended)")
    
    st.slider('Boundary extension factor', min_value=1.0, max_value=3.0, 
              value=st.session_state.settings['extension_factor'], step=0.1,
              key="extension_slider", on_change=update_extension,
              help="How much to extend peak boundaries (1.5-2.0 recommended)")
    
    st.subheader("Visualization Settings")
    show_peak_markers = st.checkbox("Show peak markers (×)", 
                                   value=st.session_state.settings['show_peak_markers'],
                                   key="marker_checkbox", on_change=update_markers)

# Function to recalculate all peaks with current settings while preserving colors
def recalculate_all_peaks(old_settings=None):
    for chrom_id, peaks in st.session_state.selected_peaks.items():
        if peaks:
            # Store the original peaks
            original_peaks = copy.deepcopy(peaks)
            
            # Clear peaks and reuse the IDs
            temp_next_peak_id = st.session_state.next_peak_id
            st.session_state.selected_peaks[chrom_id] = []
            
            # Add recalculated peaks while preserving colors and names
            for peak in original_peaks:
                x_coord = peak['Midpoint (min)']
                
                # Extract color info to preserve it
                color_info = {
                    'color': peak['color'],
                    'color_hex': peak['color_hex'],
                    'opacity': peak['opacity'],
                    'user_changed_color': peak.get('user_changed_color', False)
                }
                
                # Detect peak with preserved color
                new_peak = detect_peak_near_click(x_coord, preserve_color=color_info, chrom_id=chrom_id)
                
                if new_peak:
                    # Keep the original ID and name
                    new_peak['id'] = peak['id']
                    new_peak['name'] = peak.get('name', f"Peak {peak['id']}")
                    st.session_state.selected_peaks[chrom_id].append(new_peak)
            
            # Restore the next_peak_id
            st.session_state.next_peak_id = temp_next_peak_id
    
# --- 6) Plot the chromatogram ---
fig = go.Figure()

# Add each visible chromatogram
for chrom_id, chrom_data in st.session_state.chromatograms.items():
    if chrom_data['visible']:
        # Get processed data
        proc_data = preprocessed_data[chrom_id]
        
        # Add the main chromatogram trace
        fig.add_trace(go.Scatter(
            x=proc_data['x'], 
            y=proc_data['y_smooth'], 
            mode="lines", 
            name=chrom_data['name'],
            line=dict(color=chrom_data['color'], width=2)
        ))
        
        # Add baseline
        fig.add_trace(go.Scatter(
            x=proc_data['x'], 
            y=proc_data['baseline'], 
            mode="lines", 
            name=f"{chrom_data['name']} Baseline",
            line=dict(color=chrom_data['color'], width=1, dash="dash"),
            showlegend=False
        ))
        
        # Add any previously selected peaks for this chromatogram
        if chrom_id in st.session_state.selected_peaks:
            for peak in st.session_state.selected_peaks[chrom_id]:
                start_idx = peak['Start Index']
                end_idx = peak['End Index']
                peak_idx = peak['peak_idx']
                
                # Add fill for the peak area with the peak's color
                x_fill = proc_data['x'][start_idx:end_idx+1]
                y_fill = proc_data['y_smooth'][start_idx:end_idx+1]
                
                fig.add_trace(go.Scatter(
                    x=x_fill, 
                    y=y_fill, 
                    fill='tozeroy', 
                    fillcolor=peak.get('color', "rgba(255, 99, 132, 0.4)"), 
                    line=dict(color=chrom_data['color'], width=1),
                    name=f"{chrom_data['name']} - {peak.get('name', 'Peak ' + str(peak['id']))}",
                    showlegend=True
                ))
                
                # Add peak marker (optional)
                if st.session_state.settings['show_peak_markers']:
                    fig.add_trace(go.Scatter(
                        x=[proc_data['x'][peak_idx]], 
                        y=[proc_data['y_smooth'][peak_idx]], 
                        mode="markers", 
                        marker=dict(color="red", size=10, symbol="x"),
                        name=f"{peak.get('name', f'Peak {peak['id']}')} Max",
                        showlegend=False
                    ))
                
                # Add vertical lines at boundaries
                fig.add_shape(
                    type="line",
                    x0=proc_data['x'][start_idx], y0=0, 
                    x1=proc_data['x'][start_idx], y1=proc_data['y_smooth'][peak_idx],
                    line=dict(color=chrom_data['color'], width=1, dash="dash")
                )
                
                fig.add_shape(
                    type="line",
                    x0=proc_data['x'][end_idx], y0=0, 
                    x1=proc_data['x'][end_idx], y1=proc_data['y_smooth'][peak_idx],
                    line=dict(color=chrom_data['color'], width=1, dash="dash")
                )

# Configure layout
fig.update_layout(
    title="Chromatogram Peak Detection",
    xaxis_title="Time (min)",
    yaxis_title="Signal (a.u.)",
    hovermode="closest",
    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    modebar=dict(orientation="v")
)

# Use st.plotly_chart with zoom options
st.plotly_chart(
    fig, 
    use_container_width=True,
    config={
        'displayModeBar': True,
        'scrollZoom': True,
        'modeBarButtonsToAdd': [
            'zoomIn2d',
            'zoomOut2d',
            'autoScale2d',
            'resetScale2d',
            'hoverClosestCartesian',
            'toggleSpikelines'
        ]
    }
)

# --- 7) Manual time input for peak selection ---
st.sidebar.header("Add Peak by Time")
st.sidebar.info("📌 Hover over a peak to see its time, then enter it here")
x_coord = st.sidebar.number_input("Time coordinate (min)", 
                                 min_value=float(preprocessed_data[active_chrom]['x'][0]), 
                                 max_value=float(preprocessed_data[active_chrom]['x'][-1]), 
                                 value=float(5.00),  # Default to main peak
                                 step=0.01,
                                 format="%.2f")

if st.sidebar.button("Add Peak"):
    new_peak = detect_peak_near_click(x_coord)
    
    if new_peak:
        # Check if we already have a peak very close to this one
        duplicate = False
        if active_chrom in st.session_state.selected_peaks:
            for existing_peak in st.session_state.selected_peaks[active_chrom]:
                if abs(existing_peak['Midpoint (min)'] - new_peak['Midpoint (min)']) < 0.1:
                    duplicate = True
                    st.sidebar.warning(f"A peak has already been selected at x = {new_peak['Midpoint (min)']:.2f}")
                    break
        
        if not duplicate:
            # Initialize the list for this chromatogram if it doesn't exist
            if active_chrom not in st.session_state.selected_peaks:
                st.session_state.selected_peaks[active_chrom] = []
                
            st.session_state.selected_peaks[active_chrom].append(new_peak)
            st.session_state.next_peak_id += 1
            st.sidebar.success(f"Peak detected at x = {new_peak['Midpoint (min)']:.2f}")
            st.rerun()

# --- 8) Auto-detect All Peaks ---
st.sidebar.header("Auto-detect All Peaks")

# Use a simpler approach for threshold that works with Streamlit's widget system
if active_chrom not in st.session_state.auto_thresholds:
    # Initialize with default threshold (5% of max)
    max_y = np.max(preprocessed_data[active_chrom]['y_corrected'])
    st.session_state.auto_thresholds[active_chrom] = float(max_y * 0.05)

# Create a unique key for each chromatogram's threshold slider
threshold_key = f"threshold_{active_chrom}"

# Display the slider with the stored value
max_value = float(np.max(preprocessed_data[active_chrom]['y_corrected']))
auto_threshold = st.sidebar.slider(
    "Peak Height Threshold", 
    min_value=0.0, 
    max_value=max_value, 
    value=st.session_state.auto_thresholds[active_chrom],
    format="%.2f",
    key=threshold_key
)

# Update stored threshold from the slider (Streamlit handles this automatically through the key)
st.session_state.auto_thresholds[active_chrom] = auto_threshold

# Add buttons for peak detection with columns for better layout
detect_cols = st.sidebar.columns(2)

with detect_cols[0]:
    if st.button("Detect All Peaks"):
        # Find all peaks above threshold
        y_corrected = preprocessed_data[active_chrom]['y_corrected']
        all_peaks, properties = find_peaks(y_corrected, height=auto_threshold)
        
        # Clear existing peaks for this chromatogram
        st.session_state.selected_peaks[active_chrom] = []
        
        # Add each detected peak
        for peak_idx in all_peaks:
            x_coord = preprocessed_data[active_chrom]['x'][peak_idx]
            new_peak = detect_peak_near_click(x_coord, search_radius=0.2)
            if new_peak:
                st.session_state.selected_peaks[active_chrom].append(new_peak)
                st.session_state.next_peak_id += 1
        
        if st.session_state.selected_peaks[active_chrom]:
            st.sidebar.success(f"Detected {len(st.session_state.selected_peaks[active_chrom])} peaks")
            st.rerun()
        else:
            st.sidebar.warning("No peaks detected with current threshold")

with detect_cols[1]:
    if st.button("Auto-Detect All Samples"):
        # Process each visible chromatogram
        total_peaks = 0
        for chrom_id, chrom_data in st.session_state.chromatograms.items():
            if chrom_data['visible']:
                # Get the threshold for this chromatogram
                if chrom_id not in st.session_state.auto_thresholds:
                    max_y = np.max(preprocessed_data[chrom_id]['y_corrected'])
                    threshold = float(max_y * 0.05)  # Default 5% of max
                else:
                    threshold = st.session_state.auto_thresholds[chrom_id]
                
                # Find all peaks above threshold
                y_corrected = preprocessed_data[chrom_id]['y_corrected']
                all_peaks, properties = find_peaks(y_corrected, height=threshold)
                
                # Clear existing peaks for this chromatogram
                st.session_state.selected_peaks[chrom_id] = []
                
                # Add each detected peak
                for peak_idx in all_peaks:
                    x_coord = preprocessed_data[chrom_id]['x'][peak_idx]
                    new_peak = detect_peak_near_click(x_coord, search_radius=0.2, chrom_id=chrom_id)
                    if new_peak:
                        st.session_state.selected_peaks[chrom_id].append(new_peak)
                        st.session_state.next_peak_id += 1
                        total_peaks += 1
        
        if total_peaks > 0:
            st.sidebar.success(f"Detected {total_peaks} peaks across all visible samples")
            st.rerun()
        else:
            st.sidebar.warning("No peaks detected with current thresholds")

# --- 7) Sample Results / Peak Results switch ---
results_tabs = ["Sample Results", "Peak Results"]
selected_tab = st.radio("View Results As:", results_tabs, horizontal=True, index=results_tabs.index(st.session_state.view_mode), key="results_view_mode")
# Update view mode through a callback to avoid Streamlit widget modification error
if selected_tab != st.session_state.view_mode:
    st.session_state.view_mode = selected_tab
    st.rerun()

# --- 8) Display Sample Results (under the plot) ---
if st.session_state.view_mode == "Sample Results":
    # Show peaks only for the active chromatogram
    active_chrom = st.session_state.active_chromatogram
    
    if active_chrom in st.session_state.selected_peaks and len(st.session_state.selected_peaks[active_chrom]) > 0:
        st.header(f"Sample Results: {st.session_state.chromatograms[active_chrom]['name']}", divider=True)
        
        # Create a clean version of the DataFrame for display (active sample-focused)
        sample_results = []
        
        # Calculate total area for this chromatogram
        total_area = sum(p.get('Area (a.u.·min)', 0) for p in st.session_state.selected_peaks[active_chrom])
        
        # Get available calibration models for quantification
        available_calibrations = {}
        if 'calibration_models' in st.session_state:
            available_calibrations = st.session_state.calibration_models
        
        for peak in st.session_state.selected_peaks[active_chrom]:
            # Basic peak properties
            result_row = {
                "Peak Name": peak.get('name', f"Peak {peak['id']}"),
                "Peak ID": peak['id'],
                "Midpoint (min)": peak['Midpoint (min)'],
                "Height (a.u.)": peak['Height (a.u.)'],
                "Area (a.u.·min)": peak['Area (a.u.·min)'],
                "Area %": (peak['Area (a.u.·min)'] / total_area) * 100 if total_area > 0 else 0,
                "Width (min)": peak['Width (min)'],
                "Width at Half-Height (min)": peak['Width at Half-Height (min)']
            }
            
            # Check if there's a calibration for this peak
            matching_cal = None
            for cal_id, cal_model in available_calibrations.items():
                if abs(peak['Midpoint (min)'] - cal_model['rt']) < 0.2:  # Within 0.2 min
                    matching_cal = cal_model
                    break
            
            # Add quantification if calibration exists
            if matching_cal:
                # Calculate concentration
                concentration = matching_cal['predict_concentration'](peak['Area (a.u.·min)'])
                
                # Add to results
                result_row["Calibration"] = matching_cal['name']
                result_row[f"Concentration ({matching_cal['units']})"] = concentration
            
            sample_results.append(result_row)
        
        if sample_results:
            df = pd.DataFrame(sample_results)
            st.dataframe(df)
            
            # Add download button
            csv = df.to_csv(index=False)
            st.download_button(
                label=f"Download Results for {st.session_state.chromatograms[active_chrom]['name']} as CSV",
                data=csv,
                file_name=f"sample_{active_chrom}_results.csv",
                mime="text/csv",
            )






















# --- 9) Display Peak Results (comparison across samples) ---
else:  # Peak Results view mode
    if any(len(peaks) > 0 for peaks in st.session_state.selected_peaks.values()):
        st.header("Peak Results - Compare Across Samples", divider=True)
        
        
        # Set a time window for matching peaks (in minutes)
        time_window = st.slider(
            "Peak Matching Time Window (min)", 
            min_value=0.05, 
            max_value=1.0, 
            value=0.2,  # Default to 0.2 min (12 seconds)
            step=0.05,
            help="Peaks with midpoints closer than this value will be considered the same compound across samples"
        )
        
        # Collect all peaks from all chromatograms
        all_peaks = []
        for chrom_id, peaks in st.session_state.selected_peaks.items():
            for peak in peaks:
                peak_info = {
                    'chromatogram_id': chrom_id,
                    'chromatogram_name': st.session_state.chromatograms[chrom_id]['name'],
                    'peak_id': peak['id'],
                    'peak_name': peak.get('name', f"Peak {peak['id']}"),
                    'midpoint': peak['Midpoint (min)'],
                    'height': peak['Height (a.u.)'],
                    'area': peak['Area (a.u.·min)'],
                    'width': peak['Width (min)'],
                    'width_hh': peak['Width at Half-Height (min)']
                }
                all_peaks.append(peak_info)
        
        # Sort all peaks by midpoint time
        all_peaks.sort(key=lambda p: p['midpoint'])
        
        # Group peaks by proximity (considering them the same compound)
        peak_groups = []
        current_group = []
        
        for peak in all_peaks:
            if not current_group:
                current_group = [peak]
            else:
                # Check if this peak is close to the ones in the current group
                avg_midpoint = sum(p['midpoint'] for p in current_group) / len(current_group)
                if abs(peak['midpoint'] - avg_midpoint) <= time_window:
                    # This peak is close enough, add to current group
                    current_group.append(peak)
                else:
                    # Start a new group
                    peak_groups.append(current_group)
                    current_group = [peak]
        
        # Add the last group if it exists
        if current_group:
            peak_groups.append(current_group)
        
        # Filter out groups with only one peak (no comparison possible)
        comparison_groups = [group for group in peak_groups if len(group) > 1]
        single_peaks = [group[0] for group in peak_groups if len(group) == 1]
        
        # Display a selector for the peak groups
        if comparison_groups:
            # Create a readable name for each peak group
            group_names = []
            for i, group in enumerate(comparison_groups):
                avg_time = sum(p['midpoint'] for p in group) / len(group)
                samples = sorted(set(p['chromatogram_name'] for p in group))
                samples_str = ', '.join(samples)
                group_names.append(f"Group {i+1}: {avg_time:.2f} min - Found in {len(group)} samples ({samples_str})")
            
            # Let user select which group to compare
            selected_group_idx = st.selectbox(
                "Select Peak Group to Compare",
                options=range(len(comparison_groups)),
                format_func=lambda i: group_names[i]
            )
            
            selected_group = comparison_groups[selected_group_idx]
            
            # Get all chromatogram IDs that have samples
            all_chrom_ids = sorted(st.session_state.chromatograms.keys())
            
            # Create comparison table
            comparison_data = []
            
            # Get available calibration models for quantification
            available_calibrations = {}
            if 'calibration_models' in st.session_state:
                available_calibrations = st.session_state.calibration_models
            
            # Check if there's a calibration for this peak group
            matching_cal = None
            for cal_id, cal_model in available_calibrations.items():
                if abs(selected_group[0]['midpoint'] - cal_model['rt']) < 0.2:  # Within 0.2 min
                    matching_cal = cal_model
                    break
            
            for chrom_id in all_chrom_ids:
                if chrom_id not in st.session_state.chromatograms:
                    continue
                
                chrom_name = st.session_state.chromatograms[chrom_id]['name']
                
                # Find a peak from this chromatogram in the selected group
                matching_peak = next((p for p in selected_group if p['chromatogram_id'] == chrom_id), None)
                
                if matching_peak:
                    # Calculate the total area for this chromatogram for percentage
                    total_area = sum(p.get('Area (a.u.·min)', 0) for p in st.session_state.selected_peaks[chrom_id])
                    
                    comparison_row = {
                        "Sample": chrom_name,
                        "Peak Name": matching_peak['peak_name'],
                        "Midpoint (min)": matching_peak['midpoint'],
                        "Height (a.u.)": matching_peak['height'],
                        "Area (a.u.·min)": matching_peak['area'],
                        "Area %": (matching_peak['area'] / total_area) * 100 if total_area > 0 else 0,
                        "Width (min)": matching_peak['width'],
                        "Width at Half-Height (min)": matching_peak['width_hh']
                    }
                    
                    # Add quantification if calibration exists
                    if matching_cal:
                        # Calculate concentration
                        concentration = matching_cal['predict_concentration'](matching_peak['area'])
                        
                        # Add to comparison data
                        comparison_row["Calibration"] = matching_cal['name']
                        comparison_row[f"Concentration ({matching_cal['units']})"] = concentration
                    
                    comparison_data.append(comparison_row)
                else:
                    # Add an empty row for this chromatogram
                    comparison_row = {
                        "Sample": chrom_name,
                        "Peak Name": "Not detected",
                        "Midpoint (min)": None,
                        "Height (a.u.)": None,
                        "Area (a.u.·min)": None,
                        "Area %": None,
                        "Width (min)": None,
                        "Width at Half-Height (min)": None
                    }
                    
                    # Add placeholder for calibration info
                    if matching_cal:
                        comparison_row["Calibration"] = matching_cal['name']
                        comparison_row[f"Concentration ({matching_cal['units']})"] = None
                    
                    comparison_data.append(comparison_row)
            
            if comparison_data:
                # Display the data
                df = pd.DataFrame(comparison_data)
                st.dataframe(df)
                
                # Add download button
                csv = df.to_csv(index=False)
                st.download_button(
                    label=f"Download Comparison for Group {selected_group_idx+1} as CSV",
                    data=csv,
                    file_name=f"peak_group_{selected_group_idx+1}_comparison.csv",
                    mime="text/csv",
                )
        
        else:
            st.info("No matching peaks found across different samples. Try adjusting the time window or adding more peaks.")
            if single_peaks:
                st.write(f"Found {len(single_peaks)} peaks that only appear in one sample.")
                
                # Show the single peaks
                single_data = []
                for peak in single_peaks:
                    single_data.append({
                        "Sample": peak['chromatogram_name'],
                        "Peak Name": peak['peak_name'],
                        "Midpoint (min)": peak['midpoint']
                    })
                
                st.dataframe(pd.DataFrame(single_data))

# --- 10) Edit peak properties ---
if any(len(peaks) > 0 for peaks in st.session_state.selected_peaks.values()):
    with st.expander("Peak Properties", expanded=False):
        # First, get all unique peak IDs across all chromatograms
        all_peaks = []
        for chrom_id, peaks in st.session_state.selected_peaks.items():
            for peak in peaks:
                # Add chromatogram ID to each peak for reference
                peak_with_chrom = peak.copy()
                peak_with_chrom['chromatogram_id'] = chrom_id
                all_peaks.append(peak_with_chrom)
        
        # Sort peaks by ID
        all_peaks.sort(key=lambda p: p['id'])
        
        # Create tabs for each peak
        if all_peaks:
            tab_labels = [f"{p.get('name', f'Peak {p["id"]}')}" for p in all_peaks]
            peak_tabs = st.tabs(tab_labels)
            
            for i, (peak, tab) in enumerate(zip(all_peaks, peak_tabs)):
                with tab:
                    chrom_id = peak['chromatogram_id']
                    chrom_name = st.session_state.chromatograms[chrom_id]['name']
                    
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.write(f"**Sample:** {chrom_name}")
                        st.write(f"**Midpoint:** {peak['Midpoint (min)']:.2f} min")
                        st.write(f"**Height:** {peak['Height (a.u.)']:.1f} a.u.")
                        st.write(f"**Width:** {peak['Width (min)']:.4f} min")
                        st.write(f"**Width at Half-Height:** {peak['Width at Half-Height (min)']:.4f} min")
                        
                        # Peak name editing
                        new_peak_name = st.text_input(
                            "Peak Name", 
                            value=peak.get('name', f"Peak {peak['id']}"),
                            key=f"name_{peak['id']}_{chrom_id}"
                        )
                        
                        if new_peak_name != peak.get('name', f"Peak {peak['id']}"):
                            # Find the actual peak in the session state and update it
                            for p in st.session_state.selected_peaks[chrom_id]:
                                if p['id'] == peak['id']:
                                    p['name'] = new_peak_name
                                    break
                            st.rerun()
                        
                        # Peak color picker (hex format) + opacity slider
                        color_hex = st.color_picker(
                            "Fill Color", 
                            peak.get('color_hex', "#ff6384"),
                            key=f"color_picker_{peak['id']}_{chrom_id}"
                        )
                        
                        opacity = st.slider(
                            "Fill Opacity", 
                            min_value=0.0, 
                            max_value=1.0, 
                            value=peak.get('opacity', 0.4),
                            step=0.1,
                            key=f"opacity_{peak['id']}_{chrom_id}"
                        )
                        
                        # Convert hex to rgba 
                        r = int(color_hex[1:3], 16)
                        g = int(color_hex[3:5], 16)
                        b = int(color_hex[5:7], 16)
                        rgba_color = f"rgba({r}, {g}, {b}, {opacity})"
                        
                        # Update peak color if changed
                        if rgba_color != peak.get('color', "") or color_hex != peak.get('color_hex', ""):
                            # Find the actual peak in the session state and update it
                            for p in st.session_state.selected_peaks[chrom_id]:
                                if p['id'] == peak['id']:
                                    p['color'] = rgba_color
                                    p['color_hex'] = color_hex
                                    p['opacity'] = opacity
                                    p['user_changed_color'] = True
                                    break
                            st.rerun()
                    
                    with col2:
                        # Show boundaries
                        st.write(f"**Boundaries:** {peak['Min Time (min)']:.2f} min to {peak['Max Time (min)']:.2f} min")
                        
                        # Display area
                        area = peak.get('Area (a.u.·min)', 0)
                        st.metric("Area", f"{area:.2f} a.u.·min")
                        
                        # Calculate % of total area for this chromatogram
                        if chrom_id in st.session_state.selected_peaks:
                            total_area = sum(p.get('Area (a.u.·min)', 0) for p in st.session_state.selected_peaks[chrom_id])
                            if total_area > 0:
                                percent = (area / total_area) * 100
                                st.metric("% of Total", f"{percent:.1f}%")
                        
                        # Add a delete button
                        if st.button(f"Delete Peak", key=f"delete_{peak['id']}_{chrom_id}"):
                            # Find and remove the peak from the session state
                            for idx, p in enumerate(st.session_state.selected_peaks[chrom_id]):
                                if p['id'] == peak['id']:
                                    st.session_state.selected_peaks[chrom_id].pop(idx)
                                    break
                            st.success(f"Peak removed")
                            st.rerun()

# Add a "Clear All Peaks" button
if any(len(peaks) > 0 for peaks in st.session_state.selected_peaks.values()):
    if st.button("Clear All Peaks"):
        # Clear peaks for all chromatograms
        for chrom_id in st.session_state.selected_peaks:
            st.session_state.selected_peaks[chrom_id] = []
        st.session_state.next_peak_id = 0
        st.success("All peaks cleared")
        st.rerun()













# Add a section for calibration curves (visible in both view modes)
st.header("Calibration & Quantification", divider=True)

# Tabs for different calibration functions
cal_tabs = st.tabs(["Calibration Setup", "Calibration Curves", "Export/Import"])

    # Tab 1: Calibration Setup
with cal_tabs[0]:
    st.write("Set up calibration standards by assigning concentrations to peaks in samples.")
    
    # Get all peak groups for selection
    peak_groups = []
    group_names = []
    
    # Only attempt to find groups if we have some peaks
    if any(len(peaks) > 0 for peaks in st.session_state.selected_peaks.values()):
        # Collect all peaks 
        all_peaks = []
        for chrom_id, peaks in st.session_state.selected_peaks.items():
            for peak in peaks:
                peak_info = {
                    'chromatogram_id': chrom_id,
                    'chromatogram_name': st.session_state.chromatograms[chrom_id]['name'],
                    'peak_id': peak['id'],
                    'peak_name': peak.get('name', f"Peak {peak['id']}"),
                    'midpoint': peak['Midpoint (min)'],
                    'area': peak['Area (a.u.·min)'],
                }
                all_peaks.append(peak_info)
        
        # Sort all peaks by midpoint time
        all_peaks.sort(key=lambda p: p['midpoint'])
        
        # Default time window for matching peaks - can be made adjustable if needed
        time_window = 0.2  # Default is 0.2 min (12 seconds)
        
        # Group peaks by proximity (considering them the same compound)
        current_group = []
        
        for peak in all_peaks:
            if not current_group:
                current_group = [peak]
            else:
                # Check if this peak is close to the ones in the current group
                avg_midpoint = sum(p['midpoint'] for p in current_group) / len(current_group)
                if abs(peak['midpoint'] - avg_midpoint) <= time_window:
                    # This peak is close enough, add to current group
                    current_group.append(peak)
                else:
                    # Start a new group
                    peak_groups.append(current_group)
                    current_group = [peak]
        
        # Add the last group if it exists
        if current_group:
            peak_groups.append(current_group)
        
        # Create readable names for each peak group
        for i, group in enumerate(peak_groups):
            avg_time = sum(p['midpoint'] for p in group) / len(group)
            
            # Use consistent peak name if all peaks in the group have the same name
            peak_names = set(p['peak_name'] for p in group)
            if len(peak_names) == 1:
                group_name = next(iter(peak_names))
            else:
                # Otherwise use generic name with retention time
                group_name = f"Peak Group at {avg_time:.2f} min"
            
            group_names.append(group_name)
    
    # Select a peak group for calibration
    if group_names:
        # Add option for "Select a peak group..."
        group_options = ["Select a peak group..."] + group_names
        
        selected_group_name = st.selectbox(
            "Peak Group for Calibration",
            options=group_options
        )
        
        if selected_group_name != "Select a peak group...":
            # Get the index of the selected group
            group_idx = group_names.index(selected_group_name)
            selected_group = peak_groups[group_idx]
            
            # Display the samples in this group
            st.write("**Samples containing this peak:**")
            for peak in selected_group:
                st.write(f"- {peak['chromatogram_name']} (RT: {peak['midpoint']:.2f} min, Area: {peak['area']:.2f} a.u.·min)")
            
            # Create a unique ID for this group based on average retention time
            avg_rt = sum(p['midpoint'] for p in selected_group) / len(selected_group)
            group_id = f"group_{avg_rt:.2f}"
            
            # Set up the calibration for this group
            st.write("---")
            st.write("**Calibration Settings**")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Model type selection
                model_type = st.radio(
                    "Calibration Model", 
                    ["Linear", "Quadratic", "Power Law"],
                    index=["Linear", "Quadratic", "Power Law"].index(
                        st.session_state.calibration_data.get('model_type', 'Linear').capitalize()
                    )
                )
                
                # Update model type in session state
                st.session_state.calibration_data['model_type'] = model_type.lower()
                
                # Force through zero option
                force_zero = st.checkbox(
                    "Force through zero", 
                    value=st.session_state.calibration_data.get('force_zero', False)
                )
                
                # Update force_zero in session state
                st.session_state.calibration_data['force_zero'] = force_zero
                
                # Show the formula based on selected model
                st.write("**Model Equation:**")
                if model_type == "Linear":
                    formula = "y = mx + b" if not force_zero else "y = mx"
                elif model_type == "Quadratic":
                    formula = "y = ax² + bx + c" if not force_zero else "y = ax² + bx"
                else:  # Power Law
                    formula = "y = ax^b"
                
                st.write(f"_{formula}_")
                
                # Add calibration name input field
                cal_name = st.text_input(
                    "Calibration Name", 
                    value=st.session_state.calibration_data.get('standards', {}).get(group_id, {}).get('name', selected_group_name),
                    key=f"cal_name_{group_id}"
                )
                
                # Concentration units selection
                units = st.selectbox(
                    "Concentration Units", 
                    ["µg/mL", "ng/mL", "µM", "nM", "mg/L"],
                    index=["µg/mL", "ng/mL", "µM", "nM", "mg/L"].index(
                        st.session_state.calibration_data.get('units', 'µg/mL')
                    )
                )
                
                # Update units in session state
                st.session_state.calibration_data['units'] = units
            
            with col2:
                # Initialize the standards for this group if not present
                if group_id not in st.session_state.calibration_data['standards']:
                    st.session_state.calibration_data['standards'][group_id] = {'name': cal_name}
                else:
                    st.session_state.calibration_data['standards'][group_id]['name'] = cal_name
                
                # Sample assignment - which samples are standards and their concentrations
                st.write("**Assign Standard Concentrations:**")
                
                # For each chromatogram in the group, allow setting a standard concentration
                for peak in selected_group:
                    chrom_id = peak['chromatogram_id']
                    chrom_name = peak['chromatogram_name']
                    
                    # Check if we already have a concentration for this chromatogram
                    default_value = ""
                    if str(chrom_id) in st.session_state.calibration_data['standards'][group_id]:
                        default_value = str(st.session_state.calibration_data['standards'][group_id][str(chrom_id)])
                    
                    # Input field for concentration
                    conc_str = st.text_input(
                        f"Concentration for {chrom_name} ({units})", 
                        value=default_value,
                        key=f"conc_{group_id}_{chrom_id}"
                    )
                    
                    # Update the concentration in the session state
                    try:
                        if conc_str:
                            conc = float(conc_str)
                            st.session_state.calibration_data['standards'][group_id][str(chrom_id)] = conc
                        else:
                            # If the field is empty, remove this chromatogram from standards
                            if str(chrom_id) in st.session_state.calibration_data['standards'][group_id]:
                                del st.session_state.calibration_data['standards'][group_id][str(chrom_id)]
                    except ValueError:
                        st.error(f"Please enter a valid number for {chrom_name}")
            
            # Button to generate or update the calibration curve
            if st.button("Generate Calibration Curve", key=f"gen_cal_{group_id}"):
                # Get only the concentration values (skip the 'name' field)
                valid_standards = {k: v for k, v in st.session_state.calibration_data['standards'][group_id].items() 
                                if k != 'name' and isinstance(v, (int, float))}
                
                # Check if we have enough data points
                if len(valid_standards) < 2:
                    st.error("Please assign concentrations to at least 2 samples.")
                elif model_type == "Quadratic" and len(valid_standards) < 3 and not force_zero:
                    st.error("Quadratic fit requires at least 3 points (or 2 points with 'Force through zero').")
                else:
                    st.success(f"Calibration curve generated for {cal_name}. View it in the 'Calibration Curves' tab.")
                    st.rerun()
    else:
            st.info("No peak groups found. Add peaks to multiple samples first.")
    
    






################################





    # Tab 2: Calibration Curves
    # Tab 2: Calibration Curves
    with cal_tabs[1]:
        st.write("View and use calibration curves for quantification.")
        
        # Check if we have any calibration data
        has_standards = len(st.session_state.calibration_data.get('standards', {})) > 0
        has_models = len(st.session_state.calibration_models) > 0
        
        if not has_standards and not has_models:
            st.info("No calibration curves have been set up yet. Go to the 'Calibration Setup' tab to create one or import existing curves.")
        else:
            # List all calibrated peak groups
            calibrated_groups = []
            
            # First, add any models that exist in calibration_models
            for group_id, model in st.session_state.calibration_models.items():
                calibrated_groups.append({
                    'id': group_id,
                    'name': model['name'],
                    'rt': model['rt'],
                    'type': 'model',  # Mark as a model type
                    'model': model    # Store the full model
                })
            
            # Then check for standard sets that might need calculation
            if has_standards:
                for group_id, standards_data in st.session_state.calibration_data['standards'].items():
                    # Skip if we already have a model for this group
                    if group_id in st.session_state.calibration_models:
                        continue
                        
                    # Skip entries that don't have concentration values (only have name)
                    concentration_values = {k: v for k, v in standards_data.items() 
                                        if k != 'name' and isinstance(v, (int, float))}
                    
                    if len(concentration_values) >= 2:  # Only include groups with at least 2 standards
                        # Extract average retention time from group_id
                        try:
                            avg_rt = float(group_id.split('_')[1])
                            
                            # Find a matching peak group by retention time
                            matching_group = None
                            for i, group in enumerate(peak_groups):
                                group_avg_rt = sum(p['midpoint'] for p in group) / len(group)
                                if abs(group_avg_rt - avg_rt) < 0.01:  # Within 0.01 min
                                    matching_group = group
                                    break
                            
                            if matching_group:
                                # Use the custom name or group name
                                display_name = standards_data.get('name', group_names[peak_groups.index(matching_group)])
                                
                                calibrated_groups.append({
                                    'id': group_id,
                                    'name': display_name,
                                    'rt': avg_rt,
                                    'type': 'standards',  # Mark as standards type
                                    'standards': concentration_values,
                                    'matching_group': matching_group
                                })
                        except (IndexError, ValueError):
                            # Skip groups with invalid IDs
                            pass
            
            if not calibrated_groups:
                st.info("No complete calibration curves found. Make sure to assign at least 2 concentration values in the 'Calibration Setup' tab or import calibration data.")
            else:
                # Select a calibration curve to view
                cal_options = [g['name'] for g in calibrated_groups]
                selected_cal = st.selectbox("Select Calibration Curve", options=cal_options)
                
                # Find the selected calibration group
                selected_cal_group = next(g for g in calibrated_groups if g['name'] == selected_cal)
                
                # Add a toggle for showing current chromatogram points
                show_current_points = st.checkbox("Show current chromatogram points on curve", value=True)
                
                # Get the group ID
                group_id = selected_cal_group['id']
                
                # Display the calibration curve
                st.subheader("Calibration Curve")
                
                # Create plot
                fig = go.Figure()
                
                # Get all possible calibration standard points
                cal_x_data = []
                cal_y_data = []
                cal_sample_names = []

                # Add to data for R² calculation (only standards)
                x_values    = []   # for R²: actual concentrations
                y_values    = []   # for R²: actual areas
                y_predicted = [] # for R²: expected areas      
                
                if selected_cal_group['type'] == 'model':
                    model = selected_cal_group['model']
                    predict_area = model.get('predict_area', lambda x: x)
                    predict_concentration = model.get('predict_concentration', lambda x: x)
                    
                    # Extract all standards data for this model
                    standards = {}
                    
                    # First check if standards exist directly in the model
                    if 'standards' in model and model['standards']:
                        standards.update(model['standards'])
                    
                    # Also check in the calibration_data standards
                    if group_id in st.session_state.calibration_data.get('standards', {}):
                        std_data = st.session_state.calibration_data['standards'][group_id]
                        # Extract only the concentration values (exclude 'name' field)
                        standards.update({k: v for k, v in std_data.items() if k != 'name' and isinstance(v, (int, float))})
                    
                    # Recalculate R² from standards data points
                    if len(standards) >= 2:
                        # Get concentration values
                        conc_values = [float(standards[k]) for k in standards if k != 'name' and isinstance(standards[k], (int, float))]
                        
                        # Recalculate R² based on actual concentration values and model prediction
                        r_squared = calculate_r_squared_from_standards(conc_values, predict_area)
                    else:
                        # If insufficient data, use the stored value
                        r_squared = model.get('r_squared', 1.0)
                    
                    for sample_id, concentration in standards.items():
                        if isinstance(concentration, (int, float)):
                            # Calculate expected area based on the model
                            expected_area = predict_area(concentration)
                            
                            # Try to find the actual area from a matching peak if available
                            area_found = False
                            
                            try:
                                # Check if this is a chromatogram ID in our current session
                                chrom_id = int(sample_id)
                                if chrom_id in st.session_state.chromatograms:
                                    chrom_name = st.session_state.chromatograms[chrom_id]['name']
                                    
                                    # Look for a peak in this chromatogram that matches the RT
                                    if chrom_id in st.session_state.selected_peaks:
                                        for peak in st.session_state.selected_peaks[chrom_id]:
                                            if abs(peak['Midpoint (min)'] - model['rt']) < 0.2:
                                                # Use the actual measured area
                                                actual_area = peak['Area (a.u.·min)']
                                                
                                                # Add to data for plotting
                                                cal_x_data.append(concentration)
                                                cal_y_data.append(actual_area)
                                                cal_sample_names.append(f"{chrom_name} (standard)")
                                                 
                                            
        
                                                x_values.append(concentration)
                                                y_values.append(actual_area)
                                                y_predicted.append(expected_area)
                                                
                                                area_found = True
                                                break
                            except (ValueError, TypeError):
                                # Not a valid chromatogram ID or peak not found
                                pass
                            
                            # If we couldn't find actual area data, use the model values
                            if not area_found:
                                # Add to data for plotting
                                cal_x_data.append(concentration)
                                cal_y_data.append(expected_area)
                                
                                # Create a sample name
                                if isinstance(sample_id, str) and sample_id.isdigit() and int(sample_id) in st.session_state.chromatograms:
                                    sample_name = st.session_state.chromatograms[int(sample_id)]['name']
                                else:
                                    sample_name = f"Standard {sample_id}"
                                cal_sample_names.append(f"{sample_name} (from model)")
                                
                                # Note: We don't use these in R² calculation since they're model-generated
                    
                    # Calculate R² ONLY from true standards, not from model-derived values
                    if len(x_values) >= 2:
                        # Convert to numpy arrays
                        y_true = np.array(y_values)
                        y_pred = np.array(y_predicted)
                        
                        # Calculate R² only if there's variation in the data
                        if len(np.unique(y_true)) > 1:
                            ss_tot = np.sum((y_true - np.mean(y_true))**2)
                            ss_res = np.sum((y_true - y_pred)**2)
                            
                            if ss_tot > 0:
                                r_squared = 1 - (ss_res / ss_tot)
                                std_error = np.sqrt(ss_res / (len(y_true) - 2)) if len(y_true) > 2 else 0
                            else:
                                # Use the model's original R² if we can't calculate
                                r_squared = model.get('r_squared', 1.0)
                                std_error = model.get('std_error', 0)
                        else:
                            # Use model's original values if no variation in data
                            r_squared = model.get('r_squared', 1.0)
                            std_error = model.get('std_error', 0)
                    else:
                        # Not enough data points for R² calculation
                        r_squared = model.get('r_squared', 1.0)
                        std_error = model.get('std_error', 0)
                    
                    # Get model parameters and statistics
                    model_type = model.get('model_type', 'linear')
                    force_zero = model.get('force_zero', False)
                    units = model.get('units', 'µg/mL')
                    formula_text = model.get('formula', '').replace("y =", "Area =").replace("x", "Concentration")
                    
                    # Create x values for the curve
                    if cal_x_data:
                        x_curve = np.linspace(0, max(cal_x_data) * 1.1, 100)
                    else:
                        x_curve = np.linspace(0, 10, 100)  # Default range
                    
                    # Generate y values
                    y_curve = np.array([predict_area(x) for x in x_curve])




















                else:
                    # Need to calculate the model from standards
                    standards = selected_cal_group['standards']
                    
                    # Get model settings from global settings
                    model_type = st.session_state.calibration_data['model_type']
                    force_zero = st.session_state.calibration_data['force_zero']
                    units = st.session_state.calibration_data['units']
                    
                    # Create x and y data for calibration plot
                    x_data = []
                    y_data = []
                    sample_names = []
                    
                    for chrom_id, concentration in standards.items():
                        if int(chrom_id) in st.session_state.chromatograms:
                            # Find the peak in this chromatogram that belongs to the group
                            matching_peak = None
                            for peak in st.session_state.selected_peaks.get(int(chrom_id), []):
                                # Check if peak is close to the group's retention time
                                if abs(peak['Midpoint (min)'] - selected_cal_group['rt']) < 0.2:
                                    matching_peak = peak
                                    break
                            
                            if matching_peak:
                                x_data.append(concentration)
                                y_data.append(matching_peak['Area (a.u.·min)'])
                                sample_names.append(st.session_state.chromatograms[int(chrom_id)]['name'])
                    
                    # Sort by concentration
                    sorted_data = sorted(zip(x_data, y_data, sample_names))
                    x_data = [d[0] for d in sorted_data]
                    y_data = [d[1] for d in sorted_data]
                    sample_names = [d[2] for d in sorted_data]
                    
                    # Use these points for the plot
                    cal_x_data = x_data
                    cal_y_data = y_data
                    cal_sample_names = sample_names
                    
                    # Fit the calibration model
                    if x_data and y_data:
                        x_array = np.array(x_data)
                        y_array = np.array(y_data)
                        
                        # For smooth curve plotting
                        x_curve = np.linspace(0, max(x_data) * 1.1, 100)
                        
                        if model_type == 'linear':
                            if force_zero:
                                # Force through zero: y = mx
                                slope = np.sum(x_array * y_array) / np.sum(x_array * x_array)
                                intercept = 0
                                r_squared = 1 - np.sum((y_array - slope * x_array)**2) / np.sum((y_array - np.mean(y_array))**2)
                                
                                # Function to predict concentration from area
                                def predict_concentration(area):
                                    return area / slope
                                
                                # Function to predict area from concentration
                                def predict_area(concentration):
                                    return slope * concentration
                                
                                y_curve = predict_area(x_curve)
                                model_label = f"y = {slope:.4g}x"
                                formula_text = f"Area = {slope:.4g} × Concentration"
                                std_error = np.sqrt(np.sum((y_array - slope * x_array)**2) / (len(x_array) - 1))
                            else:
                                # Standard linear regression using numpy polyfit
                                coeffs = np.polyfit(x_array, y_array, 1)
                                slope = coeffs[0]
                                intercept = coeffs[1]
                                
                                # Calculate R-squared
                                y_pred = slope * x_array + intercept
                                ss_tot = np.sum((y_array - np.mean(y_array))**2)
                                ss_res = np.sum((y_array - y_pred)**2)
                                r_squared = 1 - (ss_res / ss_tot)
                                std_error = np.sqrt(ss_res / (len(x_array) - 2))
                                
                                # Function to predict concentration from area
                                def predict_concentration(area):
                                    return (area - intercept) / slope if slope != 0 else 0

                                # Function to predict area from concentration
                                def predict_area(concentration):
                                    return slope * concentration + intercept

                                y_curve = predict_area(x_curve)
                                model_label = f"y = {slope:.4g}x + {intercept:.4g}"
                                formula_text = f"Area = {slope:.4g} × Concentration + {intercept:.4g}"
                        
                        elif model_type == 'quadratic':
                            if force_zero:
                                # Force through zero: y = ax² + bx
                                def quad_fit_zero(x, a, b):
                                    return a * x**2 + b * x
                                
                                # Fit quadratic model through (0,0)
                                params, _ = curve_fit(quad_fit_zero, x_array, y_array)
                                a, b = params
                                
                                # Predict values
                                y_pred = quad_fit_zero(x_array, a, b)
                                
                                # Calculate R²
                                ss_tot = np.sum((y_array - np.mean(y_array))**2)
                                ss_res = np.sum((y_array - y_pred)**2)
                                r_squared = 1 - (ss_res / ss_tot)
                                std_error = np.sqrt(ss_res / (len(x_array) - 2))
                                
                                # Function to predict area from concentration
                                def predict_area(concentration):
                                    return a * concentration**2 + b * concentration
                                
                                # Function to predict concentration from area (requires solving quadratic equation)
                                def predict_concentration(area):
                                    # Using quadratic formula: ax² + bx - area = 0
                                    if a == 0:  # Avoid division by zero
                                        return area / b if b != 0 else 0
                                    
                                    # Quadratic formula: x = (-b ± sqrt(b² - 4ac)) / 2a
                                    # where c = -area
                                    discriminant = b**2 + 4 * a * area
                                    if discriminant < 0:
                                        return 0  # No real solution
                                    
                                    # We take the positive root (assuming concentration is positive)
                                    conc = (-b + np.sqrt(discriminant)) / (2 * a)
                                    return conc
                                    
                                y_curve = predict_area(x_curve)
                                model_label = f"y = {a:.4g}x² + {b:.4g}x"
                                formula_text = f"Area = {a:.4g} × Concentration² + {b:.4g} × Concentration"
                            else:
                                # Full quadratic: y = ax² + bx + c
                                def quad_fit(x, a, b, c):
                                    return a * x**2 + b * x + c
                                
                                # Initial parameter guess
                                init_guess = [0, 1, 0]
                                
                                # Fit quadratic model
                                params, _ = curve_fit(quad_fit, x_array, y_array, p0=init_guess)
                                a, b, c = params
                                
                                # Predict values
                                y_pred = quad_fit(x_array, a, b, c)
                                
                                # Calculate R²
                                ss_tot = np.sum((y_array - np.mean(y_array))**2)
                                ss_res = np.sum((y_array - y_pred)**2)
                                r_squared = 1 - (ss_res / ss_tot)
                                std_error = np.sqrt(ss_res / (len(x_array) - 2))
                                
                                # Function to predict area from concentration
                                def predict_area(concentration):
                                    return a * concentration**2 + b * concentration + c
                                
                                # Function to predict concentration from area (requires solving quadratic equation)
                                def predict_concentration(area):
                                    # Using quadratic formula: ax² + bx + (c - area) = 0
                                    if a == 0:  # If a is zero, it's a linear equation
                                        return (area - c) / b if b != 0 else 0
                                    
                                    # Quadratic formula: x = (-b ± sqrt(b² - 4a(c - area))) / 2a
                                    discriminant = b**2 - 4 * a * (c - area)
                                    if discriminant < 0:
                                        return 0  # No real solution
                                    
                                    # We take the positive root (assuming concentration is positive)
                                    conc1 = (-b + np.sqrt(discriminant)) / (2 * a)
                                    conc2 = (-b - np.sqrt(discriminant)) / (2 * a)
                                    
                                    # Choose the smallest positive concentration
                                    if conc1 > 0 and conc2 > 0:
                                        return min(conc1, conc2)
                                    elif conc1 > 0:
                                        return conc1
                                    elif conc2 > 0:
                                        return conc2
                                    else:
                                        return 0  # No positive solution
                                
                                y_curve = predict_area(x_curve)
                                model_label = f"y = {a:.4g}x² + {b:.4g}x + {c:.4g}"
                                formula_text = f"Area = {a:.4g} × Concentration² + {b:.4g} × Concentration + {c:.4g}"
                        
                        elif model_type == 'power law':
                            # Power law: y = a * x^b
                            def power_law(x, a, b):
                                return a * x**b
                            
                            # Log transform for initial guess
                            log_x = np.log(x_array)
                            log_y = np.log(y_array)
                            slope, intercept, r_value, p_value, std_err = stats.linregress(log_x, log_y)
                            init_a = np.exp(intercept)
                            init_b = slope
                            
                            # Fit power law model
                            params, _ = curve_fit(power_law, x_array, y_array, p0=[init_a, init_b])
                            a, b = params
                            
                            # Predict values
                            y_pred = power_law(x_array, a, b)
                            
                            # Calculate R²
                            ss_tot = np.sum((y_array - np.mean(y_array))**2)
                            ss_res = np.sum((y_array - y_pred)**2)
                            r_squared = 1 - (ss_res / ss_tot)
                            std_error = np.sqrt(ss_res / (len(x_array) - 2))
                            
                            # Function to predict area from concentration
                            def predict_area(concentration):
                                return a * concentration**b
                            
                            # Function to predict concentration from area
                            def predict_concentration(area):
                                return (area / a)**(1 / b) if a != 0 and b != 0 else 0
                            
                            y_curve = predict_area(x_curve)
                            model_label = f"y = {a:.4g}x^{b:.4g}"
                            formula_text = f"Area = {a:.4g} × Concentration^{b:.4g}"

                        # Store the calibration model in session state for later use in quantification
                        if 'calibration_models' not in st.session_state:
                            st.session_state.calibration_models = {}

                        # Store the model in session state
                        st.session_state.calibration_models[group_id] = {
                            'name': selected_cal_group['name'],
                            'rt': selected_cal_group['rt'],
                            'model_type': model_type,
                            'force_zero': force_zero,
                            'predict_concentration': predict_concentration,
                            'predict_area': predict_area,
                            'r_squared': r_squared,
                            'formula': model_label,
                            'units': units
                        }
                    else:
                        # Not enough data points for calibration
                        st.error("Not enough data points available for calibration. Please add more standards.")
                

                # Add calibration standard data points
                if cal_x_data:
                    fig.add_trace(go.Scatter(
                        x=cal_x_data,
                        y=cal_y_data,
                        mode='markers',
                        name='Calibration Standards',
                        marker=dict(color='blue', size=10),
                        customdata=cal_sample_names,
                        hovertemplate='Concentration: %{x} ' + units + '<br>Area: %{y:.2f} a.u.·min<br>Sample: %{customdata}<extra></extra>'
                    ))
                
                # Add the calibration curve
                if 'x_curve' in locals() and 'y_curve' in locals():
                    fig.add_trace(go.Scatter(
                        x=x_curve,
                        y=y_curve,
                        mode='lines',
                        name='Calibration Curve',
                        line=dict(color='red', width=2),
                        hovertemplate='Concentration: %{x:.2f} ' + units + '<br>Predicted Area: %{y:.2f} a.u.·min<extra></extra>'
                    ))
                
                # Add current samples to the plot (separate from calibration standards) if checkbox is enabled
                if show_current_points:
                    # Find current peaks in all active chromatograms that match the retention time
                    current_areas = []
                    current_concs = []
                    current_sample_names = []
                    
                    # Get the retention time to match based on the selected calibration group
                    if selected_cal_group['type'] == 'model':
                        rt_to_match = selected_cal_group['model']['rt']
                    else:
                        rt_to_match = selected_cal_group['rt']
                    
                    # Get list of standard chromatogram IDs for this group
                    standard_chrom_ids = []
                    if group_id in st.session_state.calibration_data.get('standards', {}):
                        standard_chrom_ids = [int(k) for k in st.session_state.calibration_data['standards'][group_id].keys() 
                                            if k != 'name' and k.isdigit()]
                
                    # Loop through all chromatograms

                    for chrom_id, chrom_data in st.session_state.chromatograms.items():
                        # Skip if not visible
                        if not chrom_data.get('visible', True):
                            continue
                            
                        # Skip if has no peaks
                        if chrom_id not in st.session_state.selected_peaks:
                            continue
                        
                        # Find matching peaks by retention time
                        for peak in st.session_state.selected_peaks[chrom_id]:
                            if abs(peak['Midpoint (min)'] - rt_to_match) < 0.2:  # 0.2 min matching window
                                # Found a matching peak
                                area = peak['Area (a.u.·min)']
                                
                                # Check if this is a calibration standard
                                is_standard = chrom_id in standard_chrom_ids
                                
                                # Only add non-standard samples
                                if not is_standard:
                                    # Calculate concentration using the calibration curve
                                    concentration = predict_concentration(area)
                                    
                                    # Add to our lists of current samples
                                    current_areas.append(area)
                                    current_concs.append(concentration)
                                    current_sample_names.append(chrom_data['name'])


                    # Add current samples to the plot if we found any
                    if current_areas:
                        fig.add_trace(go.Scatter(
                            x=current_concs,
                            y=current_areas,
                            mode='markers',
                            name='Current Samples',
                            marker=dict(color='green', size=10, symbol='diamond'),
                            customdata=current_sample_names,
                            hovertemplate='Concentration: %{x:.2f} ' + units + 
                                        '<br>Area: %{y:.2f} a.u.·min<br>Sample: %{customdata}<extra></extra>'
                        ))
                    elif show_current_points and not current_areas:
                        st.info("No current (non-calibration) samples detected for this retention time.")
                
                # Set axes labels and title
                fig.update_layout(
                    title=f"Calibration Curve: {selected_cal_group['name']}",
                    xaxis_title=f"Concentration ({units})",
                    yaxis_title="Area (a.u.·min)",
                    hovermode="closest",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                )
                
                # Add annotation for formula and R²
                formula_text = formula_text if 'formula_text' in locals() else ""
                r_squared = r_squared if 'r_squared' in locals() else 1.0
                std_error = std_error if 'std_error' in locals() else 0
                
                fig.add_annotation(
                    xref="paper", yref="paper",
                    x=0.02, y=0.98,
                    text=f"{formula_text}<br>R² = {r_squared:.4f}<br>Std Error = {std_error:.4g}",
                    showarrow=False,
                    font=dict(family="Arial", size=12),
                    align="left",
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1,
                    borderpad=4
                )
                
                # Display the plot
                st.plotly_chart(fig, use_container_width=True)
                
                # Show calibration standards table
                if cal_x_data:
                    st.subheader("Calibration Standards")
                    
                    # Create a dataframe for the calibration standards
                    cal_data = []
                    for i, (x, y, sample) in enumerate(zip(cal_x_data, cal_y_data, cal_sample_names)):
                        predicted = predict_area(x)
                        residual = y - predicted
                        percent_error = (residual / y) * 100 if y != 0 else 0
                        
                        cal_data.append({
                            "Standard": sample,
                            f"Concentration ({units})": x,
                            "Area (a.u.·min)": y,
                            "Predicted Area": predicted,
                            "Residual": residual,
                            "% Error": percent_error
                        })
                    
                    # Display as dataframe
                    cal_df = pd.DataFrame(cal_data)
                    st.dataframe(cal_df)
                    
                    # Download button for calibration data
                    csv = cal_df.to_csv(index=False)
                    st.download_button(
                        label=f"Download Calibration Data as CSV",
                        data=csv,
                        file_name=f"calibration_{selected_cal_group['name'].replace(' ', '_')}.csv",
                        mime="text/csv",
                    )
                    
                # Show current samples table if any were found
                if show_current_points and 'current_areas' in locals() and current_areas:
                    st.subheader("Current Samples")
                    
                    # Create a dataframe for the current samples
                    current_data = []
                    for i, (area, conc, sample) in enumerate(zip(current_areas, current_concs, current_sample_names)):
                        predicted_area = predict_area(conc)  # Calculate expected area for validation
                        residual = area - predicted_area
                        percent_error = (residual / area) * 100 if area != 0 else 0
                        
                        current_data.append({
                            "Sample": sample,
                            f"Concentration ({units})": conc,
                            "Area (a.u.·min)": area, 
                            "Predicted Area": predicted_area,
                            "Residual": residual,
                            "% Error": percent_error
                        })
                    
                    # Display as dataframe
                    current_df = pd.DataFrame(current_data)
                    st.dataframe(current_df)
                    
                    # Download button for current sample data
                    csv = current_df.to_csv(index=False)
                    st.download_button(
                        label=f"Download Current Sample Data as CSV",
                        data=csv,
                        file_name=f"current_samples_{selected_cal_group['name'].replace(' ', '_')}.csv",
                        mime="text/csv",
                    )







##########################



############################    








    # Tab 3: Export/Import tab
    with cal_tabs[2]:
        st.write("Export or import calibration settings and curves.")
        
        # Export section
        st.subheader("Export Calibration Data")
        
        if not st.session_state.calibration_data['standards']:
            st.info("No calibration data available to export.")
        else:
            # Create a complete export with all calibration data including model parameters
            export_data = copy.deepcopy(st.session_state.calibration_data)
            
            # Add the calibration models (excluding function references)
            export_data['calibration_models'] = {}
            for group_id, model in st.session_state.calibration_models.items():
                # Create a copy without the function references
                model_export = {
                    'name': model['name'],
                    'rt': model['rt'],
                    'model_type': model['model_type'],
                    'force_zero': model['force_zero'],
                    'r_squared': model['r_squared'],
                    'formula': model['formula'],
                    'units': model['units']
                }
                
                # Add model-specific parameters
                if model['model_type'] == 'linear':
                    # Store slope and intercept
                    if model['force_zero']:
                        # For y = mx (through zero)
                        # Calculate slope from the formula string
                        formula = model['formula']  # e.g., "y = 123.4x"
                        try:
                            slope = float(formula.split('=')[1].strip().replace('x', ''))
                            model_export['parameters'] = {'slope': slope, 'intercept': 0}
                        except:
                            st.warning(f"Could not extract parameters from formula: {formula}")
                    else:
                        # For y = mx + b
                        formula = model['formula']  # e.g., "y = 123.4x + 5.6"
                        try:
                            parts = formula.split('=')[1].strip().split('+')
                            if len(parts) == 1:  # Handle negative intercept: "y = 123.4x - 5.6"
                                parts = formula.split('=')[1].strip().split('-')
                                slope = float(parts[0].strip().replace('x', ''))
                                intercept = -float(parts[1].strip()) if len(parts) > 1 else 0
                            else:
                                slope = float(parts[0].strip().replace('x', ''))
                                intercept = float(parts[1].strip())
                            model_export['parameters'] = {'slope': slope, 'intercept': intercept}
                        except:
                            st.warning(f"Could not extract parameters from formula: {formula}")
                
                elif model['model_type'] == 'quadratic':
                    # Store a, b, c coefficients
                    if model['force_zero']:
                        # For y = ax² + bx
                        formula = model['formula']  # e.g., "y = 1.2x² + 3.4x"
                        try:
                            parts = formula.split('=')[1].strip().split('+')
                            a_part = parts[0].strip()
                            b_part = parts[1].strip() if len(parts) > 1 else "0x"
                            
                            a = float(a_part.split('x²')[0].strip())
                            b = float(b_part.split('x')[0].strip())
                            
                            model_export['parameters'] = {'a': a, 'b': b, 'c': 0}
                        except:
                            st.warning(f"Could not extract parameters from formula: {formula}")
                    else:
                        # For y = ax² + bx + c
                        formula = model['formula']  # e.g., "y = 1.2x² + 3.4x + 5.6"
                        try:
                            parts = formula.split('=')[1].strip().split('+')
                            # Handle potential negative terms
                            if len(parts) < 3:
                                # Check if there are negative terms
                                terms = re.findall(r'([+-]?\s*\d+\.?\d*\s*x²|[+-]?\s*\d+\.?\d*\s*x|[+-]?\s*\d+\.?\d*)', formula.split('=')[1])
                                a_term = next((t for t in terms if 'x²' in t), "0")
                                b_term = next((t for t in terms if 'x' in t and 'x²' not in t), "0")
                                c_term = next((t for t in terms if 'x' not in t), "0")
                                
                                a = float(a_term.replace('x²', '').strip())
                                b = float(b_term.replace('x', '').strip())
                                c = float(c_term.strip())
                            else:
                                a = float(parts[0].strip().split('x²')[0])
                                b = float(parts[1].strip().split('x')[0])
                                c = float(parts[2].strip())
                            
                            model_export['parameters'] = {'a': a, 'b': b, 'c': c}
                        except:
                            st.warning(f"Could not extract parameters from formula: {formula}")
                
                elif model['model_type'] == 'power law':
                    # Store a and b parameters (y = ax^b)
                    formula = model['formula']  # e.g., "y = 1.2x^3.4"
                    try:
                        parts = formula.split('=')[1].strip().split('x^')
                        a = float(parts[0].strip())
                        b = float(parts[1].strip())
                        
                        model_export['parameters'] = {'a': a, 'b': b}
                    except:
                        st.warning(f"Could not extract parameters from formula: {formula}")
                
                # Store all standard data points
                standards_dict = st.session_state.calibration_data['standards'].get(group_id, {})
                model_export['standards'] = {k: v for k, v in standards_dict.items() if k != 'name'}
                
                # Store in export data
                export_data['calibration_models'][group_id] = model_export
            
            # Add additional metadata for export
            export_data['export_date'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
            export_data['app_version'] = "1.0.0"
            
            # Convert to JSON
            json_data = json.dumps(export_data, indent=2)
            
            # Provide download button
            st.download_button(
                label="Download Complete Calibration Data",
                data=json_data,
                file_name="chromatogram_calibration_data.json",
                mime="application/json",
            )
            
            st.write("This file contains all calibration settings, model parameters, and standard data points.")
        



        
        # Import section
        st.subheader("Import Calibration Data")
        uploaded_file = st.file_uploader("Upload Calibration JSON", type=['json'], key="export_import_uploader")

        if uploaded_file is not None:
            try:
                # Read the file
                json_data = uploaded_file.read().decode('utf-8-sig')
                
                if not json_data.strip():  # Check if the file is empty after decoding
                    st.error("The file is empty!")
                else:
                    # Parse the JSON data
                    imported_data = json.loads(json_data)

                    # Validate the imported data
                    is_valid, message = validate_calibration_json(imported_data)
                    if not is_valid:
                        st.error(f"Invalid calibration file: {message}")
                    else:
                        st.success("Valid calibration file detected!")
                        
                        # Show import options
                        st.write("**Imported Calibration Settings:**")
                        st.write(f"- Export Date: {imported_data.get('export_date', 'Unknown')}")
                        st.write(f"- App Version: {imported_data.get('app_version', 'Unknown')}")
                        
                        # Check what's in the file
                        has_models = 'calibration_models' in imported_data and len(imported_data['calibration_models']) > 0
                        has_standards = 'standards' in imported_data and len(imported_data['standards']) > 0
                        
                        if has_models:
                            st.write(f"- Number of Calibration Models: {len(imported_data['calibration_models'])}")
                            
                            # List the models
                            st.write("**Calibration Models:**")
                            for group_id, model in imported_data['calibration_models'].items():
                                st.write(f"- {model.get('name', 'Unnamed')} (RT: {model.get('rt', 0):.2f} min, {model.get('model_type', 'unknown').capitalize()} model, R²: {model.get('r_squared', 0):.4f})")
                        
                        elif has_standards:
                            st.write(f"- Number of Standard Sets: {len(imported_data['standards'])}")
                            
                            # List the standard sets
                            st.write("**Standard Sets:**")
                            for group_id, standards in imported_data['standards'].items():
                                name = standards.get('name', f"Group {group_id}")
                                st.write(f"- {name}")
                        
                        # Import button
                        if st.button("Import Calibration Data", key="import_button"):
                            import_mode = st.radio(
                                "Import Mode",
                                ["Merge with existing", "Replace existing"],
                                index=0,
                                key="import_mode"
                            )
                            
                            if import_mode == "Replace existing":
                                # Clear existing data
                                st.session_state.calibration_data = {
                                    'standards': {},
                                    'model_type': imported_data.get('model_type', 'linear'),
                                    'force_zero': imported_data.get('force_zero', False),
                                    'units': imported_data.get('units', 'µg/mL')
                                }
                                st.session_state.calibration_models = {}

                            # Import standards - This is important for displaying data points!
                            if has_standards:
                                for group_id, standards in imported_data['standards'].items():
                                    st.session_state.calibration_data['standards'][group_id] = standards

                            # Import calibration models
                            if has_models:
                                for group_id, model_data in imported_data['calibration_models'].items():
                                    # Create calibration functions
                                    model_type = model_data.get('model_type', 'linear')
                                    params = model_data.get('parameters', {})
                                    force_zero = model_data.get('force_zero', False)
                                    
                                    # Create functions for this model
                                    predict_area, predict_concentration = create_calibration_functions(
                                        model_type, params, force_zero
                                    )
                                    
                                    # Extract all standards data from different possible sources
                                    standards = {}
                                    
                                    # Check in model's standards 
                                    if 'standards' in model_data and model_data['standards']:
                                        standards.update(model_data['standards'])
                                    
                                    # Also check in the main standards section
                                    if group_id in imported_data.get('standards', {}):
                                        std_data = imported_data['standards'][group_id]
                                        # Extract only the concentration values (exclude 'name' field)
                                        standards.update({k: v for k, v in std_data.items() if k != 'name' and isinstance(v, (int, float))})
                                    
                                    # Store the model with functions and standards
                                    st.session_state.calibration_models[group_id] = {
                                        'name': model_data.get('name', f"Imported Model {group_id}"),
                                        'rt': model_data.get('rt', 0.0),
                                        'model_type': model_type,
                                        'force_zero': force_zero,
                                        'predict_concentration': predict_concentration,
                                        'predict_area': predict_area,
                                        'r_squared': model_data.get('r_squared', 1.0),
                                        'formula': model_data.get('formula', ''),
                                        'units': model_data.get('units', 'µg/mL'),
                                        'parameters': params,
                                        'standards': standards  # Store the standards here
                                    }
                                    
                                    # Also store in calibration_data for UI consistency
                                    if 'standards' not in st.session_state.calibration_data:
                                        st.session_state.calibration_data['standards'] = {}
                                        
                                    if group_id not in st.session_state.calibration_data['standards']:
                                        st.session_state.calibration_data['standards'][group_id] = {'name': model_data.get('name', f"Imported Model {group_id}")}
                                        
                                    # Add all concentration values
                                    for sample_id, concentration in standards.items():
                                        if isinstance(concentration, (int, float)):
                                            st.session_state.calibration_data['standards'][group_id][sample_id] = concentration

                            st.success("Calibration data imported successfully!")
                            st.rerun()

            except Exception as e:
                st.error(f"Error importing calibration file: {str(e)}")
                st.exception(e)  # Show traceback for debugging