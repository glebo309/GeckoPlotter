import streamlit as st
import os
import re
import requests
import py3Dmol
from stmol import showmol
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from collections import defaultdict, Counter
import json
from datetime import datetime

# Import the color palettes
from utils.colourmaps import (
    get_color_from_palette, get_set1_palette, get_viridis_palette, 
    get_wes_anderson_palette, get_retro80s_palette, get_midnight_synthwave_palette
)

# Page configuration
st.set_page_config(
    page_title="🧬 Advanced Protein Explorer", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
    }
    .analysis-section {
        background: #ffffff;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 1rem 0;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        background-color: #f0f2f6;
        border-radius: 4px 4px 0px 0px;
    }
    .stTabs [aria-selected="true"] {
        background-color: #667eea;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'analysis_data' not in st.session_state:
    st.session_state.analysis_data = {}

# Header
st.markdown("""
<div class="main-header">
    <h1 style="color: white; margin: 0;">🧬 Advanced Protein Structure Explorer</h1>
    <p style="color: white; margin: 0; opacity: 0.9;">Comprehensive PDB analysis and visualization platform</p>
</div>
""", unsafe_allow_html=True)

# Sidebar configuration
with st.sidebar:
    st.header("🎮 Visualization Controls")
    
    # File selection section
    st.subheader("📁 File Selection")
    pdb_dir = "./pdb"
    os.makedirs(pdb_dir, exist_ok=True)
    
    # File upload option
    uploaded_file = st.file_uploader("Upload PDB file", type=['pdb'])
    if uploaded_file:
        with open(os.path.join(pdb_dir, uploaded_file.name), "wb") as f:
            f.write(uploaded_file.getbuffer())
        st.success(f"Uploaded {uploaded_file.name}")
    
    # PDB ID download
    st.subheader("🌐 Download from PDB")
    pdb_id = st.text_input("Enter PDB ID (e.g., 1crn, 6lu7)")
    if st.button("Download from RCSB PDB"):
        if pdb_id:
            try:
                url = f"https://files.rcsb.org/download/{pdb_id.upper()}.pdb"
                response = requests.get(url)
                if response.status_code == 200:
                    with open(os.path.join(pdb_dir, f"{pdb_id.upper()}.pdb"), "w") as f:
                        f.write(response.text)
                    st.success(f"Downloaded {pdb_id.upper()}.pdb")
                else:
                    st.error("Failed to download. Check PDB ID.")
            except Exception as e:
                st.error(f"Error: {e}")
    
    # Select from existing files
    pdb_files = [f for f in os.listdir(pdb_dir) if f.endswith(".pdb")]
    if pdb_files:
        selected_file = st.selectbox("Choose a PDB file:", pdb_files)
    else:
        st.warning("No PDB files found. Upload or download one!")
        st.stop()

# Main content
if pdb_files and selected_file:
    # Load PDB file
    pdb_path = os.path.join(pdb_dir, selected_file)
    with open(pdb_path, "r") as f:
        pdb_content = f.read()
    
    # Parse PDB data
    @st.cache_data
    def parse_pdb(pdb_content):
        """Parse PDB file and extract useful information"""
        lines = pdb_content.split('\n')
        
        # Extract header information
        header_info = {}
        for line in lines:
            if line.startswith('HEADER'):
                header_info['title'] = line[10:50].strip()
                header_info['date'] = line[50:59].strip()
                header_info['pdb_id'] = line[62:66].strip()
            elif line.startswith('TITLE'):
                header_info['full_title'] = line[10:].strip()
            elif line.startswith('COMPND'):
                if 'compound' not in header_info:
                    header_info['compound'] = []
                header_info['compound'].append(line[10:].strip())
            elif line.startswith('SOURCE'):
                if 'source' not in header_info:
                    header_info['source'] = []
                header_info['source'].append(line[10:].strip())
        
        # Extract atom information
        atoms = []
        residues = defaultdict(list)
        chains = set()
        
        for line in lines:
            if line.startswith('ATOM'):
                atom_data = {
                    'serial': int(line[6:11].strip()),
                    'name': line[12:16].strip(),
                    'residue': line[17:20].strip(),
                    'chain': line[21:22].strip(),
                    'residue_num': int(line[22:26].strip()),
                    'x': float(line[30:38].strip()),
                    'y': float(line[38:46].strip()),
                    'z': float(line[46:54].strip()),
                    'element': line[76:78].strip() if len(line) > 76 else line[12:14].strip()
                }
                atoms.append(atom_data)
                residues[atom_data['chain']].append(atom_data)
                chains.add(atom_data['chain'])
        
        return header_info, atoms, residues, chains
    
    # Parse the PDB file
    header_info, atoms, residues, chains = parse_pdb(pdb_content)
    
    # Create tabs for different views
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🧬 3D Visualization", 
        "📊 Structure Analysis", 
        "🔬 Sequence Analysis",
        "🎨 Custom Views",
        "📈 Interactive Plots"
    ])
    
    with tab1:
        st.subheader("🧬 Interactive 3D Molecular Viewer")
        
        # Visualization controls
        col1, col2, col3 = st.columns(3)
        
        with col1:
            style_type = st.selectbox(
                "Representation Style",
                ["cartoon", "stick", "sphere", "surface", "line"]
            )
            
        with col2:
            color_scheme = st.selectbox(
                "Color Scheme",
                ["spectrum", "chainbow", "element", "residue", "secondary", "hydrophobicity"]
            )
            
        with col3:
            show_water = st.checkbox("Show Water", value=False)
            show_hetero = st.checkbox("Show Heteroatoms", value=True)
        
        # Advanced controls
        with st.expander("🎛️ Advanced Visualization Controls"):
            col1, col2 = st.columns(2)
            with col1:
                transparency = st.slider("Transparency", 0.0, 1.0, 1.0, 0.1)
                surface_opacity = st.slider("Surface Opacity", 0.0, 1.0, 0.8, 0.1)
            with col2:
                cartoon_thickness = st.slider("Cartoon Thickness", 0.1, 2.0, 1.0, 0.1)
                stick_radius = st.slider("Stick Radius", 0.1, 1.0, 0.3, 0.1)
        
        # Create 3D visualization
        view = py3Dmol.view(width=800, height=600)
        view.addModel(pdb_content, 'pdb')
        
        # Apply styling based on selections
        style_dict = {}
        if style_type == "cartoon":
            style_dict = {"cartoon": {"color": color_scheme, "thickness": cartoon_thickness, "opacity": transparency}}
        elif style_type == "stick":
            style_dict = {"stick": {"color": color_scheme, "radius": stick_radius, "opacity": transparency}}
        elif style_type == "sphere":
            style_dict = {"sphere": {"color": color_scheme, "opacity": transparency}}
        elif style_type == "surface":
            style_dict = {"surface": {"color": color_scheme, "opacity": surface_opacity}}
        elif style_type == "line":
            style_dict = {"line": {"color": color_scheme, "opacity": transparency}}
        
        view.setStyle({}, style_dict)
        
        # Additional representations
        if show_hetero:
            view.setStyle({"hetflag": True}, {"stick": {"color": "element", "radius": 0.5}})
        
        if show_water:
            view.setStyle({"resn": "HOH"}, {"sphere": {"color": "red", "radius": 0.3}})
        
        view.zoomTo()
        showmol(view, height=600, width=800)
        
        # Chain selection for detailed view
        if chains:
            st.subheader("🔗 Chain-specific Visualization")
            selected_chain = st.selectbox("Select chain to highlight:", ["All"] + list(sorted(chains)))
            
            if selected_chain != "All":
                view_chain = py3Dmol.view(width=800, height=400)
                view_chain.addModel(pdb_content, 'pdb')
                view_chain.setStyle({}, {"cartoon": {"color": "lightgray", "opacity": 0.3}})
                view_chain.setStyle({"chain": selected_chain}, {"cartoon": {"color": "spectrum", "thickness": 1.5}})
                view_chain.zoomTo({"chain": selected_chain})
                showmol(view_chain, height=400, width=800)
    
    with tab2:
        st.subheader("📊 Structural Analysis Dashboard")
        
        # Basic statistics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown("""
            <div class="metric-card">
                <h4>Total Atoms</h4>
                <h2>{}</h2>
            </div>
            """.format(len(atoms)), unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div class="metric-card">
                <h4>Chains</h4>
                <h2>{}</h2>
            </div>
            """.format(len(chains)), unsafe_allow_html=True)
        
        with col3:
            unique_residues = len(set([atom['residue'] for atom in atoms]))
            st.markdown("""
            <div class="metric-card">
                <h4>Unique Residues</h4>
                <h2>{}</h2>
            </div>
            """.format(unique_residues), unsafe_allow_html=True)
        
        with col4:
            total_residues = len(set([(atom['chain'], atom['residue_num']) for atom in atoms]))
            st.markdown("""
            <div class="metric-card">
                <h4>Total Residues</h4>
                <h2>{}</h2>
            </div>
            """.format(total_residues), unsafe_allow_html=True)
        
        # Residue composition analysis
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🧪 Residue Composition")
            residue_counts = Counter([atom['residue'] for atom in atoms])
            
            # Create amino acid classification
            hydrophobic = ['ALA', 'VAL', 'LEU', 'ILE', 'PRO', 'PHE', 'TRP', 'MET']
            polar = ['SER', 'THR', 'TYR', 'CYS', 'ASN', 'GLN']
            charged = ['ASP', 'GLU', 'LYS', 'ARG', 'HIS']
            
            residue_df = pd.DataFrame(list(residue_counts.items()), columns=['Residue', 'Count'])
            residue_df['Type'] = residue_df['Residue'].apply(
                lambda x: 'Hydrophobic' if x in hydrophobic 
                else ('Polar' if x in polar 
                      else ('Charged' if x in charged else 'Other'))
            )
            
            # Use colormap for the pie chart
            colors = [get_wes_anderson_palette(i) for i in range(len(residue_df))]
            color_strings = [f"rgb({r},{g},{b})" for r, g, b in colors]
            
            fig_pie = px.pie(residue_df, values='Count', names='Residue', 
                           title="Residue Distribution",
                           color_discrete_sequence=color_strings)
            fig_pie.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig_pie, use_container_width=True)
        
        with col2:
            st.subheader("🔗 Chain Analysis")
            chain_stats = {}
            for chain in chains:
                chain_atoms = [atom for atom in atoms if atom['chain'] == chain]
                chain_residues = len(set([atom['residue_num'] for atom in chain_atoms]))
                chain_stats[chain] = {
                    'Atoms': len(chain_atoms),
                    'Residues': chain_residues
                }
            
            chain_df = pd.DataFrame(chain_stats).T
            chain_df.index.name = 'Chain'
            
            # Use colormap for chain visualization
            colors = [get_viridis_palette(i) for i in range(len(chain_df))]
            color_strings = [f"rgb({r},{g},{b})" for r, g, b in colors]
            
            fig_bar = px.bar(chain_df, y=chain_df.index, x='Residues', 
                           orientation='h', title="Residues per Chain",
                           color=chain_df.index,
                           color_discrete_sequence=color_strings)
            st.plotly_chart(fig_bar, use_container_width=True)
        
        # Element composition
        st.subheader("⚛️ Atomic Composition")
        element_counts = Counter([atom['element'] for atom in atoms])
        element_df = pd.DataFrame(list(element_counts.items()), columns=['Element', 'Count'])
        
        # Use retro palette for elements
        colors = [get_retro80s_palette(i) for i in range(len(element_df))]
        color_strings = [f"rgb({r},{g},{b})" for r, g, b in colors]
        
        fig_elements = px.bar(element_df, x='Element', y='Count', 
                             title="Atomic Element Distribution",
                             color='Element',
                             color_discrete_sequence=color_strings)
        st.plotly_chart(fig_elements, use_container_width=True)
        
        # Geometric analysis
        if len(atoms) > 0:
            st.subheader("📐 Geometric Properties")
            
            # Calculate center of mass and bounding box
            coords = np.array([[atom['x'], atom['y'], atom['z']] for atom in atoms])
            center_of_mass = np.mean(coords, axis=0)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Center of Mass X", f"{center_of_mass[0]:.2f} Å")
            with col2:
                st.metric("Center of Mass Y", f"{center_of_mass[1]:.2f} Å")
            with col3:
                st.metric("Center of Mass Z", f"{center_of_mass[2]:.2f} Å")
            
            # Calculate protein dimensions
            min_coords = np.min(coords, axis=0)
            max_coords = np.max(coords, axis=0)
            dimensions = max_coords - min_coords
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Width (X)", f"{dimensions[0]:.2f} Å")
            with col2:
                st.metric("Height (Y)", f"{dimensions[1]:.2f} Å")
            with col3:
                st.metric("Depth (Z)", f"{dimensions[2]:.2f} Å")
    
    with tab3:
        st.subheader("🔬 Sequence and Secondary Structure Analysis")
        
        # Extract sequence for each chain
        sequences = {}
        for chain in chains:
            chain_residues = []
            seen_residues = set()
            for atom in atoms:
                if atom['chain'] == chain:
                    residue_key = (atom['residue_num'], atom['residue'])
                    if residue_key not in seen_residues:
                        chain_residues.append((atom['residue_num'], atom['residue']))
                        seen_residues.add(residue_key)
            
            # Sort by residue number
            chain_residues.sort(key=lambda x: x[0])
            sequences[chain] = [residue[1] for residue in chain_residues]
        
        # Display sequences
        for chain, sequence in sequences.items():
            st.subheader(f"Chain {chain} Sequence")
            
            # Convert to single letter code
            aa_map = {
                'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C',
                'GLU': 'E', 'GLN': 'Q', 'GLY': 'G', 'HIS': 'H', 'ILE': 'I',
                'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P',
                'SER': 'S', 'THR': 'T', 'TRP': 'W', 'TYR': 'Y', 'VAL': 'V'
            }
            
            single_letter = ''.join([aa_map.get(res, 'X') for res in sequence])
            
            # Display sequence in chunks of 50
            chunk_size = 50
            for i in range(0, len(single_letter), chunk_size):
                chunk = single_letter[i:i+chunk_size]
                st.code(f"{i+1:4d}: {chunk}")
            
            # Sequence statistics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Length", len(sequence))
            with col2:
                molecular_weight = sum([
                    110 if res in aa_map else 0 for res in sequence
                ])  # Approximate MW
                st.metric("Approx. MW (kDa)", f"{molecular_weight/1000:.1f}")
            with col3:
                charge = sum([
                    1 if res in ['LYS', 'ARG'] else (-1 if res in ['ASP', 'GLU'] else 0)
                    for res in sequence
                ])
                st.metric("Net Charge", charge)
        
        # Hydrophobicity plot
        if sequences:
            st.subheader("💧 Hydrophobicity Profile")
            
            # Kyte-Doolittle hydrophobicity scale
            hydrophobicity_scale = {
                'A': 1.8, 'R': -4.5, 'N': -3.5, 'D': -3.5, 'C': 2.5,
                'Q': -3.5, 'E': -3.5, 'G': -0.4, 'H': -3.2, 'I': 4.5,
                'L': 3.8, 'K': -3.9, 'M': 1.9, 'F': 2.8, 'P': -1.6,
                'S': -0.8, 'T': -0.7, 'W': -0.9, 'Y': -1.3, 'V': 4.2
            }
            
            for chain, sequence in sequences.items():
                hydrophobicity = [hydrophobicity_scale.get(aa_map.get(res, 'X'), 0) for res in sequence]
                
                # Moving average for smoothing
                window_size = 9
                if len(hydrophobicity) >= window_size:
                    smoothed = np.convolve(hydrophobicity, np.ones(window_size)/window_size, mode='valid')
                    positions = list(range(window_size//2 + 1, len(hydrophobicity) - window_size//2 + 1))
                else:
                    smoothed = hydrophobicity
                    positions = list(range(1, len(hydrophobicity) + 1))
                
                # Use midnight synthwave palette for the plot
                color = get_midnight_synthwave_palette(ord(chain) % 12)
                color_string = f"rgb({color[0]},{color[1]},{color[2]})"
                
                fig_hydro = go.Figure()
                fig_hydro.add_trace(go.Scatter(
                    x=positions, y=smoothed,
                    mode='lines+markers',
                    name=f'Chain {chain}',
                    line=dict(color=color_string, width=3),
                    marker=dict(size=4)
                ))
                
                fig_hydro.update_layout(
                    title=f"Hydrophobicity Profile - Chain {chain}",
                    xaxis_title="Residue Position",
                    yaxis_title="Hydrophobicity (Kyte-Doolittle)",
                    template="plotly_white"
                )
                fig_hydro.add_hline(y=0, line_dash="dash", line_color="gray")
                
                st.plotly_chart(fig_hydro, use_container_width=True)
    
    with tab4:
        st.subheader("🎨 Custom Visualization Studio")
        
        # Custom selection interface
        st.write("Create custom selections and visualizations:")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Selection Criteria:**")
            select_chain = st.multiselect("Select Chains:", list(chains), default=list(chains))
            
            # Residue range selection
            if atoms:
                min_res = min([atom['residue_num'] for atom in atoms])
                max_res = max([atom['residue_num'] for atom in atoms])
                res_range = st.slider("Residue Range:", min_res, max_res, (min_res, max_res))
            
            # Residue type selection
            unique_residues = sorted(list(set([atom['residue'] for atom in atoms])))
            select_residues = st.multiselect("Select Residue Types:", unique_residues)
            
            # Element selection
            unique_elements = sorted(list(set([atom['element'] for atom in atoms])))
            select_elements = st.multiselect("Select Elements:", unique_elements)
        
        with col2:
            st.write("**Visualization Style:**")
            custom_style = st.selectbox("Style:", ["cartoon", "stick", "sphere", "surface", "line"])
            custom_color = st.selectbox("Color:", ["spectrum", "element", "residue", "chainbow", "byatom"])
            
            # Advanced styling
            if custom_style == "cartoon":
                cartoon_color = st.color_picker("Custom Color", "#FF6B6B")
                cartoon_thickness = st.slider("Thickness", 0.5, 3.0, 1.5)
            elif custom_style == "stick":
                stick_color = st.color_picker("Custom Color", "#4ECDC4")
                stick_radius = st.slider("Radius", 0.1, 1.0, 0.3)
            elif custom_style == "sphere":
                sphere_color = st.color_picker("Custom Color", "#45B7D1")
                sphere_scale = st.slider("Size Scale", 0.5, 2.0, 1.0)
        
        # Generate custom visualization
        if st.button("🎬 Generate Custom View"):
            custom_view = py3Dmol.view(width=800, height=600)
            custom_view.addModel(pdb_content, 'pdb')
            
            # Apply base style (lighter)
            custom_view.setStyle({}, {"cartoon": {"color": "lightgray", "opacity": 0.2}})
            
            # Build selection criteria
            selection = {}
            if select_chain:
                if len(select_chain) == 1:
                    selection["chain"] = select_chain[0]
                else:
                    # Multiple chains - need to create separate selections
                    pass
            
            if select_residues:
                selection["resn"] = select_residues
            
            if select_elements:
                selection["elem"] = select_elements
            
            # Apply residue range if specified
            if 'res_range' in locals():
                selection["resi"] = f"{res_range[0]}-{res_range[1]}"
            
            # Apply custom style to selection
            style_dict = {}
            if custom_style == "cartoon":
                hex_color = cartoon_color if 'cartoon_color' in locals() else "#FF6B6B"
                style_dict = {"cartoon": {"color": hex_color, "thickness": cartoon_thickness if 'cartoon_thickness' in locals() else 1.5}}
            elif custom_style == "stick":
                hex_color = stick_color if 'stick_color' in locals() else "#4ECDC4"
                style_dict = {"stick": {"color": hex_color, "radius": stick_radius if 'stick_radius' in locals() else 0.3}}
            elif custom_style == "sphere":
                hex_color = sphere_color if 'sphere_color' in locals() else "#45B7D1"
                style_dict = {"sphere": {"color": hex_color, "scale": sphere_scale if 'sphere_scale' in locals() else 1.0}}
            else:
                style_dict = {custom_style: {"color": custom_color}}
            
            custom_view.setStyle(selection, style_dict)
            custom_view.zoomTo(selection)
            showmol(custom_view, height=600, width=800)
        
        # Save/Load custom views
        st.subheader("💾 Save & Load Custom Views")
        col1, col2 = st.columns(2)
        
        with col1:
            view_name = st.text_input("View Name:")
            if st.button("Save Current View"):
                if view_name:
                    # In a real app, you'd save this to a database or file
                    st.success(f"View '{view_name}' saved!")
        
        with col2:
            # In a real app, you'd load saved views from storage
            saved_views = ["Default", "Active Site", "Hydrophobic Core"]
            selected_view = st.selectbox("Load Saved View:", saved_views)
            if st.button("Load View"):
                st.info(f"Loading view: {selected_view}")
    
    with tab5:
        st.subheader("📈 Interactive Analysis Plots")
        
        # B-factor analysis if available
        b_factors = []
        for line in pdb_content.split('\n'):
            if line.startswith('ATOM') and len(line) > 60:
                try:
                    b_factor = float(line[60:66].strip())
                    b_factors.append({
                        'residue_num': int(line[22:26].strip()),
                        'chain': line[21:22].strip(),
                        'residue': line[17:20].strip(),
                        'b_factor': b_factor
                    })
                except:
                    pass
        
        if b_factors:
            st.subheader("🌡️ B-Factor Analysis")
            b_factor_df = pd.DataFrame(b_factors)
            
            # Plot B-factors by position
            fig_bf = px.scatter(b_factor_df, x='residue_num', y='b_factor', 
                               color='chain', title="B-Factors by Residue Position",
                               hover_data=['residue'])
            fig_bf.update_layout(xaxis_title="Residue Number", yaxis_title="B-Factor")
            st.plotly_chart(fig_bf, use_container_width=True)
            
            # B-factor distribution
            fig_bf_hist = px.histogram(b_factor_df, x='b_factor', nbins=30,
                                      title="B-Factor Distribution")
            st.plotly_chart(fig_bf_hist, use_container_width=True)
        
        # Distance matrices and contact maps
        st.subheader("🗺️ Contact Map Analysis")
        
        # Calculate CA-CA distances for contact map
        ca_atoms = [atom for atom in atoms if atom['name'] == 'CA']
        
        if len(ca_atoms) > 1:
            with st.spinner("Calculating distance matrix..."):
                # Limit to first 100 residues for performance
                ca_sample = ca_atoms[:min(100, len(ca_atoms))]
                
                n_residues = len(ca_sample)
                distance_matrix = np.zeros((n_residues, n_residues))
                
                for i, atom1 in enumerate(ca_sample):
                    for j, atom2 in enumerate(ca_sample):
                        if i != j:
                            dist = np.sqrt(
                                (atom1['x'] - atom2['x'])**2 + 
                                (atom1['y'] - atom2['y'])**2 + 
                                (atom1['z'] - atom2['z'])**2
                            )
                            distance_matrix[i][j] = dist
                
                # Create contact map (distances < 8 Å)
                contact_map = distance_matrix < 8.0
                contact_map = contact_map.astype(int)
                
                # Plot contact map
                residue_nums = [atom['residue_num'] for atom in ca_sample]
                
                fig_contact = go.Figure(data=go.Heatmap(
                    z=contact_map,
                    x=residue_nums,
                    y=residue_nums,
                    colorscale='Viridis',
                    showscale=True
                ))
                
                fig_contact.update_layout(
                    title="Contact Map (CA-CA distance < 8Å)",
                    xaxis_title="Residue Number",
                    yaxis_title="Residue Number",
                    width=600,
                    height=600
                )
                st.plotly_chart(fig_contact, use_container_width=True)
                
                # Distance distribution
                upper_triangle = distance_matrix[np.triu_indices_from(distance_matrix, k=1)]
                fig_dist = px.histogram(x=upper_triangle, nbins=50,
                                       title="CA-CA Distance Distribution",
                                       labels={'x': 'Distance (Å)', 'y': 'Count'})
                st.plotly_chart(fig_dist, use_container_width=True)
        
        # Ramachandran plot simulation (simplified)
        st.subheader("🔄 Ramachandran Plot (Simulated)")
        
        # For demonstration, generate random phi/psi angles
        # In a real implementation, you'd calculate these from the backbone atoms
        n_residues = len(set([(atom['chain'], atom['residue_num']) for atom in atoms]))
        
        phi_angles = np.random.normal(-60, 30, n_residues)
        psi_angles = np.random.normal(-45, 30, n_residues)
        
        # Create Ramachandran plot
        fig_rama = go.Figure()
        
        # Add allowed regions (simplified)
        # Alpha-helix region
        fig_rama.add_shape(
            type="rect",
            x0=-120, y0=-60, x1=-40, y1=20,
            fillcolor="lightblue", opacity=0.3,
            layer="below", line_width=0
        )
        
        # Beta-sheet region
        fig_rama.add_shape(
            type="rect", 
            x0=-180, y0=120, x1=-90, y1=180,
            fillcolor="lightgreen", opacity=0.3,
            layer="below", line_width=0
        )
        
        # Left-handed alpha-helix
        fig_rama.add_shape(
            type="rect",
            x0=40, y0=30, x1=100, y1=80,
            fillcolor="lightcoral", opacity=0.3,
            layer="below", line_width=0
        )
        
        # Plot residues
        colors = [get_set1_palette(i) for i in range(len(phi_angles))]
        color_strings = [f"rgb({r},{g},{b})" for r, g, b in colors]
        
        fig_rama.add_trace(go.Scatter(
            x=phi_angles, y=psi_angles,
            mode='markers',
            marker=dict(
                size=8,
                color=color_strings,
                line=dict(width=1, color='black')
            ),
            name='Residues'
        ))
        
        fig_rama.update_layout(
            title="Ramachandran Plot (φ vs ψ angles)",
            xaxis_title="φ (phi) angle (°)",
            yaxis_title="ψ (psi) angle (°)",
            xaxis=dict(range=[-180, 180]),
            yaxis=dict(range=[-180, 180]),
            width=600, height=600
        )
        
        st.plotly_chart(fig_rama, use_container_width=True)
        
        # 3D scatter plot of atomic positions
        st.subheader("🌌 3D Atomic Position Scatter")
        
        # Sample atoms for performance
        sample_size = min(1000, len(atoms))
        sampled_atoms = np.random.choice(atoms, sample_size, replace=False)
        
        x_coords = [atom['x'] for atom in sampled_atoms]
        y_coords = [atom['y'] for atom in sampled_atoms]
        z_coords = [atom['z'] for atom in sampled_atoms]
        elements = [atom['element'] for atom in sampled_atoms]
        
        # Create element-to-color mapping
        unique_elements = list(set(elements))
        element_colors = {}
        for i, element in enumerate(unique_elements):
            color_rgb = get_retro80s_palette(i)
            element_colors[element] = f"rgb({color_rgb[0]}, {color_rgb[1]}, {color_rgb[2]})"
        
        # Map element names to colors
        colors = [element_colors[element] for element in elements]
        
        # Create 3D scatter plot
        fig_3d = go.Figure(data=[go.Scatter3d(
            x=x_coords,
            y=y_coords,
            z=z_coords,
            mode='markers',
            marker=dict(
                size=3,
                color=colors,
                opacity=0.8
            ),
            text=[f"Element: {e}<br>Chain: {atom['chain']}<br>Residue: {atom['residue']}" 
                  for atom, e in zip(sampled_atoms, elements)],
            hovertemplate='%{text}<br>X: %{x}<br>Y: %{y}<br>Z: %{z}<extra></extra>'
        )])
        
        # Add element legend by creating separate traces for each element
        for element in unique_elements:
            element_mask = [e == element for e in elements]
            if any(element_mask):
                element_x = [x for x, mask in zip(x_coords, element_mask) if mask]
                element_y = [y for y, mask in zip(y_coords, element_mask) if mask]
                element_z = [z for z, mask in zip(z_coords, element_mask) if mask]
                
                fig_3d.add_trace(go.Scatter3d(
                    x=element_x[:1],  # Just one point for legend
                    y=element_y[:1],
                    z=element_z[:1],
                    mode='markers',
                    marker=dict(
                        size=6,
                        color=element_colors[element]
                    ),
                    name=element,
                    showlegend=True,
                    visible='legendonly'  # Only show in legend
                ))
        
        fig_3d.update_layout(
            title="3D Atomic Positions (Colored by Element)",
            scene=dict(
                xaxis_title="X (Å)",
                yaxis_title="Y (Å)",
                zaxis_title="Z (Å)"
            ),
            width=800,
            height=600,
            legend=dict(
                orientation="v",
                yanchor="top",
                y=1,
                xanchor="left",
                x=1.02
            )
        )
        
        st.plotly_chart(fig_3d, use_container_width=True)

    # Protein Information Panel
    with st.expander("ℹ️ Protein Information", expanded=False):
        if header_info:
            st.subheader("📋 Header Information")
            
            col1, col2 = st.columns(2)
            with col1:
                if 'title' in header_info:
                    st.write(f"**Title:** {header_info['title']}")
                if 'pdb_id' in header_info:
                    st.write(f"**PDB ID:** {header_info['pdb_id']}")
                if 'date' in header_info:
                    st.write(f"**Date:** {header_info['date']}")
            
            with col2:
                if 'compound' in header_info:
                    st.write("**Compound:**")
                    for compound in header_info['compound']:
                        st.write(f"  {compound}")
                
                if 'source' in header_info:
                    st.write("**Source:**")
                    for source in header_info['source']:
                        st.write(f"  {source}")
    
    # Raw PDB content viewer
    with st.expander("📄 Raw PDB Content", expanded=False):
        st.code(pdb_content[:2000] + ("..." if len(pdb_content) > 2000 else ""), 
                language="text")
    
    # Export functionality
    st.sidebar.subheader("💾 Export Options")
    
    if st.sidebar.button("📊 Export Analysis Report"):
        # Create analysis report
        report = f"""
# Protein Analysis Report
**File:** {selected_file}
**Generated:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## Summary Statistics
- Total Atoms: {len(atoms)}
- Chains: {len(chains)}
- Unique Residues: {len(set([atom['residue'] for atom in atoms]))}

## Chain Information
"""
        for chain in chains:
            chain_atoms = [atom for atom in atoms if atom['chain'] == chain]
            chain_residues = len(set([atom['residue_num'] for atom in chain_atoms]))
            report += f"- Chain {chain}: {len(chain_atoms)} atoms, {chain_residues} residues\n"
        
        st.sidebar.download_button(
            label="📄 Download Report",
            data=report,
            file_name=f"{selected_file}_analysis_report.md",
            mime="text/markdown"
        )
    
    # Settings panel
    with st.sidebar.expander("⚙️ Advanced Settings"):
        st.write("**Performance Settings**")
        max_atoms_display = st.number_input("Max atoms for 3D view", 1000, 50000, 10000)
        
        st.write("**Color Palette Selection**")
        palette_options = [
            "Wes Anderson", "Retro 80s", "Midnight Synthwave", 
            "Scientific Viridis", "Set1", "Default"
        ]
        selected_palette = st.selectbox("Choose color palette:", palette_options)
        
        if 'plot_settings' not in st.session_state:
            st.session_state.plot_settings = {}
        
        st.session_state.plot_settings['color_palette'] = selected_palette
        st.session_state.plot_settings['max_atoms'] = max_atoms_display
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; padding: 20px;">
        🧬 Advanced Protein Explorer | Built with Streamlit & py3Dmol<br>
        <small>Upload your PDB files and explore protein structures in stunning detail!</small>
    </div>
    """, unsafe_allow_html=True)