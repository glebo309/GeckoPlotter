import streamlit as st
import os
import re
import requests
import py3Dmol
from stmol import showmol
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from collections import defaultdict, Counter
import json
from datetime import datetime
import scipy.spatial.distance as dist
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.stats import gaussian_kde
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, DBSCAN
import networkx as nx
from Bio.PDB import *
from Bio.SeqUtils.ProtParam import ProteinAnalysis
import warnings
warnings.filterwarnings('ignore')

# Import the color palettes
from utils.colourmaps import (
    get_color_from_palette, get_set1_palette, get_viridis_palette, 
    get_wes_anderson_palette, get_retro80s_palette, get_midnight_synthwave_palette,
    get_batlow_palette, get_lajolla_palette, get_turku_palette, get_crayon_box_palette
)

# Page configuration with EXTREME styling
st.set_page_config(
    page_title="🧬 INSANE Protein Universe Explorer", 
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': 'mailto:molecular.wizard@proteinuniverse.ai',
        'Report a bug': 'mailto:bugs@proteinuniverse.ai',
        'About': '# The Most INSANE Protein Analyzer Ever Created!'
    }
)

# Helper function for amino acid properties
def get_aa_properties(aa):
    """Get properties of amino acid"""
    properties = {
        'A': 'Hydrophobic', 'V': 'Hydrophobic', 'L': 'Hydrophobic', 'I': 'Hydrophobic',
        'P': 'Hydrophobic', 'F': 'Hydrophobic', 'W': 'Hydrophobic', 'M': 'Hydrophobic',
        'S': 'Polar', 'T': 'Polar', 'Y': 'Polar', 'C': 'Polar', 'N': 'Polar', 'Q': 'Polar',
        'K': 'Positive', 'R': 'Positive', 'H': 'Positive',
        'D': 'Negative', 'E': 'Negative',
        'G': 'Special'
    }
    return properties.get(aa, 'Unknown')

# ABSOLUTELY BONKERS CSS
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');
    
    .main-header {
        background: linear-gradient(45deg, #ff006e, #8338ec, #3a86ff, #06ffa5);
        background-size: 400% 400%;
        animation: gradient 15s ease infinite;
        padding: 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        border: 2px solid rgba(255,255,255,0.1);
    }
    
    @keyframes gradient {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    .cyber-title {
        font-family: 'Orbitron', monospace;
        font-weight: 900;
        font-size: 3rem;
        color: white;
        text-shadow: 0 0 20px rgba(255,255,255,0.5);
        margin: 0;
    }
    
    .cyber-subtitle {
        font-family: 'Orbitron', monospace;
        color: rgba(255,255,255,0.8);
        font-size: 1.2rem;
        margin: 0;
    }
    
    .metric-card {
        background: linear-gradient(135deg, #1a1a2e, #16213e);
        padding: 1.5rem;
        border-radius: 15px;
        border: 1px solid #00ffa1;
        box-shadow: 0 10px 30px rgba(0,255,161,0.1);
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0,255,161,0.2);
        border-color: #ff006e;
    }
    
    .analysis-section {
        background: linear-gradient(135deg, #0f0f0f, #1a1a1a);
        padding: 2rem;
        border-radius: 20px;
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 15px 35px rgba(0,0,0,0.5);
        margin: 1.5rem 0;
    }
    
    .ai-section {
        background: linear-gradient(45deg, #ff006e, #8338ec);
        padding: 2rem;
        border-radius: 20px;
        margin: 2rem 0;
        border: 2px solid rgba(255,255,255,0.2);
        box-shadow: 0 0 50px rgba(255,0,110,0.3);
    }
    
    .stTabs [data-baseweb="tab-list"] {
        gap: 5px;
        background: #0f0f0f;
        padding: 10px;
        border-radius: 15px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 60px;
        background: linear-gradient(135deg, #1a1a2e, #16213e);
        border-radius: 10px;
        color: white;
        font-weight: bold;
        border: 1px solid rgba(255,255,255,0.1);
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #ff006e, #8338ec);
        box-shadow: 0 0 20px rgba(255,0,110,0.5);
    }
    
    .feature-badge {
        display: inline-block;
        background: linear-gradient(45deg, #00ffa1, #03dac6);
        color: black;
        padding: 0.5rem 1rem;
        border-radius: 25px;
        font-weight: bold;
        margin: 0.25rem;
        box-shadow: 0 5px 15px rgba(0,255,161,0.3);
    }
    
    .warning-box {
        background: linear-gradient(135deg, #ff006e, #ff4081);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        font-weight: bold;
        text-align: center;
        box-shadow: 0 0 30px rgba(255,0,110,0.4);
    }
    
    .sidebar .element-container {
        background: rgba(0,0,0,0.8);
        border-radius: 10px;
        padding: 1rem;
        border: 1px solid rgba(255,255,255,0.1);
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state for MAXIMUM POWER
if 'analysis_data' not in st.session_state:
    st.session_state.analysis_data = {}
if 'ai_analysis' not in st.session_state:
    st.session_state.ai_analysis = {}
if 'molecular_dynamics' not in st.session_state:
    st.session_state.molecular_dynamics = {}
if 'drug_discovery' not in st.session_state:
    st.session_state.drug_discovery = {}

# EPIC HEADER
st.markdown("""
<div class="main-header">
    <h1 class="cyber-title">🧬 PROTEIN UNIVERSE EXPLORER 💫</h1>
    <p class="cyber-subtitle">🚀 THE MOST INSANELY ADVANCED MOLECULAR VISUALIZATION PLATFORM EVER CREATED 🚀</p>
    <div style="text-align: center; margin-top: 1rem;">
        <span class="feature-badge">🤖 AI-POWERED</span>
        <span class="feature-badge">⚡ REAL-TIME</span>
        <span class="feature-badge">🎮 INTERACTIVE</span>
        <span class="feature-badge">🔬 RESEARCH-GRADE</span>
        <span class="feature-badge">💎 PUBLICATION-READY</span>
    </div>
</div>
""", unsafe_allow_html=True)

# SIDEBAR OF ABSOLUTE MADNESS
with st.sidebar:
    st.markdown("## 🎮 MOLECULAR COMMAND CENTER")
    
    # File selection section
    st.markdown("### 📁 PROTEIN ACQUISITION SYSTEM")
    
    with st.expander("🌐 DOWNLOAD FROM PROTEIN DATA BANK", expanded=True):
        pdb_id = st.text_input("🆔 Enter PDB ID (e.g., 1crn, 6lu7, 7p6z)")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("⚡ DOWNLOAD NOW"):
                if pdb_id:
                    try:
                        url = f"https://files.rcsb.org/download/{pdb_id.upper()}.pdb"
                        response = requests.get(url)
                        if response.status_code == 200:
                            pdb_dir = "./pdb"
                            os.makedirs(pdb_dir, exist_ok=True)
                            with open(os.path.join(pdb_dir, f"{pdb_id.upper()}.pdb"), "w") as f:
                                f.write(response.text)
                            st.success(f"🎯 ACQUIRED {pdb_id.upper()}.pdb")
                        else:
                            st.error("💥 DOWNLOAD FAILED!")
                    except Exception as e:
                        st.error(f"🚨 ERROR: {e}")
        
        with col2:
            if st.button("📊 GET METADATA"):
                if pdb_id:
                    try:
                        meta_url = f"https://data.rcsb.org/rest/v1/core/entry/{pdb_id.upper()}"
                        response = requests.get(meta_url)
                        if response.status_code == 200:
                            metadata = response.json()
                            st.json(metadata)
                    except:
                        st.error("Failed to fetch metadata")
    
    # File upload section
    with st.expander("📤 UPLOAD YOUR PROTEIN", expanded=False):
        uploaded_file = st.file_uploader("Drop your PDB file here", type=['pdb', 'cif'])
        if uploaded_file:
            pdb_dir = "./pdb"
            os.makedirs(pdb_dir, exist_ok=True)
            with open(os.path.join(pdb_dir, uploaded_file.name), "wb") as f:
                f.write(uploaded_file.getbuffer())
            st.success(f"🎊 UPLOADED {uploaded_file.name}")
    
    # Select from existing files
    pdb_dir = "./pdb"
    os.makedirs(pdb_dir, exist_ok=True)
    pdb_files = [f for f in os.listdir(pdb_dir) if f.endswith((".pdb", ".cif"))]
    
    if pdb_files:
        selected_file = st.selectbox("🎯 SELECT PROTEIN TARGET:", pdb_files, key="file_selector")
    else:
        st.markdown('<div class="warning-box">⚠️ NO PROTEINS DETECTED! UPLOAD OR DOWNLOAD ONE! ⚠️</div>', unsafe_allow_html=True)
        st.stop()
    
    # VISUALIZATION CONTROLS OF DOOM
    st.markdown("### 🎨 VISUALIZATION MATRIX")
    
    with st.expander("🔬 3D RENDER SETTINGS", expanded=True):
        style_type = st.selectbox("📐 Molecular Style:", 
            ["cartoon", "stick", "sphere", "surface", "line", "ribbon", "trace"], key="style")
        color_scheme = st.selectbox("🎨 Color Mode:", 
            ["spectrum", "chainbow", "element", "residue", "secondary", "hydrophobicity", "bfactor", "charge"], key="color")
        
        col1, col2 = st.columns(2)
        with col1:
            transparency = st.slider("👻 Transparency", 0.0, 1.0, 1.0, 0.05)
            surface_opacity = st.slider("🌊 Surface Alpha", 0.0, 1.0, 0.85, 0.05)
        with col2:
            quality = st.selectbox("⚡ Render Quality:", ["Low", "Medium", "High", "Ultra"])
            background = st.color_picker("🌌 Background:", "#000000")
    
    # ADVANCED AI CONTROLS
    st.markdown("### 🤖 AI ANALYSIS ENGINE")
    
    with st.expander("🧠 AI MOLECULAR INTELLIGENCE", expanded=False):
        ai_analysis_types = st.multiselect("🔮 AI Analysis Types:", [
            "🎯 Active Site Prediction",
            "🔗 Allosteric Site Detection", 
            "💊 Drug Binding Prediction",
            "🧬 Flexibility Analysis",
            "⚡ Dynamics Simulation",
            "🌡️ Stability Assessment",
            "🔄 Conformational Changes",
            "📊 Evolutionary Conservation"
        ])
        
        if st.button("🚀 LAUNCH AI ANALYSIS"):
            if ai_analysis_types:
                st.session_state.ai_analysis['types'] = ai_analysis_types
                st.session_state.ai_analysis['timestamp'] = datetime.now()
                st.success("🤖 AI ANALYSIS INITIATED!")
    
    # MOLECULAR DYNAMICS
    with st.expander("⚡ MOLECULAR DYNAMICS SETUP", expanded=False):
        md_duration = st.slider("⏱️ Simulation Time (ns)", 1, 100, 10)
        md_temperature = st.slider("🌡️ Temperature (K)", 200, 400, 300)
        md_force_field = st.selectbox("⚗️ Force Field:", ["CHARMM36", "AMBER99SB", "GROMOS96"])
        
        if st.button("🔥 START MD SIMULATION"):
            st.session_state.molecular_dynamics['params'] = {
                'duration': md_duration,
                'temperature': md_temperature, 
                'force_field': md_force_field
            }
            st.success("⚡ MD SIMULATION QUEUED!")
    
    # COLOR PALETTE SELECTION
    st.markdown("### 🎨 COLOR UNIVERSE")
    palette_options = {
        "🎬 Wes Anderson": "get_wes_anderson_palette",
        "🌈 Retro 80s": "get_retro80s_palette", 
        "🌙 Midnight Synthwave": "get_midnight_synthwave_palette",
        "🔬 Scientific Viridis": "get_viridis_palette",
        "🎯 ColorBrewer Set1": "get_set1_palette",
        "🌋 Batlow Volcanic": "get_batlow_palette",
        "🏜️ LaJolla Desert": "get_lajolla_palette",
        "❄️ Turku Ice": "get_turku_palette",
        "🖍️ Crayon Box": "get_crayon_box_palette"
    }
    
    selected_palette = st.selectbox("🌈 Choose Color Palette:", list(palette_options.keys()))
    st.session_state.selected_palette = palette_options[selected_palette]

# ENHANCED PDB PARSER WITH EXTREME FEATURES
@st.cache_data
def parse_pdb_extreme(pdb_content):
    """The most comprehensive PDB parser ever created"""
    lines = pdb_content.split('\n')
    
    # Extract ALL possible information
    header_info = {}
    atoms = []
    residues = defaultdict(list)
    chains = set()
    secondary_structure = {}
    crystallographic_info = {}
    experimental_data = {}
    
    for line in lines:
        # Header information
        if line.startswith('HEADER'):
            header_info['title'] = line[10:50].strip()
            header_info['date'] = line[50:59].strip()
            header_info['pdb_id'] = line[62:66].strip()
            header_info['classification'] = line[10:50].strip()
        elif line.startswith('TITLE'):
            if 'full_title' not in header_info:
                header_info['full_title'] = []
            header_info['full_title'].append(line[10:].strip())
        elif line.startswith('COMPND'):
            if 'compound' not in header_info:
                header_info['compound'] = []
            header_info['compound'].append(line[10:].strip())
        elif line.startswith('SOURCE'):
            if 'source' not in header_info:
                header_info['source'] = []
            header_info['source'].append(line[10:].strip())
        elif line.startswith('KEYWDS'):
            header_info['keywords'] = line[10:].strip()
        elif line.startswith('EXPDTA'):
            experimental_data['method'] = line[10:].strip()
        elif line.startswith('REMARK   2'):
            if 'RESOLUTION' in line:
                try:
                    experimental_data['resolution'] = float(line.split()[-2])
                except:
                    pass
        elif line.startswith('REMARK   3'):
            if 'R VALUE' in line:
                try:
                    experimental_data['r_factor'] = float(line.split()[-1])
                except:
                    pass
        
        # Secondary structure
        elif line.startswith('HELIX'):
            if 'helices' not in secondary_structure:
                secondary_structure['helices'] = []
            secondary_structure['helices'].append({
                'id': line[11:14].strip(),
                'chain': line[19:20].strip(),
                'start': int(line[21:25].strip()),
                'end': int(line[33:37].strip())
            })
        elif line.startswith('SHEET'):
            if 'sheets' not in secondary_structure:
                secondary_structure['sheets'] = []
            secondary_structure['sheets'].append({
                'strand': line[7:10].strip(),
                'chain': line[21:22].strip(),
                'start': int(line[22:26].strip()),
                'end': int(line[33:37].strip())
            })
        
        # Crystallographic data
        elif line.startswith('CRYST1'):
            crystallographic_info = {
                'a': float(line[6:15].strip()),
                'b': float(line[15:24].strip()),
                'c': float(line[24:33].strip()),
                'alpha': float(line[33:40].strip()),
                'beta': float(line[40:47].strip()),
                'gamma': float(line[47:54].strip()),
                'space_group': line[55:66].strip()
            }
        
        # Atom information with EVERYTHING
        elif line.startswith('ATOM'):
            atom_data = {
                'serial': int(line[6:11].strip()),
                'name': line[12:16].strip(),
                'residue': line[17:20].strip(),
                'chain': line[21:22].strip(),
                'residue_num': int(line[22:26].strip()),
                'x': float(line[30:38].strip()),
                'y': float(line[38:46].strip()),
                'z': float(line[46:54].strip()),
                'occupancy': float(line[54:60].strip()) if len(line) > 54 else 1.0,
                'b_factor': float(line[60:66].strip()) if len(line) > 60 else 0.0,
                'element': line[76:78].strip() if len(line) > 76 else line[12:14].strip(),
                'charge': line[78:80].strip() if len(line) > 78 else ''
            }
            atoms.append(atom_data)
            residues[atom_data['chain']].append(atom_data)
            chains.add(atom_data['chain'])
    
    return {
        'header_info': header_info,
        'atoms': atoms,
        'residues': residues,
        'chains': chains,
        'secondary_structure': secondary_structure,
        'crystallographic_info': crystallographic_info,
        'experimental_data': experimental_data
    }

# MAIN CONTENT - THE PROTEIN UNIVERSE
if pdb_files and selected_file:
    # Load and parse PDB file
    pdb_path = os.path.join(pdb_dir, selected_file)
    with open(pdb_path, "r") as f:
        pdb_content = f.read()
    
    # Parse the PDB file with EXTREME POWER
    parsed_data = parse_pdb_extreme(pdb_content)
    atoms = parsed_data['atoms']
    residues = parsed_data['residues']
    chains = parsed_data['chains']
    header_info = parsed_data['header_info']
    secondary_structure = parsed_data['secondary_structure']
    crystallographic_info = parsed_data['crystallographic_info']
    experimental_data = parsed_data['experimental_data']
    
    # INSANE TAB SYSTEM
    tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8, tab9 = st.tabs([
        "🧬 3D MOLECULAR THEATER", 
        "📊 DEEP STRUCTURAL ANALYSIS", 
        "🔬 SEQUENCE INTELLIGENCE",
        "🎨 CUSTOM VISUALIZATION STUDIO",
        "📈 INTERACTIVE SCIENTIFIC PLOTS",
        "🤖 AI MOLECULAR INSIGHTS",
        "⚡ MOLECULAR DYNAMICS",
        "💊 DRUG DISCOVERY SUITE",
        "🌌 NETWORK ANALYSIS"
    ])
    
    with tab1:
        st.markdown("## 🧬 MOLECULAR THEATER - 3D VISUALIZATION EXTREME")
        
        # Create columns for controls
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            show_water = st.checkbox("💧 Show Water", value=False)
            show_hetero = st.checkbox("⚗️ Show Heteroatoms", value=True)
            
        with col2:
            show_hydrogen = st.checkbox("⚪ Show Hydrogen", value=False)
            show_bonds = st.checkbox("🔗 Show Bonds", value=True)
            
        with col3:
            cartoon_thickness = st.slider("🎭 Cartoon Thickness", 0.1, 3.0, 1.0, 0.1)
            stick_radius = st.slider("🥢 Stick Radius", 0.1, 1.0, 0.3, 0.1)
            
        with col4:
            sphere_scale = st.slider("🔮 Sphere Scale", 0.1, 2.0, 1.0, 0.1)
            surface_probe = st.slider("🏄 Surface Probe", 1.0, 3.0, 1.4, 0.1)
        
        # ADVANCED VISUALIZATION WITH MULTIPLE VIEWS
        st.markdown("### 🎬 MULTIPLE ANGLE THEATER")
        
        view_cols = st.columns(2)
        
        with view_cols[0]:
            st.markdown("#### 🎯 PRIMARY VIEW")
            view1 = py3Dmol.view(width=400, height=400)
            view1.addModel(pdb_content, 'pdb')
            
            # Apply main styling
            if style_type == "cartoon":
                view1.setStyle({}, {"cartoon": {"color": color_scheme, "thickness": cartoon_thickness, "opacity": transparency}})
            elif style_type == "stick":
                view1.setStyle({}, {"stick": {"color": color_scheme, "radius": stick_radius, "opacity": transparency}})
            elif style_type == "sphere":
                view1.setStyle({}, {"sphere": {"color": color_scheme, "scale": sphere_scale, "opacity": transparency}})
            elif style_type == "surface":
                view1.setStyle({}, {"surface": {"color": color_scheme, "opacity": surface_opacity}})
            
            if show_hetero:
                view1.setStyle({"hetflag": True}, {"stick": {"color": "element", "radius": 0.5}})
            
            if show_water:
                view1.setStyle({"resn": "HOH"}, {"sphere": {"color": "blue", "radius": 0.3}})
            
            view1.setBackgroundColor(background)
            view1.zoomTo()
            showmol(view1, height=400, width=400)
        
        with view_cols[1]:
            st.markdown("#### 🌀 SECONDARY VIEW")
            view2 = py3Dmol.view(width=400, height=400)
            view2.addModel(pdb_content, 'pdb')
            
            # Different style for comparison
            view2.setStyle({}, {"cartoon": {"color": "spectrum", "thickness": 1.2}})
            view2.setStyle({"hetflag": True}, {"stick": {"color": "element"}})
            view2.setBackgroundColor("#1a1a1a")
            view2.rotate(90, "y")
            view2.zoomTo()
            showmol(view2, height=400, width=400)
        
        # CHAIN-SPECIFIC ANALYSIS
        if chains:
            st.markdown("### 🔗 CHAIN ISOLATION CHAMBER")
            chain_cols = st.columns(min(len(chains), 4))
            
            for i, chain in enumerate(sorted(chains)[:4]):
                with chain_cols[i]:
                    st.markdown(f"#### Chain {chain}")
                    
                    # Get color for this chain
                    palette_func = globals()[st.session_state.selected_palette]
                    chain_color = palette_func(i)
                    color_hex = f"#{chain_color[0]:02x}{chain_color[1]:02x}{chain_color[2]:02x}"
                    
                    view_chain = py3Dmol.view(width=300, height=300)
                    view_chain.addModel(pdb_content, 'pdb')
                    view_chain.setStyle({}, {"cartoon": {"color": "lightgray", "opacity": 0.2}})
                    view_chain.setStyle({"chain": chain}, {"cartoon": {"color": color_hex, "thickness": 1.5}})
                    view_chain.zoomTo({"chain": chain})
                    view_chain.setBackgroundColor("#000000")
                    showmol(view_chain, height=300, width=300)
                    
                    # Chain stats
                    chain_atoms = [atom for atom in atoms if atom['chain'] == chain]
                    st.metric("Atoms", len(chain_atoms))
                    st.metric("Residues", len(set([atom['residue_num'] for atom in chain_atoms])))
        
        # SURFACE ANALYSIS
        st.markdown("### 🏄 MOLECULAR SURFACE ANALYSIS")
        
        surface_cols = st.columns(3)
        
        with surface_cols[0]:
            st.markdown("#### ⚡ Electrostatic Surface")
            view_electro = py3Dmol.view(width=300, height=300)
            view_electro.addModel(pdb_content, 'pdb')
            view_electro.setStyle({}, {"cartoon": {"color": "gray", "opacity": 0.3}})
            view_electro.setStyle({}, {"surface": {"color": "rwb", "opacity": 0.8}})
            view_electro.setBackgroundColor("#000000")
            view_electro.zoomTo()
            showmol(view_electro, height=300, width=300)
            
        with surface_cols[1]:
            st.markdown("#### 💧 Hydrophobicity Surface")
            view_hydro = py3Dmol.view(width=300, height=300)
            view_hydro.addModel(pdb_content, 'pdb')
            view_hydro.setStyle({}, {"cartoon": {"color": "gray", "opacity": 0.3}})
            view_hydro.setStyle({}, {"surface": {"color": "hydrophobicity", "opacity": 0.8}})
            view_hydro.setBackgroundColor("#000000")
            view_hydro.zoomTo()
            showmol(view_hydro, height=300, width=300)
            
        with surface_cols[2]:
            st.markdown("#### 🌡️ B-Factor Surface")
            view_bfactor = py3Dmol.view(width=300, height=300)
            view_bfactor.addModel(pdb_content, 'pdb')
            view_bfactor.setStyle({}, {"cartoon": {"color": "bfactor", "opacity": 0.8}})
            view_bfactor.setBackgroundColor("#000000")
            view_bfactor.zoomTo()
            showmol(view_bfactor, height=300, width=300)
    
    with tab2:
        st.markdown("## 📊 DEEP STRUCTURAL ANALYSIS - MOLECULAR INTELLIGENCE")
        
        # COMPREHENSIVE STATISTICS DASHBOARD
        st.markdown("### 🎯 MOLECULAR STATISTICS COMMAND CENTER")
        
        # Create metrics with extreme detail
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.markdown("""
            <div class="metric-card">
                <h4>⚛️ Total Atoms</h4>
                <h1 style="color: #00ffa1;">{}</h1>
                <p>Atomic Universe</p>
            </div>
            """.format(len(atoms)), unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div class="metric-card">
                <h4>🔗 Protein Chains</h4>
                <h1 style="color: #ff006e;">{}</h1>
                <p>Molecular Strings</p>
            </div>
            """.format(len(chains)), unsafe_allow_html=True)
###Part2
        with col3:
            unique_residues = len(set([atom['residue'] for atom in atoms]))
            st.markdown("""
            <div class="metric-card">
                <h4>🧬 Amino Acid Types</h4>    
                <h1 style="color: #8338ec;">{}</h1>
               <p>Building Blocks</p>
           </div>
           """.format(unique_residues), unsafe_allow_html=True)
        
        with col4:
            total_residues = len(set([(atom['chain'], atom['residue_num']) for atom in atoms]))
            st.markdown("""
            <div class="metric-card">
                <h4>🏗️ Total Residues</h4>
                <h1 style="color: #3a86ff;">{}</h1>
                <p>Structural Units</p>
            </div>
            """.format(total_residues), unsafe_allow_html=True)
        
        with col5:
            # Calculate molecular weight
            avg_residue_weight = 110  # Average amino acid weight
            estimated_mw = total_residues * avg_residue_weight / 1000
            st.markdown("""
            <div class="metric-card">
                <h4>⚖️ Molecular Weight</h4>
                <h1 style="color: #06ffa5;">{:.1f}</h1>
                <p>kDa (estimated)</p>
            </div>
            """.format(estimated_mw), unsafe_allow_html=True)
        
        # ADVANCED COMPOSITIONAL ANALYSIS
        st.markdown("### 🧪 MOLECULAR COMPOSITION MATRIX")
        
        comp_cols = st.columns(2)
        
        with comp_cols[0]:
            st.markdown("#### 🧬 Amino Acid Universe")
            
            # Enhanced residue analysis
            residue_counts = Counter([atom['residue'] for atom in atoms])
            
            # Amino acid classification with properties
            aa_properties = {
                'Hydrophobic': {'residues': ['ALA', 'VAL', 'LEU', 'ILE', 'PRO', 'PHE', 'TRP', 'MET'], 'color': '#ff6b6b'},
                'Polar': {'residues': ['SER', 'THR', 'TYR', 'CYS', 'ASN', 'GLN'], 'color': '#4ecdc4'},
                'Positively Charged': {'residues': ['LYS', 'ARG', 'HIS'], 'color': '#45b7d1'},
                'Negatively Charged': {'residues': ['ASP', 'GLU'], 'color': '#96ceb4'},
                'Special': {'residues': ['GLY', 'PRO'], 'color': '#ffeaa7'}
            }
            
            residue_df = pd.DataFrame(list(residue_counts.items()), columns=['Residue', 'Count'])
            residue_df['Percentage'] = (residue_df['Count'] / residue_df['Count'].sum() * 100).round(2)
            
            # Classify residues
            residue_df['Category'] = 'Other'
            residue_df['Color'] = '#ddd'
            for category, props in aa_properties.items():
                mask = residue_df['Residue'].isin(props['residues'])
                residue_df.loc[mask, 'Category'] = category
                residue_df.loc[mask, 'Color'] = props['color']
            
            # Create advanced pie chart with custom colors
            colors = residue_df['Color'].tolist()
            
            fig_pie = go.Figure(data=[go.Pie(
                labels=residue_df['Residue'],
                values=residue_df['Count'],
                marker_colors=colors,
                textinfo='label+percent',
                hovertemplate='<b>%{label}</b><br>Count: %{value}<br>Percentage: %{percent}<extra></extra>',
                hole=0.3
            )])
            
            fig_pie.update_layout(
                title="Amino Acid Composition Galaxy",
                font=dict(size=12),
                showlegend=True,
                height=500
            )
            st.plotly_chart(fig_pie, use_container_width=True)
            
            # Category breakdown
            category_counts = residue_df.groupby('Category')['Count'].sum().sort_values(ascending=False)
            fig_cat = px.bar(
                x=category_counts.index,
                y=category_counts.values,
                color=category_counts.index,
                title="Amino Acid Categories"
            )
            fig_cat.update_layout(showlegend=False)
            st.plotly_chart(fig_cat, use_container_width=True)
        
        with comp_cols[1]:
            st.markdown("#### ⚛️ Atomic Element Matrix")
            
            element_counts = Counter([atom['element'] for atom in atoms])
            element_df = pd.DataFrame(list(element_counts.items()), columns=['Element', 'Count'])
            element_df['Percentage'] = (element_df['Count'] / element_df['Count'].sum() * 100).round(2)
            
            # Element colors (CPK coloring)
            element_colors = {
                'C': '#909090', 'N': '#3050f8', 'O': '#ff0d0d', 'S': '#ffff30',
                'P': '#ff8000', 'H': '#ffffff', 'FE': '#e06633', 'ZN': '#7d80b0',
                'MG': '#8aff00', 'CA': '#3dff00', 'NA': '#ab5cf2', 'CL': '#1ff01f'
            }
            
            colors = [element_colors.get(elem, '#gray') for elem in element_df['Element']]
            
            fig_elements = go.Figure(data=[go.Bar(
                x=element_df['Element'],
                y=element_df['Count'],
                marker_color=colors,
                text=element_df['Percentage'],
                texttemplate='%{text}%',
                textposition='outside',
                hovertemplate='<b>%{x}</b><br>Count: %{y}<br>Percentage: %{text}%<extra></extra>'
            )])
            
            fig_elements.update_layout(
                title="Atomic Element Distribution",
                xaxis_title="Element",
                yaxis_title="Count",
                height=400
            )
            st.plotly_chart(fig_elements, use_container_width=True)
            
            # Element properties table
            st.markdown("##### 📊 Element Properties")
            element_df['Atomic Number'] = element_df['Element'].map({
                'H': 1, 'C': 6, 'N': 7, 'O': 8, 'P': 15, 'S': 16
            })
            st.dataframe(element_df, use_container_width=True)
        
        # GEOMETRIC ANALYSIS EXTREME
        st.markdown("### 📐 GEOMETRIC UNIVERSE ANALYSIS")
        
        if len(atoms) > 0:
            coords = np.array([[atom['x'], atom['y'], atom['z']] for atom in atoms])
            
            # Calculate comprehensive geometric properties
            center_of_mass = np.mean(coords, axis=0)
            min_coords = np.min(coords, axis=0)
            max_coords = np.max(coords, axis=0)
            dimensions = max_coords - min_coords
            
            # Calculate radius of gyration
            distances_from_com = np.linalg.norm(coords - center_of_mass, axis=1)
            radius_of_gyration = np.sqrt(np.mean(distances_from_com**2))
            
            # Calculate geometric center
            geometric_center = (min_coords + max_coords) / 2
            
            geo_cols = st.columns(3)
            
            with geo_cols[0]:
                st.markdown("##### 🎯 Center of Mass")
                st.metric("X", f"{center_of_mass[0]:.2f} Å")
                st.metric("Y", f"{center_of_mass[1]:.2f} Å")
                st.metric("Z", f"{center_of_mass[2]:.2f} Å")
                
            with geo_cols[1]:
                st.markdown("##### 📏 Protein Dimensions")
                st.metric("Width (X)", f"{dimensions[0]:.2f} Å")
                st.metric("Height (Y)", f"{dimensions[1]:.2f} Å")
                st.metric("Depth (Z)", f"{dimensions[2]:.2f} Å")
                
            with geo_cols[2]:
                st.markdown("##### 🌀 Advanced Properties")
                st.metric("Radius of Gyration", f"{radius_of_gyration:.2f} Å")
                st.metric("Volume (approx)", f"{np.prod(dimensions):.0f} Ų")
                st.metric("Aspect Ratio", f"{max(dimensions)/min(dimensions):.2f}")
            
            # 3D visualization of geometric properties
            st.markdown("##### 🌌 Geometric Visualization")
            
            # Create 3D plot showing protein shape and properties
            fig_geo = go.Figure()
            
            # Sample points for visualization
            sample_coords = coords[::max(1, len(coords)//1000)]
            
            fig_geo.add_trace(go.Scatter3d(
                x=sample_coords[:, 0],
                y=sample_coords[:, 1],
                z=sample_coords[:, 2],
                mode='markers',
                marker=dict(
                    size=2,
                    color=sample_coords[:, 2],  # Color by Z coordinate
                    colorscale='Viridis',
                    opacity=0.6
                ),
                name='Protein Atoms'
            ))
            
            # Add center of mass
            fig_geo.add_trace(go.Scatter3d(
                x=[center_of_mass[0]],
                y=[center_of_mass[1]],
                z=[center_of_mass[2]],
                mode='markers',
                marker=dict(size=10, color='red'),
                name='Center of Mass'
            ))
            
            # Add bounding box
            box_x = [min_coords[0], max_coords[0], max_coords[0], min_coords[0], min_coords[0],
                        min_coords[0], max_coords[0], max_coords[0], min_coords[0]]
            box_y = [min_coords[1], min_coords[1], max_coords[1], max_coords[1], min_coords[1],
                        min_coords[1], min_coords[1], max_coords[1], max_coords[1]]
            box_z = [min_coords[2], min_coords[2], min_coords[2], min_coords[2], min_coords[2],
                        max_coords[2], max_coords[2], max_coords[2], max_coords[2]]
            
            fig_geo.add_trace(go.Scatter3d(
                x=box_x, y=box_y, z=box_z,
                mode='lines',
                line=dict(color='orange', width=5),
                name='Bounding Box'
            ))
            
            fig_geo.update_layout(
                title="Protein Geometric Analysis",
                scene=dict(
                    xaxis_title="X (Å)",
                    yaxis_title="Y (Å)",
                    zaxis_title="Z (Å)",
                    bgcolor="black"
                ),
                height=600
            )
            st.plotly_chart(fig_geo, use_container_width=True)
        
        # SECONDARY STRUCTURE ANALYSIS
        if secondary_structure:
            st.markdown("### 🌀 SECONDARY STRUCTURE UNIVERSE")
            
            sec_cols = st.columns(2)
            
            with sec_cols[0]:
                if 'helices' in secondary_structure:
                    st.markdown("#### 🌀 Alpha Helices")
                    helix_df = pd.DataFrame(secondary_structure['helices'])
                    st.dataframe(helix_df, use_container_width=True)
                    
                    # Helix length distribution
                    helix_df['length'] = helix_df['end'] - helix_df['start'] + 1
                    fig_helix = px.histogram(helix_df, x='length', title="Helix Length Distribution")
                    st.plotly_chart(fig_helix, use_container_width=True)
            
            with sec_cols[1]:
                if 'sheets' in secondary_structure:
                    st.markdown("#### 📄 Beta Sheets")
                    sheet_df = pd.DataFrame(secondary_structure['sheets'])
                    st.dataframe(sheet_df, use_container_width=True)
                    
                    # Sheet length distribution
                    sheet_df['length'] = sheet_df['end'] - sheet_df['start'] + 1
                    fig_sheet = px.histogram(sheet_df, x='length', title="Sheet Length Distribution")
                    st.plotly_chart(fig_sheet, use_container_width=True)
        
        # EXPERIMENTAL DATA ANALYSIS
        if experimental_data:
            st.markdown("### 🔬 EXPERIMENTAL DATA MATRIX")
            
            exp_cols = st.columns(3)
            
            with exp_cols[0]:
                if 'method' in experimental_data:
                    st.markdown(f"**Experimental Method:** {experimental_data['method']}")
                    
            with exp_cols[1]:
                if 'resolution' in experimental_data:
                    st.metric("Resolution", f"{experimental_data['resolution']:.2f} Å")
                    
            with exp_cols[2]:
                if 'r_factor' in experimental_data:
                    st.metric("R-Factor", f"{experimental_data['r_factor']:.3f}")
        
        # CRYSTALLOGRAPHIC ANALYSIS
        if crystallographic_info:
            st.markdown("### 💎 CRYSTALLOGRAPHIC UNIVERSE")
            
            cryst_cols = st.columns(3)
            
            with cryst_cols[0]:
                st.markdown("#### 📏 Unit Cell Parameters")
                st.metric("a", f"{crystallographic_info['a']:.2f} Å")
                st.metric("b", f"{crystallographic_info['b']:.2f} Å")
                st.metric("c", f"{crystallographic_info['c']:.2f} Å")
                
            with cryst_cols[1]:
                st.markdown("#### 📐 Unit Cell Angles")
                st.metric("α", f"{crystallographic_info['alpha']:.2f}°")
                st.metric("β", f"{crystallographic_info['beta']:.2f}°")
                st.metric("γ", f"{crystallographic_info['gamma']:.2f}°")
                
            with cryst_cols[2]:
                st.markdown("#### 🏗️ Crystal System")
                st.metric("Space Group", crystallographic_info['space_group'])
                
                # Calculate unit cell volume
                a, b, c = crystallographic_info['a'], crystallographic_info['b'], crystallographic_info['c']
                alpha, beta, gamma = (np.radians(crystallographic_info[angle]) 
                                    for angle in ['alpha', 'beta', 'gamma'])
                
                volume = a * b * c * np.sqrt(1 + 2*np.cos(alpha)*np.cos(beta)*np.cos(gamma) - 
                                            np.cos(alpha)**2 - np.cos(beta)**2 - np.cos(gamma)**2)
                st.metric("Unit Cell Volume", f"{volume:.0f} ų")
    
    with tab3:
        st.markdown("## 🔬 SEQUENCE INTELLIGENCE - MOLECULAR GENETICS")
        
        # Extract and analyze sequences
        sequences = {}
        sequence_properties = {}
        
        for chain in chains:
            chain_residues = []
            seen_residues = set()
            for atom in atoms:
                if atom['chain'] == chain:
                    residue_key = (atom['residue_num'], atom['residue'])
                    if residue_key not in seen_residues:
                        chain_residues.append((atom['residue_num'], atom['residue']))
                        seen_residues.add(residue_key)
            
            # Sort by residue number
            chain_residues.sort(key=lambda x: x[0])
            sequences[chain] = [residue[1] for residue in chain_residues]
        
        # Amino acid conversion
        aa_map = {
            'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C',
            'GLU': 'E', 'GLN': 'Q', 'GLY': 'G', 'HIS': 'H', 'ILE': 'I',
            'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P',
            'SER': 'S', 'THR': 'T', 'TRP': 'W', 'TYR': 'Y', 'VAL': 'V'
        }
        
        # SEQUENCE ANALYSIS FOR EACH CHAIN
        for chain, sequence in sequences.items():
            st.markdown(f"### 🧬 Chain {chain} - Molecular String Analysis")
            
            # Convert to single letter code
            single_letter = ''.join([aa_map.get(res, 'X') for res in sequence])
            
            # Display sequence in a beautiful format
            st.markdown("#### 📝 Primary Sequence")
            chunk_size = 50
            sequence_display = ""
            for i in range(0, len(single_letter), chunk_size):
                chunk = single_letter[i:i+chunk_size]
                sequence_display += f"{i+1:4d}: {chunk}\n"
            
            st.code(sequence_display, language="text")
            
            # COMPREHENSIVE SEQUENCE ANALYSIS
            seq_cols = st.columns(4)
            
            with seq_cols[0]:
                st.metric("Length", len(sequence))
                
            with seq_cols[1]:
                # Approximate molecular weight
                molecular_weight = sum([
                    {'A': 89, 'R': 174, 'N': 132, 'D': 133, 'C': 121, 'E': 147, 'Q': 146,
                        'G': 75, 'H': 155, 'I': 131, 'L': 131, 'K': 146, 'M': 149, 'F': 165,
                        'P': 115, 'S': 105, 'T': 119, 'W': 204, 'Y': 181, 'V': 117}.get(aa_map.get(res, 'A'), 110)
                    for res in sequence
                ])
                st.metric("Molecular Weight", f"{molecular_weight/1000:.1f} kDa")
                
            with seq_cols[2]:
                # Calculate net charge at pH 7
                charge = sum([
                    1 if res in ['LYS', 'ARG'] else (-1 if res in ['ASP', 'GLU'] else 0)
                    for res in sequence
                ])
                st.metric("Net Charge (pH 7)", charge)
                
            with seq_cols[3]:
                # Calculate isoelectric point (simplified)
                positive = sum([1 for res in sequence if res in ['LYS', 'ARG']])
                negative = sum([1 for res in sequence if res in ['ASP', 'GLU']])
                estimated_pi = 7 + (positive - negative) * 0.5  # Very simplified
                st.metric("Est. Isoelectric Point", f"{estimated_pi:.1f}")
            
            # ADVANCED SEQUENCE PROPERTIES
            if single_letter and len(single_letter) > 10:  # Only analyze if we have a reasonable sequence
                st.markdown("#### 🧪 Advanced Sequence Properties")
                
                try:
                    # Hydrophobicity analysis with multiple scales
                    hydrophobicity_scales = {
                        'Kyte-Doolittle': {
                            'A': 1.8, 'R': -4.5, 'N': -3.5, 'D': -3.5, 'C': 2.5,
                            'Q': -3.5, 'E': -3.5, 'G': -0.4, 'H': -3.2, 'I': 4.5,
                            'L': 3.8, 'K': -3.9, 'M': 1.9, 'F': 2.8, 'P': -1.6,
                            'S': -0.8, 'T': -0.7, 'W': -0.9, 'Y': -1.3, 'V': 4.2
                        },
                        'Eisenberg': {
                            'A': 0.62, 'R': -2.53, 'N': -0.78, 'D': -0.90, 'C': 0.29,
                            'Q': -0.85, 'E': -0.74, 'G': 0.48, 'H': -0.40, 'I': 1.38,
                            'L': 1.06, 'K': -1.50, 'M': 0.64, 'F': 1.19, 'P': 0.12,
                            'S': -0.18, 'T': -0.05, 'W': 0.81, 'Y': 0.26, 'V': 1.08
                        }
                    }
                    
                    # Calculate hydrophobicity profiles
                    fig_hydro = go.Figure()
                    
                    for scale_name, scale in hydrophobicity_scales.items():
                        hydrophobicity = [scale.get(aa, 0) for aa in single_letter]
                        
                        # Moving average for smoothing
                        window_size = min(9, len(hydrophobicity))
                        if len(hydrophobicity) >= window_size:
                            smoothed = np.convolve(hydrophobicity, np.ones(window_size)/window_size, mode='valid')
                            positions = list(range(window_size//2 + 1, len(hydrophobicity) - window_size//2 + 1))
                        else:
                            smoothed = hydrophobicity
                            positions = list(range(1, len(hydrophobicity) + 1))
                        
                        # Get color for this scale
                        palette_func = globals()[st.session_state.selected_palette]
                        color = palette_func(hash(scale_name) % 10)
                        color_string = f"rgb({color[0]},{color[1]},{color[2]})"
                        
                        fig_hydro.add_trace(go.Scatter(
                            x=positions, y=smoothed,
                            mode='lines+markers',
                            name=f'{scale_name} Scale',
                            line=dict(color=color_string, width=3),
                            marker=dict(size=4)
                        ))
                    
                    fig_hydro.update_layout(
                        title=f"Hydrophobicity Profile - Chain {chain}",
                        xaxis_title="Residue Position",
                        yaxis_title="Hydrophobicity Score",
                        template="plotly_dark",
                        height=400
                    )
                    fig_hydro.add_hline(y=0, line_dash="dash", line_color="gray")
                    
                    st.plotly_chart(fig_hydro, use_container_width=True)
                    
                except Exception as e:
                    st.warning(f"Advanced analysis limited: {e}")
            
            # AMINO ACID COMPOSITION ANALYSIS
            st.markdown("#### 📊 Amino Acid Composition Matrix")
            
            # Count amino acids in this chain
            chain_aa_counts = Counter([aa_map.get(res, 'X') for res in sequence])
            
            # Create composition dataframe
            composition_data = []
            for aa, count in chain_aa_counts.items():
                percentage = (count / len(sequence)) * 100
                composition_data.append({
                    'Amino Acid': aa,
                    'Count': count,
                    'Percentage': percentage,
                    'Properties': get_aa_properties(aa)
                })
            
            composition_df = pd.DataFrame(composition_data)
            composition_df = composition_df.sort_values('Count', ascending=False)
            
            # Visualize composition
            comp_cols = st.columns(2)
            
            with comp_cols[0]:
                # Bar chart of composition
                palette_func = globals()[st.session_state.selected_palette]
                colors = [palette_func(i) for i in range(len(composition_df))]
                color_strings = [f"rgb({r},{g},{b})" for r, g, b in colors]
                
                fig_comp = px.bar(
                    composition_df, 
                    x='Amino Acid', 
                    y='Percentage',
                    title=f"Chain {chain} Composition",
                    color='Amino Acid',
                    color_discrete_sequence=color_strings
                )
                fig_comp.update_layout(showlegend=False, height=400)
                st.plotly_chart(fig_comp, use_container_width=True)
            
            with comp_cols[1]:
                # Properties pie chart
                property_counts = composition_df.groupby('Properties')['Count'].sum()
                
                fig_props = px.pie(
                    values=property_counts.values,
                    names=property_counts.index,
                    title=f"Chain {chain} - Property Distribution"
                )
                fig_props.update_traces(textposition='inside', textinfo='percent+label')
                st.plotly_chart(fig_props, use_container_width=True)
            
            # Display composition table
            st.dataframe(composition_df, use_container_width=True)
        
        # SEQUENCE COMPARISON (if multiple chains)
        if len(sequences) > 1:
            st.markdown("### 🔗 INTER-CHAIN SEQUENCE COMPARISON")
            
            # Calculate sequence similarities
            similarity_matrix = np.zeros((len(sequences), len(sequences)))
            chain_list = list(sequences.keys())
            
            for i, chain1 in enumerate(chain_list):
                for j, chain2 in enumerate(chain_list):
                    if i != j:
                        seq1 = ''.join([aa_map.get(res, 'X') for res in sequences[chain1]])
                        seq2 = ''.join([aa_map.get(res, 'X') for res in sequences[chain2]])
                        
                        # Simple sequence similarity (could be improved with proper alignment)
                        min_len = min(len(seq1), len(seq2))
                        if min_len > 0:
                            matches = sum(a == b for a, b in zip(seq1[:min_len], seq2[:min_len]))
                            similarity = matches / min_len
                        else:
                            similarity = 0
                        similarity_matrix[i][j] = similarity
                    else:
                        similarity_matrix[i][j] = 1.0
            
            # Visualize similarity matrix
            fig_sim = go.Figure(data=go.Heatmap(
                z=similarity_matrix,
                x=chain_list,
                y=chain_list,
                colorscale='Viridis',
                text=np.round(similarity_matrix, 3),
                texttemplate="%{text}",
                textfont={"size": 12}
            ))
            
            fig_sim.update_layout(
                title="Chain Sequence Similarity Matrix",
                xaxis_title="Chain",
                yaxis_title="Chain",
                height=400
            )
            st.plotly_chart(fig_sim, use_container_width=True)
    
    with tab4:
        st.markdown("## 🎨 CUSTOM VISUALIZATION STUDIO - MOLECULAR ARTISTRY")
        
        # EXTREME CUSTOM SELECTION INTERFACE
        st.markdown("### 🎭 MOLECULAR SELECTION THEATER")
        
        sel_cols = st.columns(3)
        
        with sel_cols[0]:
            st.markdown("#### 🔗 Chain Universe")
            select_chains = st.multiselect("Select Chains:", list(chains), default=list(chains))
            
            # Residue range selection with advanced controls
            if atoms:
                min_res = min([atom['residue_num'] for atom in atoms])
                max_res = max([atom['residue_num'] for atom in atoms])
                
                st.markdown("#### 📏 Residue Range Matrix")
                use_range = st.checkbox("Enable Residue Range Filter")
                if use_range:
                    res_range = st.slider("Residue Range:", min_res, max_res, (min_res, max_res))
                else:
                    res_range = (min_res, max_res)
                
                # Advanced residue selection
                st.markdown("#### 🧬 Specific Residue Selection")
                residue_selection_mode = st.radio("Selection Mode:", 
                    ["All Residues", "By Type", "Custom List"])
                
                if residue_selection_mode == "By Type":
                    residue_types = st.multiselect("Residue Categories:", [
                        "Hydrophobic", "Polar", "Positively Charged", "Negatively Charged", "Special"
                    ])
                elif residue_selection_mode == "Custom List":
                    custom_residues = st.text_input("Enter residue numbers (comma-separated):", "")
                    if custom_residues:
                        custom_res_list = [int(x.strip()) for x in custom_residues.split(",") if x.strip().isdigit()]
                    else:
                        custom_res_list = []
        
        with sel_cols[1]:
            st.markdown("#### ⚛️ Element Matrix")
            unique_elements = sorted(list(set([atom['element'] for atom in atoms])))
            select_elements = st.multiselect("Select Elements:", unique_elements, default=unique_elements)
            
            st.markdown("#### 🏗️ Structural Components")
            structural_components = st.multiselect("Include:", [
                "🧬 Protein Backbone", 
                "🔗 Side Chains", 
                "💧 Water Molecules", 
                "⚗️ Ligands/Cofactors",
                "🧲 Metal Ions"
            ])
            
            st.markdown("#### 🎯 Advanced Filters")
            bfactor_filter = st.checkbox("Filter by B-Factor")
            if bfactor_filter:
                max_bfactor = st.slider("Max B-Factor:", 0.0, 100.0, 50.0)
            
            occupancy_filter = st.checkbox("Filter by Occupancy")
            if occupancy_filter:
                min_occupancy = st.slider("Min Occupancy:", 0.0, 1.0, 0.5)
        
        with sel_cols[2]:
            st.markdown("#### 🎨 Artistic Style Matrix")
            custom_style = st.selectbox("Primary Style:", 
                ["cartoon", "stick", "sphere", "surface", "line", "ribbon", "trace"])
###Part3          
            secondary_style = st.selectbox("Secondary Style (overlay):", 
                ["None", "stick", "sphere", "line", "dots"])
            

            
            st.markdown("#### 🌈 Color Universe")
            color_mode = st.selectbox("Coloring Scheme:", [
                "spectrum", "element", "residue", "chainbow", "secondary", 
                "hydrophobicity", "bfactor", "charge", "custom"
            ])
            
            if color_mode == "custom":
                custom_color_scheme = st.selectbox("Custom Scheme:", [
                    "🎬 Wes Anderson", "🌈 Retro 80s", "🌙 Synthwave", 
                    "🔬 Scientific", "🎨 Artist Palette"
                ])
            
            st.markdown("#### ✨ Effects & Enhancements")
            apply_effects = st.multiselect("Visual Effects:", [
                "🌟 Glow Effect", "💫 Transparency Gradient", 
                "🌊 Surface Waves", "⚡ Electric Field", "🔥 Heat Map"
            ])
        
        # REAL-TIME PREVIEW GENERATION
        st.markdown("### 🎬 LIVE PREVIEW THEATER")
        
        if st.button("🚀 GENERATE EXTREME VISUALIZATION", type="primary"):
            # Create the most insane visualization possible
            preview_cols = st.columns(2)
            
            with preview_cols[0]:
                st.markdown("#### 🎯 Primary Visualization")
                
                custom_view = py3Dmol.view(width=500, height=500)
                custom_view.addModel(pdb_content, 'pdb')
                
                # Set background based on effects
                if "🌙 Dark Mode" in apply_effects:
                    bg_color = "#000000"
                elif "🌟 Glow Effect" in apply_effects:
                    bg_color = "#0a0a0a"
                else:
                    bg_color = "#ffffff"
                
                custom_view.setBackgroundColor(bg_color)
                
                # Build selection criteria
                selection = {}
                
                # Chain selection
                if select_chains and len(select_chains) < len(chains):
                    selection["chain"] = select_chains
                
                # Element selection
                if select_elements and len(select_elements) < len(unique_elements):
                    selection["elem"] = select_elements
                
                # Residue range
                if use_range:
                    selection["resi"] = f"{res_range[0]}-{res_range[1]}"
                
                # Apply base style (very subtle)
                custom_view.setStyle({}, {"cartoon": {"color": "lightgray", "opacity": 0.1}})
                
                # Apply primary style
                style_dict = {}
                if custom_style == "cartoon":
                    style_dict = {"cartoon": {"color": color_mode, "thickness": 1.5, "opacity": 0.9}}
                elif custom_style == "stick":
                    style_dict = {"stick": {"color": color_mode, "radius": 0.3}}
                elif custom_style == "sphere":
                    style_dict = {"sphere": {"color": color_mode, "scale": 1.0}}
                elif custom_style == "surface":
                    style_dict = {"surface": {"color": color_mode, "opacity": 0.8}}
                elif custom_style == "line":
                    style_dict = {"line": {"color": color_mode}}
                elif custom_style == "ribbon":
                    style_dict = {"ribbon": {"color": color_mode, "thickness": 1.0}}
                elif custom_style == "trace":
                    style_dict = {"trace": {"color": color_mode}}
                
                custom_view.setStyle(selection, style_dict)
                
                # Apply secondary style if selected
                if secondary_style != "None":
                    if secondary_style == "stick":
                        custom_view.setStyle(selection, {"stick": {"color": "element", "radius": 0.2}})
                    elif secondary_style == "sphere":
                        custom_view.setStyle(selection, {"sphere": {"color": "element", "scale": 0.5}})
                
                # Apply structural components
                if "💧 Water Molecules" in structural_components:
                    custom_view.setStyle({"resn": "HOH"}, {"sphere": {"color": "blue", "radius": 0.3}})
                
                if "⚗️ Ligands/Cofactors" in structural_components:
                    custom_view.setStyle({"hetflag": True}, {"stick": {"color": "element", "radius": 0.5}})
                
                custom_view.zoomTo(selection if selection else {})
                showmol(custom_view, height=500, width=500)
            
            with preview_cols[1]:
                st.markdown("#### 🌀 Alternative View")
                
                alt_view = py3Dmol.view(width=500, height=500)
                alt_view.addModel(pdb_content, 'pdb')
                
                # Create a contrasting view
                alt_view.setStyle({}, {"surface": {"color": "hydrophobicity", "opacity": 0.7}})
                alt_view.setStyle(selection, {"cartoon": {"color": "secondary", "thickness": 2.0}})
                alt_view.setBackgroundColor("#1a1a1a")
                alt_view.rotate(45, "x")
                alt_view.rotate(45, "y")
                alt_view.zoomTo(selection if selection else {})
                showmol(alt_view, height=500, width=500)
        
        # ANIMATION CONTROLS
        st.markdown("### 🎬 ANIMATION STUDIO")
        
        anim_cols = st.columns(3)
        
        with anim_cols[0]:
            st.markdown("#### 🔄 Rotation Animation")
            rotation_speed = st.slider("Rotation Speed", 0.0, 5.0, 1.0)
            rotation_axis = st.selectbox("Rotation Axis", ["x", "y", "z", "xy", "xyz"])
            
        with anim_cols[1]:
            st.markdown("#### 🌊 Morphing Animation")
            morph_between = st.multiselect("Morph Between Styles:", 
                ["cartoon", "stick", "sphere", "surface"])
            morph_speed = st.slider("Morph Speed", 0.1, 2.0, 1.0)
            
        with anim_cols[2]:
            st.markdown("#### ⚡ Dynamic Effects")
            dynamic_coloring = st.checkbox("Dynamic Color Changes")
            breathing_effect = st.checkbox("Breathing Effect")
            particle_system = st.checkbox("Particle System Overlay")
        
        if st.button("🎬 GENERATE ANIMATION PREVIEW"):
            st.info("🎬 Animation preview would be generated here! (Requires WebGL animation framework)")
        
        # SAVE/EXPORT SYSTEM
        st.markdown("### 💾 VISUALIZATION EXPORT SYSTEM")
        
        export_cols = st.columns(4)
        
        with export_cols[0]:
            st.markdown("#### 📸 Image Export")
            image_format = st.selectbox("Format:", ["PNG", "JPG", "SVG"])
            image_resolution = st.selectbox("Resolution:", ["720p", "1080p", "4K", "8K"])
            
        with export_cols[1]:
            st.markdown("#### 🎬 Video Export")
            video_format = st.selectbox("Format:", ["MP4", "WebM", "GIF"])
            video_quality = st.selectbox("Quality:", ["Standard", "High", "Ultra"])
            
        with export_cols[2]:
            st.markdown("#### 🔬 Scientific Export")
            scientific_format = st.selectbox("Format:", ["PDB", "mol2", "SDF", "xyz"])
            include_metadata = st.checkbox("Include Analysis Metadata")
            
        with export_cols[3]:
            st.markdown("#### 🎨 Interactive Export")
            interactive_format = st.selectbox("Format:", ["HTML", "WebGL", "Jupyter"])
            include_controls = st.checkbox("Include Interactive Controls")
        
        # PRESET GALLERY
        st.markdown("### 🎨 PRESET VISUALIZATION GALLERY")
        
        preset_cols = st.columns(4)
        
        presets = [
            {"name": "🧬 DNA Helix", "style": "cartoon", "color": "chainbow"},
            {"name": "⚗️ Active Site", "style": "stick", "color": "element"},
            {"name": "🌊 Hydrophobic Surface", "style": "surface", "color": "hydrophobicity"},
            {"name": "🔥 B-Factor Heat", "style": "cartoon", "color": "bfactor"},
            {"name": "⚡ Electrostatic", "style": "surface", "color": "charge"},
            {"name": "🎭 Artistic Rainbow", "style": "ribbon", "color": "spectrum"},
            {"name": "🔬 Scientific View", "style": "cartoon", "color": "secondary"},
            {"name": "🎮 Gamer Style", "style": "sphere", "color": "element"}
        ]
        
        for i, preset in enumerate(presets):
            with preset_cols[i % 4]:
                if st.button(preset["name"], key=f"preset_{i}"):
                    st.session_state.selected_preset = preset
                    st.success(f"Applied preset: {preset['name']}")
    
    with tab5:
        st.markdown("## 📈 INTERACTIVE SCIENTIFIC PLOTS - DATA UNIVERSE")
        
        # B-FACTOR ANALYSIS EXTREME
        st.markdown("### 🌡️ B-FACTOR THERMAL ANALYSIS")
        
        b_factors = []
        for atom in atoms:
            if 'b_factor' in atom and atom['b_factor'] > 0:
                b_factors.append({
                    'residue_num': atom['residue_num'],
                    'chain': atom['chain'],
                    'residue': atom['residue'],
                    'atom_name': atom['name'],
                    'b_factor': atom['b_factor'],
                    'element': atom['element']
                })
        
        if b_factors:
            b_factor_df = pd.DataFrame(b_factors)
            
            bf_cols = st.columns(2)
            
            with bf_cols[0]:
                # B-factors by position with advanced visualization
                fig_bf = go.Figure()
                
                # Group by chain for different colors
                for chain in sorted(b_factor_df['chain'].unique()):
                    chain_data = b_factor_df[b_factor_df['chain'] == chain]
                    
                    # Get color for this chain
                    palette_func = globals()[st.session_state.selected_palette]
                    color = palette_func(ord(chain) % 12)
                    color_string = f"rgb({color[0]},{color[1]},{color[2]})"
                    
                    fig_bf.add_trace(go.Scatter(
                        x=chain_data['residue_num'],
                        y=chain_data['b_factor'],
                        mode='markers+lines',
                        name=f'Chain {chain}',
                        marker=dict(
                            color=color_string,
                            size=6,
                            line=dict(width=1, color='white')
                        ),
                        line=dict(color=color_string, width=2),
                        hovertemplate='<b>Chain %{text}</b><br>' +
                                    'Residue: %{x}<br>' +
                                    'B-Factor: %{y:.2f}<br>' +
                                    '<extra></extra>',
                        text=[chain] * len(chain_data)
                    ))
                
                fig_bf.update_layout(
                    title="B-Factor Thermal Landscape",
                    xaxis_title="Residue Number",
                    yaxis_title="B-Factor (Ų)",
                    template="plotly_dark",
                    height=500
                )
                
                # Add flexibility regions
                mean_bf = b_factor_df['b_factor'].mean()
                std_bf = b_factor_df['b_factor'].std()
                
                fig_bf.add_hline(y=mean_bf, line_dash="dash", line_color="yellow", 
                                annotation_text="Mean B-Factor")
                fig_bf.add_hline(y=mean_bf + std_bf, line_dash="dot", line_color="red",
                                annotation_text="High Flexibility")
                fig_bf.add_hline(y=mean_bf - std_bf, line_dash="dot", line_color="blue",
                                annotation_text="Low Flexibility")
                
                st.plotly_chart(fig_bf, use_container_width=True)
            
            with bf_cols[1]:
                # B-factor distribution analysis
                fig_bf_dist = go.Figure()
                
                # Overall distribution
                fig_bf_dist.add_trace(go.Histogram(
                    x=b_factor_df['b_factor'],
                    nbinsx=50,
                    name='Overall',
                    opacity=0.7,
                    marker_color='lightblue'
                ))
                
                # Distribution by chain
                for chain in sorted(b_factor_df['chain'].unique()):
                    chain_data = b_factor_df[b_factor_df['chain'] == chain]
                    fig_bf_dist.add_trace(go.Histogram(
                        x=chain_data['b_factor'],
                        nbinsx=30,
                        name=f'Chain {chain}',
                        opacity=0.6
                    ))
                
                fig_bf_dist.update_layout(
                    title="B-Factor Distribution Analysis",
                    xaxis_title="B-Factor (Ų)",
                    yaxis_title="Frequency",
                    barmode='overlay',
                    template="plotly_dark",
                    height=500
                )
                
                st.plotly_chart(fig_bf_dist, use_container_width=True)
            
            # Advanced B-factor analysis
            st.markdown("#### 🔬 Advanced Thermal Analysis")
            
            # Flexibility regions
            flexibility_analysis = b_factor_df.groupby(['chain', 'residue_num']).agg({
                'b_factor': ['mean', 'std', 'count']
            }).round(2)
            
            flexibility_analysis.columns = ['Mean B-Factor', 'Std B-Factor', 'Atom Count']
            flexibility_analysis = flexibility_analysis.reset_index()
            
            # Classify flexibility
            mean_bf = b_factor_df['b_factor'].mean()
            std_bf = b_factor_df['b_factor'].std()
            
            flexibility_analysis['Flexibility'] = flexibility_analysis['Mean B-Factor'].apply(
                lambda x: 'Highly Flexible' if x > mean_bf + std_bf 
                            else ('Flexible' if x > mean_bf 
                                else ('Rigid' if x < mean_bf - std_bf else 'Normal'))
            )
            
            st.dataframe(flexibility_analysis, use_container_width=True)
        else:
            st.warning("No B-factor data available in this PDB file")
        
        # CONTACT MAP ANALYSIS EXTREME
        st.markdown("### 🗺️ CONTACT MAP & DISTANCE ANALYSIS")
        
        # Calculate CA-CA distances for contact map
        ca_atoms = [atom for atom in atoms if atom['name'] == 'CA']
        
        if len(ca_atoms) > 1:
            with st.spinner("🔥 Calculating molecular contact universe..."):
                # Limit to manageable size for performance
                ca_sample = ca_atoms[:min(200, len(ca_atoms))]
                
                n_residues = len(ca_sample)
                distance_matrix = np.zeros((n_residues, n_residues))
                
                # Calculate all pairwise distances
                for i, atom1 in enumerate(ca_sample):
                    for j, atom2 in enumerate(ca_sample):
                        if i != j:
                            dist = np.sqrt(
                                (atom1['x'] - atom2['x'])**2 + 
                                (atom1['y'] - atom2['y'])**2 + 
                                (atom1['z'] - atom2['z'])**2
                            )
                            distance_matrix[i][j] = dist
                
                contact_cols = st.columns(2)
                
                with contact_cols[0]:
                    # Contact map with multiple distance thresholds
                    st.markdown("#### 🎯 Multi-Threshold Contact Map")
                    
                    distance_threshold = st.slider("Contact Distance Threshold (Å)", 4.0, 12.0, 8.0, 0.5)
                    
                    contact_map = distance_matrix < distance_threshold
                    contact_map = contact_map.astype(int)
                    
                    residue_nums = [atom['residue_num'] for atom in ca_sample]
                    
                    fig_contact = go.Figure(data=go.Heatmap(
                        z=contact_map,
                        x=residue_nums,
                        y=residue_nums,
                        colorscale=[[0, 'darkblue'], [1, 'red']],
                        hovertemplate='Residue %{x} ↔ Residue %{y}<br>Contact: %{z}<extra></extra>',
                        showscale=True
                    ))
                    
                    fig_contact.update_layout(
                        title=f"Contact Map (Distance < {distance_threshold}Å)",
                        xaxis_title="Residue Number",
                        yaxis_title="Residue Number",
                        width=500,
                        height=500,
                        template="plotly_dark"
                    )
                    st.plotly_chart(fig_contact, use_container_width=True)
                    
                    # Contact density analysis
                    contact_density = np.sum(contact_map, axis=1)
                    fig_density = px.bar(
                        x=residue_nums,
                        y=contact_density,
                        title="Contact Density per Residue",
                        labels={'x': 'Residue Number', 'y': 'Number of Contacts'}
                    )
                    fig_density.update_layout(template="plotly_dark")
                    st.plotly_chart(fig_density, use_container_width=True)
                
                with contact_cols[1]:
                    # Distance distribution with advanced analysis
                    st.markdown("#### 📊 Distance Distribution Universe")
                    
                    upper_triangle = distance_matrix[np.triu_indices_from(distance_matrix, k=1)]
                    
                    # Create comprehensive distance analysis
                    fig_dist = go.Figure()
                    
                    # Main distribution
                    fig_dist.add_trace(go.Histogram(
                        x=upper_triangle,
                        nbinsx=100,
                        name='All Distances',
                        opacity=0.7,
                        marker_color='lightblue'
                    ))
                    
                    # Add theoretical distributions for comparison
                    # Secondary structure typical distances
                    fig_dist.add_vline(x=3.8, line_dash="dash", line_color="red",
                                        annotation_text="α-helix CA-CA")
                    fig_dist.add_vline(x=4.9, line_dash="dash", line_color="green",
                                        annotation_text="β-sheet CA-CA")
                    fig_dist.add_vline(x=8.0, line_dash="dash", line_color="orange",
                                        annotation_text="Contact cutoff")
                    
                    fig_dist.update_layout(
                        title="CA-CA Distance Distribution",
                        xaxis_title="Distance (Å)",
                        yaxis_title="Count",
                        template="plotly_dark",
                        height=400
                    )
                    st.plotly_chart(fig_dist, use_container_width=True)
                    
                    # Distance statistics
                    st.markdown("##### 📈 Distance Statistics")
                    
                    dist_stats = {
                        'Mean Distance': f"{np.mean(upper_triangle):.2f} Å",
                        'Median Distance': f"{np.median(upper_triangle):.2f} Å",
                        'Min Distance': f"{np.min(upper_triangle):.2f} Å",
                        'Max Distance': f"{np.max(upper_triangle):.2f} Å",
                        'Std Deviation': f"{np.std(upper_triangle):.2f} Å"
                    }
                    
                    metric_cols = st.columns(2)
                    for i, (stat, value) in enumerate(dist_stats.items()):
                        with metric_cols[i % 2]:
                            st.metric(stat, value)
                    
                    # Local contact analysis
                    st.markdown("##### 🎯 Local Contact Analysis")
                    
                    # Calculate local contacts (nearby in sequence)
                    local_contacts = 0
                    long_range_contacts = 0
                    
                    for i in range(len(ca_sample)):
                        for j in range(i+1, len(ca_sample)):
                            if distance_matrix[i][j] < distance_threshold:
                                if abs(ca_sample[i]['residue_num'] - ca_sample[j]['residue_num']) < 5:
                                    local_contacts += 1
                                else:
                                    long_range_contacts += 1
                    
                    total_contacts = local_contacts + long_range_contacts
                    
                    if total_contacts > 0:
                        local_percent = (local_contacts / total_contacts) * 100
                        long_range_percent = (long_range_contacts / total_contacts) * 100
                        
                        st.metric("Local Contacts", f"{local_contacts} ({local_percent:.1f}%)")
                        st.metric("Long-range Contacts", f"{long_range_contacts} ({long_range_percent:.1f}%)")
        
        # RAMACHANDRAN PLOT EXTREME
        st.markdown("### 🔄 RAMACHANDRAN PLOT ANALYSIS")
        
        # For a real implementation, you'd calculate phi/psi angles from backbone atoms
        # Here we'll create a more sophisticated simulation
        
        rama_cols = st.columns(2)
        
        with rama_cols[0]:
            st.markdown("#### 🎯 Classic Ramachandran Plot")
            
            # Generate realistic phi/psi angles based on secondary structure
            n_residues = len(set([(atom['chain'], atom['residue_num']) for atom in atoms]))
            
            # Create realistic distributions
            phi_angles = []
            psi_angles = []
            ss_types = []
            
            for i in range(n_residues):
                # Randomly assign secondary structure with realistic probabilities
                rand = np.random.random()
                if rand < 0.4:  # α-helix
                    phi = np.random.normal(-60, 15)
                    psi = np.random.normal(-45, 15)
                    ss_type = 'α-helix'
                elif rand < 0.6:  # β-sheet
                    phi = np.random.normal(-120, 20)
                    psi = np.random.normal(120, 20)
                    ss_type = 'β-sheet'
                elif rand < 0.7:  # Left-handed helix (rare)
                    phi = np.random.normal(60, 15)
                    psi = np.random.normal(45, 15)
                    ss_type = 'Left-handed'
                else:  # Random coil
                    phi = np.random.uniform(-180, 180)
                    psi = np.random.uniform(-180, 180)
                    ss_type = 'Random coil'
                
                phi_angles.append(phi)
                psi_angles.append(psi)
                ss_types.append(ss_type)
            
            # Create Ramachandran plot
            fig_rama = go.Figure()
            
            # Add allowed regions as shapes
            allowed_regions = [
                # α-helix region
                dict(type="rect", x0=-120, y0=-60, x1=-40, y1=20,
                        fillcolor="rgba(0,128,255,0.2)", layer="below", line_width=0),
                # β-sheet region  
                dict(type="rect", x0=-180, y0=120, x1=-90, y1=180,
                        fillcolor="rgba(0,255,128,0.2)", layer="below", line_width=0),
                # Left-handed α-helix
                dict(type="rect", x0=40, y0=30, x1=100, y1=80,
                        fillcolor="rgba(255,128,0,0.2)", layer="below", line_width=0)
            ]
            
            for region in allowed_regions:
                fig_rama.add_shape(region)
            
            # Plot points colored by secondary structure
            ss_colors = {'α-helix': 'blue', 'β-sheet': 'green', 
                        'Left-handed': 'orange', 'Random coil': 'red'}
            
            for ss_type in set(ss_types):
                mask = [s == ss_type for s in ss_types]
                phi_subset = [phi for phi, m in zip(phi_angles, mask) if m]
                psi_subset = [psi for psi, m in zip(psi_angles, mask) if m]
                
                fig_rama.add_trace(go.Scatter(
                    x=phi_subset,
                    y=psi_subset,
                    mode='markers',
                    name=ss_type,
                    marker=dict(
                        color=ss_colors.get(ss_type, 'gray'),
                        size=8,
                        line=dict(width=1, color='white')
                    )
                ))
            
            fig_rama.update_layout(
                title="Ramachandran Plot (φ vs ψ angles)",
                xaxis_title="φ (phi) angle (°)",
                yaxis_title="ψ (psi) angle (°)",
                xaxis=dict(range=[-180, 180], dtick=60),
                yaxis=dict(range=[-180, 180], dtick=60),
                template="plotly_dark",
                height=500,
                width=500
            )
            
            st.plotly_chart(fig_rama, use_container_width=True)
            
            # Ramachandran statistics
            st.markdown("##### 📊 Conformational Statistics")
            
            rama_stats = pd.DataFrame({
                'Secondary Structure': list(set(ss_types)),
                'Count': [ss_types.count(ss) for ss in set(ss_types)],
                'Percentage': [ss_types.count(ss)/len(ss_types)*100 for ss in set(ss_types)]
            })
            rama_stats = rama_stats.sort_values('Count', ascending=False)
            st.dataframe(rama_stats, use_container_width=True)
        
        with rama_cols[1]:
            st.markdown("#### 🌈 Density Ramachandran Plot")
            
            # Create density plot
            from scipy.stats import gaussian_kde
            
            # Calculate 2D density
            phi_psi = np.vstack([phi_angles, psi_angles])
            kde = gaussian_kde(phi_psi)
            
            # Create grid for contour plot
            phi_grid = np.linspace(-180, 180, 50)
            psi_grid = np.linspace(-180, 180, 50)
            phi_mesh, psi_mesh = np.meshgrid(phi_grid, psi_grid)
            positions = np.vstack([phi_mesh.ravel(), psi_mesh.ravel()])
            
            # Calculate density
            density = kde(positions).reshape(phi_mesh.shape)
            
            fig_density = go.Figure(data=go.Contour(
                z=density,
                x=phi_grid,
                y=psi_grid,
                colorscale='Viridis',
                contours=dict(showlabels=True),
                hovertemplate='φ: %{x}°<br>ψ: %{y}°<br>Density: %{z}<extra></extra>'
            ))
            
            # Overlay scatter points
            fig_density.add_trace(go.Scatter(
                x=phi_angles,
                y=psi_angles,
                mode='markers',
                marker=dict(size=4, color='white', opacity=0.6),
                name='Residues',
                showlegend=False
            ))
            
            fig_density.update_layout(
                title="Ramachandran Density Plot",
                xaxis_title="φ (phi) angle (°)",
                yaxis_title="ψ (psi) angle (°)",
                template="plotly_dark",
                height=500
            )
            
            st.plotly_chart(fig_density, use_container_width=True)
        
        # 3D SCATTER PLOT EXTREME
        st.markdown("### 🌌 3D ATOMIC SCATTER UNIVERSE")
        
        # Advanced 3D visualization with multiple options
        scatter_cols = st.columns(2)
        
        with scatter_cols[0]:
            st.markdown("#### 🎯 Element-Colored Atomic Cloud")
            
            # Sample atoms for performance
            sample_size = min(2000, len(atoms))
            sampled_atoms = np.random.choice(atoms, sample_size, replace=False)
            
            x_coords = [atom['x'] for atom in sampled_atoms]
            y_coords = [atom['y'] for atom in sampled_atoms]
            z_coords = [atom['z'] for atom in sampled_atoms]
            elements = [atom['element'] for atom in sampled_atoms]
            chains = [atom['chain'] for atom in sampled_atoms]
            residues = [atom['residue'] for atom in sampled_atoms]
            
            # Create element-to-color mapping
            unique_elements = list(set(elements))
            element_colors = {}
            palette_func = globals()[st.session_state.selected_palette]
            
            for i, element in enumerate(unique_elements):
                color_rgb = palette_func(i)
                element_colors[element] = f"rgb({color_rgb[0]}, {color_rgb[1]}, {color_rgb[2]})"
            

            # Create main 3D scatter
            fig_3d = go.Figure()

            # Add points for each element type
            for element in unique_elements:
                element_mask = [e == element for e in elements]
                if any(element_mask):
                    element_x = [x for x, m in zip(x_coords, element_mask) if m]
                    element_y = [y for y, m in zip(y_coords, element_mask) if m]
                    element_z = [z for z, m in zip(z_coords, element_mask) if m]
                    element_chains = [c for c, m in zip(chains, element_mask) if m]
                    element_residues = [r for r, m in zip(residues, element_mask) if m]
                    
                    fig_3d.add_trace(go.Scatter3d(
                        x=element_x,
                        y=element_y,
                        z=element_z,
                        mode='markers',
                        name=element,
                        marker=dict(
                            size=4,
                            color=element_colors[element],
                            opacity=0.8,
                            line=dict(width=0.5, color='white')
                        ),
                        hovertemplate=(
                            '<b>%{text}</b><br>'
                            'Element: ' + element + '<br>'
                            'X: %{x:.2f} Å<br>'
                            'Y: %{y:.2f} Å<br>'
                            'Z: %{z:.2f} Å<br>'
                            '<extra></extra>'
                        ),
                        text=[f"Chain {c}, {r}" for c, r in zip(element_chains, element_residues)]
                    ))
            
            # Calculate and add center of mass
            coords = np.array([[atom['x'], atom['y'], atom['z']] for atom in sampled_atoms])
            center_of_mass = coords.mean(axis=0)

            fig_3d.add_trace(go.Scatter3d(
                x=[center_of_mass[0]],
                y=[center_of_mass[1]],
                z=[center_of_mass[2]],
                mode='markers',
                name='Center of Mass',
                marker=dict(
                    size=15,
                    color='red',
                    symbol='diamond'
                ),
                hovertemplate=(
                    'Center of Mass<br>'
                    'X: %{x:.2f} Å<br>'
                    'Y: %{y:.2f} Å<br>'
                    'Z: %{z:.2f} Å<br>'
                    '<extra></extra>'
                )
            ))

            # Final layout tweaks
            fig_3d.update_layout(
                title="3D Atomic Position Universe",
                scene=dict(
                    xaxis_title="X (Å)",
                    yaxis_title="Y (Å)",
                    zaxis_title="Z (Å)",
                    bgcolor="black",
                    camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
                ),
                height=600,
                showlegend=True,
                legend=dict(
                    orientation="v",
                    yanchor="top",
                    y=1,
                    xanchor="left",
                    x=1.02
                )
            )

            # Render with Streamlit
            st.plotly_chart(fig_3d, use_container_width=True)


        # 🕳️ BINDING POCKET IDENTIFICATION & ANALYSIS
        st.markdown("### 🕳️ BINDING POCKET IDENTIFICATION & ANALYSIS")

        pocket_cols = st.columns(2)

        with pocket_cols[0]:
            st.markdown("#### 🎯 Identified Binding Pockets")
            
            # Simulate pocket identification results
            pockets_data = [
                {"pocket_id": "P1", "volume": 856.3, "hydrophobicity": 0.65, "druggability": 0.92, "type": "Active Site"},
                {"pocket_id": "P2", "volume": 432.7, "hydrophobicity": 0.45, "druggability": 0.78, "type": "Allosteric"},
                {"pocket_id": "P3", "volume": 298.1, "hydrophobicity": 0.72, "druggability": 0.84, "type": "Allosteric"},
                {"pocket_id": "P4", "volume": 156.9, "hydrophobicity": 0.38, "druggability": 0.56, "type": "Cryptic"},
                {"pocket_id": "P5", "volume": 623.4, "hydrophobicity": 0.59, "druggability": 0.71, "type": "Interface"}
            ]
            pockets_df = pd.DataFrame(pockets_data)
            
            # Pocket analysis scatter plot
            fig_pockets = px.scatter(
                pockets_df,
                x='volume',
                y='druggability',
                size='hydrophobicity',
                color='type',
                text='pocket_id',
                title="Binding Pocket Druggability Analysis"
            )
            fig_pockets.update_traces(textposition='top center')
            fig_pockets.update_layout(
                xaxis_title="Pocket Volume (Å³)",
                yaxis_title="Druggability Score",
                height=400
            )
            st.plotly_chart(fig_pockets, use_container_width=True)

        with pocket_cols[1]:
            st.markdown("#### 🗺️ Pocket Properties Heatmap")
            
            # Create properties heatmap
            pocket_properties = pockets_df.set_index('pocket_id')[['volume', 'hydrophobicity', 'druggability']]
            from sklearn.preprocessing import MinMaxScaler
            scaler = MinMaxScaler()
            normalized_props = scaler.fit_transform(pocket_properties.T).T
            
            fig_heatmap = go.Figure(data=go.Heatmap(
                z=normalized_props,
                x=pocket_properties.columns,
                y=pocket_properties.index,
                colorscale='Viridis',
                text=pocket_properties.values,
                texttemplate="%{text:.2f}",
                hovertemplate='Pocket: %{y}<br>Property: %{x}<br>Value: %{text}<extra></extra>'
            ))
            fig_heatmap.update_layout(
                title="Pocket Properties Heatmap",
                height=400
            )
            st.plotly_chart(fig_heatmap, use_container_width=True)
