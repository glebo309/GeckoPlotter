import streamlit as st
import plotly.graph_objects as go
import numpy as np
from plotly.subplots import make_subplots

def create_journal_style_plot(plot_type="chromatogram"):
    """Create scientific plot with proper journal styling based on type"""
    
    if plot_type == "chromatogram":
        # Generate chromatogram-like data
        x = np.linspace(0, 10, 500)
        
        def gaussian_peak(x, amplitude, center, width):
            return amplitude * np.exp(-((x - center) ** 2) / (2 * width ** 2))
        
        # Sample 1 - early eluting peak
        y1 = gaussian_peak(x, 2.0, 3.0, 0.5) + 0.1 * np.random.randn(len(x))
        
        # Sample 2 - middle peak
        y2 = gaussian_peak(x, 1.6, 5.5, 0.4) + 0.1 * np.random.randn(len(x))
        
        # Sample 3 - late peak
        y3 = gaussian_peak(x, 1.2, 8.0, 0.3) + 0.1 * np.random.randn(len(x))
        
        # Create stacked subplots like in your second image
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True)
        
        # Add traces for each sample in separate subplots
        fig.add_trace(
            go.Scatter(
                x=x, y=y1,
                mode='lines',
                name='Sample 1',
                line=dict(color='blue', width=1.5)
            ),
            row=1, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=x, y=y2,
                mode='lines',
                name='Sample 2',
                line=dict(color='red', width=1.5)
            ),
            row=2, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=x, y=y3,
                mode='lines',
                name='Sample 3',
                line=dict(color='green', width=1.5)
            ),
            row=3, col=1
        )
        
        # Update layout
        fig.update_layout(
            height=600,
            font=dict(family="Arial", size=14, color="black"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            margin=dict(l=60, r=20, t=40, b=60),
            showlegend=True
        )
        
        # Format all axes to journal standards - this is the key part
        # Only show x-axis title on bottom plot
        fig.update_xaxes(
            title_text=None,
            row=1, col=1,
            showline=True,
            linewidth=1.5,
            linecolor='black',
            mirror=True,
            ticks="outside",
            tickwidth=1.5,
            tickcolor='black',
            ticklen=6,
            showgrid=False
        )
        
        fig.update_xaxes(
            title_text=None,
            row=2, col=1,
            showline=True,
            linewidth=1.5,
            linecolor='black',
            mirror=True,
            ticks="outside",
            tickwidth=1.5,
            tickcolor='black',
            ticklen=6,
            showgrid=False
        )
        
        fig.update_xaxes(
            title_text='Retention Time (min)',
            row=3, col=1,
            showline=True,
            linewidth=1.5,
            linecolor='black',
            mirror=True,
            ticks="outside",
            tickwidth=1.5,
            tickcolor='black',
            ticklen=6,
            showgrid=False
        )
        
        # Update all y-axes
        for i in range(1, 4):
            fig.update_yaxes(
                title_text='Signal (a.u.)' if i == 2 else None,  # Only middle plot has y-axis title
                row=i, col=1,
                showline=True,
                linewidth=1.5,
                linecolor='black',
                mirror=True,
                ticks="outside",
                tickwidth=1.5,
                tickcolor='black',
                ticklen=6,
                showgrid=False
            )
        
    elif plot_type == "oscillation":
        # Create oscillation data similar to your first image
        time = np.linspace(0, 300, 500)
        
        # Three different oscillation signals
        y1 = 1.1 + 0.04 * np.sin(2 * np.pi * time / 80) + 0.005 * np.random.randn(len(time))
        y2 = 1.0 + 0.05 * np.sin(2 * np.pi * time / 30) + 0.005 * np.random.randn(len(time))
        y3 = 0.95 + 0.03 * np.sin(2 * np.pi * time / 20) + 0.005 * np.random.randn(len(time))
        
        # Create figure
        fig = go.Figure()
        
        # Add traces
        fig.add_trace(go.Scatter(
            x=time, y=y1,
            mode='markers+lines',
            name='(HK0)',
            line=dict(color='black', width=1.5),
            marker=dict(color='black', size=5, symbol='circle')
        ))
        
        fig.add_trace(go.Scatter(
            x=time, y=y2,
            mode='markers+lines',
            name='(H0L)',
            line=dict(color='red', width=1.5),
            marker=dict(color='red', size=5, symbol='circle')
        ))
        
        fig.add_trace(go.Scatter(
            x=time, y=y3,
            mode='markers+lines',
            name='(HKL)',
            line=dict(color='blue', width=1.5),
            marker=dict(color='blue', size=5, symbol='circle')
        ))
        
        # Update layout for scientific publication
        fig.update_layout(
            font=dict(family="Arial", size=14, color="black"),
            plot_bgcolor="white",
            paper_bgcolor="white",
            margin=dict(l=60, r=20, t=20, b=60),
            legend=dict(
                x=0.02,
                y=0.98,
                bgcolor="white",
                bordercolor="black",
                borderwidth=1
            )
        )
        
        # Update axes to journal style
        fig.update_xaxes(
            title_text='Time Delay (ps)',
            showline=True,
            linewidth=1.5,
            linecolor='black',
            mirror=True,
            ticks="outside",
            tickwidth=1.5,
            tickcolor='black',
            ticklen=6,
            showgrid=False
        )
        
        fig.update_yaxes(
            title_text='I/I₀',
            showline=True,
            linewidth=1.5,
            linecolor='black',
            mirror=True,
            ticks="outside",
            tickwidth=1.5,
            tickcolor='black',
            ticklen=6,
            showgrid=False
        )
    
    return fig

def main():
    st.title("Scientific Journal-Style Plots")
    
    st.write("""
    This application demonstrates how to create proper scientific plots following 
    journal publication standards. Notice how each plot has its own box formed by the 
    axes themselves, with ticks extending outward.
    """)
    
    plot_type = st.radio(
        "Select Plot Type",
        ["Chromatogram", "Oscillation"]
    )
    
    if plot_type == "Chromatogram":
        fig = create_journal_style_plot("chromatogram")
    else:
        fig = create_journal_style_plot("oscillation")
        
    st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("### Key Features of Journal-Standard Plots")
    st.write("""
    1. **Box formed by the axes themselves** - using `mirror=True`
    2. **Ticks extending outward** - using `ticks="outside"` and `ticklen=6`
    3. **No grid lines** - using `showgrid=False`
    4. **Clean white background** - professional appearance
    5. **Properly sized fonts** - typically 8-12pt in final publication 
    """)
    
    with st.expander("Show implementation code"):
        st.code("""
# The key parameters for journal-style plots:
fig.update_xaxes(
    showline=True,
    linewidth=1.5,
    linecolor='black',
    mirror=True,  # Creates the box effect
    ticks="outside",
    tickwidth=1.5,
    tickcolor='black',
    ticklen=6,
    showgrid=False
)

fig.update_yaxes(
    showline=True,
    linewidth=1.5,
    linecolor='black',
    mirror=True,  # Creates the box effect
    ticks="outside",
    tickwidth=1.5,
    tickcolor='black',
    ticklen=6,
    showgrid=False
)
        """)

if __name__ == "__main__":
    main()