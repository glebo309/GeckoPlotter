import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import io

st.set_page_config(page_title="Smart Axis Controls Demo", layout="wide")

def parse_chromatography_file(file_content):
    """Parse chromatography data file and extract time/value data."""
    lines = file_content.strip().split('\n')
    
    # Find where the raw data starts
    data_start_idx = None
    for i, line in enumerate(lines):
        if line.strip() == "Raw Data:":
            data_start_idx = i + 2  # Skip header line
            break
    
    if data_start_idx is None:
        st.error("Could not find 'Raw Data:' section in file")
        return None, None
    
    # Parse the data
    times = []
    values = []
    
    for line in lines[data_start_idx:]:
        line = line.strip()
        if not line:
            continue
            
        parts = line.split('\t')
        if len(parts) >= 3:
            try:
                # Replace comma with dot for decimal separator
                time_str = parts[0].replace(',', '.')
                value_str = parts[2].replace(',', '.')
                
                time = float(time_str)
                value = float(value_str)
                
                times.append(time)
                values.append(value)
            except ValueError:
                continue
    
    return times, values

def main():
    st.title("Smart Axis Controls Demo - Chromatography Data")
    
    # File upload section
    uploaded_file = st.file_uploader("Upload chromatography data file", type=['txt', 'csv'])
    
    # Initialize session state for zoom persistence
    zoom_key = "saved_layout_main_chromatogram_plot"
    if zoom_key not in st.session_state:
        st.session_state[zoom_key] = {}
    if "zoom_count" not in st.session_state:
        st.session_state.zoom_count = 0
    
    # Default data (if no file uploaded)
    x_data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    y_data = [15, -23, 45, -12, 67, -89, 34, -56, 78, -91]
    data_label = "Default Test Data"
    
    # Process uploaded file if available
    if uploaded_file is not None:
        try:
            # Read file content
            file_content = uploaded_file.read().decode('utf-8')
            
            # Parse the chromatography data
            times, values = parse_chromatography_file(file_content)
            
            if times and values:
                x_data = times
                y_data = values
                data_label = f"Chromatography Data ({uploaded_file.name})"
                
                # Set initial zoom range based on the data
                if "saved_layout" not in st.session_state:
                    x_min, x_max = min(x_data), max(x_data)
                    padding = (x_max - x_min) * 0.05  # 5% padding
                    initial_range = [x_min - padding, x_max + padding]
                    st.session_state.saved_layout = {'xaxis.range': initial_range}
                    st.write(f"🏁 **Setting initial zoom range:** {initial_range}")
                
                # Display data info
                st.success(f"✅ Loaded {len(x_data)} data points from {uploaded_file.name}")
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Data Points", len(x_data))
                with col2:
                    st.metric("Time Range", f"{min(x_data):.3f} - {max(x_data):.3f} min")
                with col3:
                    st.metric("Signal Range", f"{min(y_data):.1f} - {max(y_data):.1f} mAU")
                with col4:
                    st.metric("Peak Signal", f"{max(y_data):.1f} mAU")
            else:
                st.error("Could not parse data from the uploaded file")
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")
    else:
        # Set initial zoom for default data
        if "saved_layout" not in st.session_state:
            x_min, x_max = min(x_data), max(x_data)
            padding = (x_max - x_min) * 0.1
            initial_range = [x_min - padding, x_max + padding]
            st.session_state.saved_layout = {'xaxis.range': initial_range}
            st.write(f"🏁 **Setting initial zoom range:** {initial_range}")
    
    # Sidebar controls
    with st.sidebar:
        st.header("Plot Controls")
        line_thickness = st.slider("Line Thickness", 0.5, 3.0, 1.5, 0.1)
        line_color = st.selectbox("Color", ["blue", "red", "green", "purple", "orange", "brown"])
        
        # Show markers toggle
        show_markers = st.checkbox("Show Markers", value=False)
        
        if st.button("Reset Zoom"):
            x_min, x_max = min(x_data), max(x_data)
            padding = (x_max - x_min) * 0.05
            initial_range = [x_min - padding, x_max + padding]
            st.session_state.saved_layout = {'xaxis.range': initial_range}
            st.rerun()
            
        if st.button("Test Rerun"):
            st.rerun()
            
        # Debug info
        if st.checkbox("Show Debug", value=True):
            st.write("**Current saved_layout:**", st.session_state.saved_layout)
            st.write("**What will be applied to plot:**")
            if 'xaxis.range' in st.session_state.saved_layout:
                st.write(f"  - X range: {st.session_state.saved_layout['xaxis.range']}")
            else:
                st.write("  - X range: None (using default)")
            if 'yaxis.range' in st.session_state.saved_layout:
                st.write(f"  - Y range: {st.session_state.saved_layout['yaxis.range']}")
            else:
                st.write("  - Y range: None (using default)")
    
    # Create plot
    fig = go.Figure()
    
    # Determine mode for scatter plot
    mode = 'lines+markers' if show_markers else 'lines'
    
    fig.add_trace(go.Scatter(
        x=x_data,
        y=y_data,
        mode=mode,
        name=data_label,
        line=dict(color=line_color, width=line_thickness),
        marker=dict(size=3) if show_markers else None
    ))
    
    # Set appropriate axis labels
    x_label = "Time (min)" if uploaded_file else "X"
    y_label = "Absorbance (mAU)" if uploaded_file else "Y"
    
    fig.update_layout(
        title="Zoom with mouse, then change controls - zoom should persist",
        xaxis_title=x_label,
        yaxis_title=y_label,
        height=600
    )
    
    # Apply saved zoom if we have it
    if st.session_state.saved_layout and 'xaxis.range' in st.session_state.saved_layout:
        zoom_range = st.session_state.saved_layout['xaxis.range']
        fig.update_xaxes(range=zoom_range)
        st.write(f"**🔧 APPLYING saved X zoom:** {zoom_range}")
    else:
        st.write("**🔧 No saved zoom to apply - using default**")
    
    # Apply saved Y zoom if we have it
    if st.session_state.saved_layout and 'yaxis.range' in st.session_state.saved_layout:
        y_zoom_range = st.session_state.saved_layout['yaxis.range']
        fig.update_yaxes(range=y_zoom_range)
        st.write(f"**🔧 APPLYING saved Y zoom:** {y_zoom_range}")
    
    # Try to use the zoom-preserving component
    try:
        from streamlit_advanced_plotly_chart import preserveZoomPlotlyChart
        
        # Call the component with event capture
        result = preserveZoomPlotlyChart(fig, event='relayout')
        
        # ALWAYS show what was captured
        st.write("**🔍 DEBUG - Raw result from component:**", result)
        
        # Save any zoom changes to session state
        if result and 'selected_range' in result:
            # The component returns selected_range as [xmin, xmax]
            zoom_range = result['selected_range']
            if len(zoom_range) == 2:
                # Only store if it's different from current
                current_range = st.session_state.saved_layout.get('xaxis.range')
                if current_range != zoom_range:
                    st.session_state.saved_layout['xaxis.range'] = zoom_range
                    st.session_state.zoom_count += 1
                    st.write(f"✅ **STORING X zoom #{st.session_state.zoom_count}:** {zoom_range}")
        
        # Handle Y-axis zoom if available
        if result and 'selected_y_range' in result:
            y_zoom_range = result['selected_y_range']
            if len(y_zoom_range) == 2:
                current_y_range = st.session_state.saved_layout.get('yaxis.range')
                if current_y_range != y_zoom_range:
                    st.session_state.saved_layout['yaxis.range'] = y_zoom_range
                    st.write(f"✅ **STORING Y zoom:** {y_zoom_range}")
        
        # Show what's actually stored
        st.write("**📦 What's now in session state:**", st.session_state.saved_layout)
        
        st.success("🎯 Zoom capturing active - try zooming then changing the controls!")
        
    except ImportError:
        st.error("❌ Component not installed: pip install streamlit-advanced-plotly-chart")
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"❌ Error with component: {e}")
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()