# utils/generate_test_data.py

import numpy as np
import pandas as pd
import os
import random
import copy

def gaussian_peak(x, amplitude, center, width):
    """Generate a Gaussian peak"""
    return amplitude * np.exp(-((x - center) ** 2) / (2 * width ** 2))

def generate_chromatogram_data(filename, peaks, noise_level=0.5, baseline_drift=0):
    """
    Generate a synthetic chromatogram with multiple Gaussian peaks.
    
    Parameters:
    -----------
    filename : str
        Output filename
    peaks : list of dict
        List of peak parameters (amplitude, center, width)
    noise_level : float
        Level of random noise to add
    baseline_drift : float
        Linear baseline drift factor
    """
    # Create time axis from 0 to 10 minutes with 0.0033 min steps (like your example)
    time = np.arange(0, 10, 0.0033333)
    
    # Initialize signal with zero values
    signal = np.zeros_like(time)
    
    # Add each peak
    for peak in peaks:
        signal += gaussian_peak(
            time, 
            amplitude=peak['amplitude'],
            center=peak['center'],
            width=peak['width']
        )
    
    # Add noise
    if noise_level > 0:
        signal += np.random.normal(0, noise_level, size=time.shape)
    
    # Add baseline drift
    if baseline_drift != 0:
        signal += baseline_drift * time
    
    # Create step values (constant for all points)
    steps = np.full_like(time, 0.2)
    
    # Create data dictionary for the header
    max_signal = np.max(signal)
    min_signal = np.min(signal)
    
    # Generate the header
    header = f"""File Path\tchrom://pc/ChromeleonLocal2023/Glenn/export test.seq/{random.randint(400, 500)}.smp/UV_VIS_1.channel/UV_VIS_1.chm
Channel\tUV_VIS_1
Injection Information:
Data Vault\tChromeleonLocal2023
Injection\t{filename}
Injection Number\t{random.randint(1, 10)}
Position\tRB{random.randint(1, 24)}
Comment\t
Processing Method\tStandard
Instrument Method\t5-95 4 min TFA
Type\tUnknown
Status\tFinished
Injection Date\t{random.randint(10, 30)}.07.2024
Injection Time\t{random.randint(10, 23)}:{random.randint(10, 59)}:{random.randint(10, 59)}
Injection Volume (µl)\t2,000
Dilution Factor\t1,0000
Weight\t1,0000
Raw Data Information:
Time Min. (min)\t0,000000
Time Max. (min)\t10,000000
Data Points\t{len(time)}
Detector\tUV
Exporting Data System\tChromeleon 7.1.3.2425
Operator\t
Signal Quantity\tAbsorbance
Signal Unit\tmAU
Signal Min.\t{min_signal:.6f}
Signal Max.\t{max_signal:.6f}
Channel\tUV_VIS_1
Driver Name\tDAD3000.dll
Channel Type\tEvaluation
Min. Step (s)\t0,200
Max. Step (s)\t0,200
Average Step (s)\t0,200
Signal Parameter Information:
Signal Info\tWVL:210 nm
Raw Data:
Time (min)\tStep (s)\tValue (mAU)"""
    
    # Create data rows
    rows = []
    for t, s, v in zip(time, steps, signal):
        rows.append(f"{t:.6f}\t{s:.3f}\t{v:.6f}")
    
    # Combine header and data
    full_text = header + "\n" + "\n".join(rows)
    
    # Write to file
    with open(filename, 'w') as f:
        f.write(full_text)
    
    return filename

def generate_test_datasets():
    """Generate a set of test chromatograms with highly varied peaks"""
    # Define base peaks that will appear in all samples with variations
    base_peaks = [
        {'amplitude': 700, 'center': 6.4, 'width': 0.05},  # Peak 1
        {'amplitude': 400, 'center': 7.1, 'width': 0.04},  # Peak 2
        {'amplitude': 400, 'center': 7.4, 'width': 0.04},  # Peak 3
        {'amplitude': 50, 'center': 7.8, 'width': 0.06}    # Peak 4
    ]
    
    # Generate datasets with extreme variations
    datasets = []
    
    # Sample 1: Standard with all peaks
    peaks1 = copy.deepcopy(base_peaks)
    datasets.append(generate_chromatogram_data(
        "test_sample_1.txt", 
        peaks1, 
        noise_level=1.0
    ))
    
    # Sample 2: Dramatic concentration differences (10× for first peak, 0.1× for third)
    peaks2 = [
        {'amplitude': 7000, 'center': 6.39, 'width': 0.055},  # Peak 1 (10× higher!)
        {'amplitude': 350, 'center': 7.12, 'width': 0.042},   # Peak 2 (slightly lower)
        {'amplitude': 40, 'center': 7.38, 'width': 0.038},    # Peak 3 (10× lower!)
        {'amplitude': 60, 'center': 7.82, 'width': 0.062}     # Peak 4 (slightly higher)
    ]
    datasets.append(generate_chromatogram_data(
        "test_sample_2.txt", 
        peaks2, 
        noise_level=2.0,
        baseline_drift=0.5  # Add some baseline drift
    ))
    
    # Sample 3: Significant RT shifts approaching the window limit
    peaks3 = [
        {'amplitude': 650, 'center': 6.28, 'width': 0.053},  # Peak 1 (shifted -0.12 min)
        {'amplitude': 420, 'center': 7.25, 'width': 0.045},  # Peak 2 (shifted +0.15 min)
        {'amplitude': 380, 'center': 7.56, 'width': 0.049},  # Peak 3 (shifted +0.16 min)
        {'amplitude': 45, 'center': 7.95, 'width': 0.058},   # Peak 4 (shifted +0.15 min)
        {'amplitude': 150, 'center': 8.2, 'width': 0.07}     # Extra peak only in this sample
    ]
    datasets.append(generate_chromatogram_data(
        "test_sample_3.txt", 
        peaks3, 
        noise_level=1.5
    ))
    
    # Sample 4: Extreme concentration variations with some RT shifts
    peaks4 = [
        {'amplitude': 5000, 'center': 6.45, 'width': 0.052},  # Peak 1 (7× higher)
        {'amplitude': 20, 'center': 7.08, 'width': 0.039},    # Peak 2 (20× lower!)
        {'amplitude': 3000, 'center': 7.42, 'width': 0.044},  # Peak 3 (7.5× higher)
        {'amplitude': 10, 'center': 7.79, 'width': 0.058}     # Peak 4 (5× lower)
    ]
    datasets.append(generate_chromatogram_data(
        "test_sample_4.txt", 
        peaks4, 
        noise_level=3.0  # Higher noise to challenge detection
    ))
    
    # Sample 5: Missing peaks, one very large peak, significant baseline
    peaks5 = [
        {'amplitude': 10000, 'center': 6.36, 'width': 0.054},  # Peak 1 (14× higher!)
        # Peak 2 is missing entirely
        {'amplitude': 200, 'center': 7.44, 'width': 0.041},    # Peak 3 (half height)
        # Peak 4 is missing entirely
        {'amplitude': 300, 'center': 5.6, 'width': 0.06},      # New peak before others
        {'amplitude': 180, 'center': 8.4, 'width': 0.07}       # New peak after others
    ]
    datasets.append(generate_chromatogram_data(
        "test_sample_5.txt", 
        peaks5, 
        noise_level=2.0,
        baseline_drift=2.0  # Strong baseline drift
    ))
    
    # Sample 6: Edge case with peaks just outside the matching window
    peaks6 = [
        {'amplitude': 800, 'center': 6.61, 'width': 0.05},   # Peak 1 (shifted +0.21 min - just outside window)
        {'amplitude': 450, 'center': 6.89, 'width': 0.04},   # Peak 2 (shifted -0.21 min - just outside window)
        {'amplitude': 380, 'center': 7.4, 'width': 0.04},    # Peak 3 (unchanged)
        {'amplitude': 75, 'center': 7.8, 'width': 0.06}      # Peak 4 (unchanged)
    ]
    datasets.append(generate_chromatogram_data(
        "test_sample_6.txt", 
        peaks6, 
        noise_level=1.0
    ))
    
    return datasets

# Generate the test datasets when this script is run directly
if __name__ == "__main__":
    test_files = generate_test_datasets()
    print(f"Generated {len(test_files)} test chromatogram files:")
    for filename in test_files:
        print(f"  - {filename}")