# legend_drag_test.py
import streamlit as st
import plotly.graph_objects as go
import time

# Initialize session state
if 'plot_config' not in st.session_state:
    st.session_state.plot_config = {'legend_position': {'x': 0.99, 'y': 0.9}}

if 'counter' not in st.session_state:
    st.session_state.counter = 0

# Title
st.title("Legend Drag Persistence Test")

# Show current run count to verify app is rerunning
st.session_state.counter += 1
st.write(f"App has run {st.session_state.counter} times in this session")

# Display current saved legend position
st.write(f"Current saved legend position: x={st.session_state.plot_config['legend_position']['x']:.2f}, y={st.session_state.plot_config['legend_position']['y']:.2f}")

# Create a simple figure with a draggable legend
def create_test_figure():
    fig = go.Figure()
    
    # Add two traces
    fig.add_trace(go.Scatter(
        x=[1, 2, 3, 4, 5],
        y=[1, 3, 2, 4, 3],
        name="Line 1"
    ))
    
    fig.add_trace(go.Scatter(
        x=[1, 2, 3, 4, 5],
        y=[5, 3, 5, 2, 4],
        name="Line 2"
    ))
    
    # Get saved legend position
    legend_pos = st.session_state.plot_config.get('legend_position', {'x': 0.99, 'y': 0.9})
    
    # Apply saved legend position
    fig.update_layout(
        title="Drag the Legend & Test Persistence",
        legend=dict(
            orientation="v",
            y=legend_pos['y'],
            x=legend_pos['x'],
            xanchor="right",
            yanchor="middle",
            bgcolor="rgba(255, 255, 255, 0.9)",
            bordercolor="black",
            borderwidth=2,
        ),
        # Important: Make legend draggable
        dragmode="pan"
    )
    
    return fig

# Generate the figure
fig = create_test_figure()

# FORCE RERUN button
if st.button("🔄 FORCE RERUN (Simulates App Restart)"):
    # Add timestamp to make it obvious the app reran
    st.success(f"App rerunning at {time.strftime('%H:%M:%S')}")
    time.sleep(0.5)  # Short delay to show the message
    st.rerun()

# Display the figure with a properly draggable legend
st.plotly_chart(
    fig, 
    use_container_width=True,
    config={
        'displayModeBar': True,
        'responsive': True,
        # These configs help make the legend draggable
        'editable': True,
        'showLegend': True,
        'edits': {
            'legendPosition': True,
            'legendText': True
        }
    }
)

# Capture Events (Warning - this likely won't work in Streamlit)
try:
    if 'plotly_events' in st.session_state and st.session_state.plotly_events:
        st.write("Detected events:", st.session_state.plotly_events)
        
        if 'relayoutData' in st.session_state.plotly_events:
            relayout = st.session_state.plotly_events['relayoutData']
            if 'legend.x' in relayout and 'legend.y' in relayout:
                st.write("Legend moved to:", relayout)
                st.session_state.plot_config['legend_position'] = {
                    'x': relayout['legend.x'],
                    'y': relayout['legend.y']
                }
except Exception as e:
    st.error(f"Error capturing events: {e}")

# Add a note about Streamlit limitations
st.markdown("""
### Instructions:
1. Try to drag the legend to a new position
2. Click the "FORCE RERUN" button to simulate closing/reopening the app
3. Check if the legend position:
   - Stays where you dragged it (persistence works!)
   - Resets to its default position (persistence fails)

**Important Note:** Plotly's interactive features like legend dragging may not persist in Streamlit due to its execution model. If this test shows that dragged positions do not persist, you'll need to use the manual control approach with sliders instead.
""")

# For debugging - watch session state
with st.expander("Debug: Session State"):
    st.write(st.session_state)