import os
import py3Dmol

# === CONFIG ===
pdb_file = "/Users/glenn/Documents/SecondBrain/_CODE/geckoplotter_web/pdb/7u6i.pdb"
output_html = "/Users/glenn/Documents/SecondBrain/_CODE/quartz-builder/public/Paradisi/EnzymeLibrary/7u6i_viewer.html"
target_md = "/Users/glenn/Documents/SecondBrain/_PROTOTYPE/Paradisi/EnzymeLibrary/pdb.md"

# === LOAD PDB ===
with open(pdb_file, "r") as f:
    pdb_data = f.read()

# === CREATE VIEWER ===
view = py3Dmol.view(width=800, height=500)
view.addModel(pdb_data, 'pdb')
view.setStyle({'cartoon': {'color': 'spectrum'}})
view.zoomTo()
view.setSpin(True)
view.setSpinSpeed(0.3)

# === WRITE HTML VIEWER ===
with open(output_html, "w") as f:
    f.write(view._make_html())

print(f"✅ Viewer written to: {output_html}")

# === ADD TO MARKDOWN ===
viewer_name = os.path.basename(output_html)
iframe_code = f"""<iframe src="/Paradisi/EnzymeLibrary/{viewer_name}" width="100%" height="500" frameborder="0"></iframe>"""

# Inject into .md
with open(target_md, "a") as f:
    f.write(f"\n\n### 🧬 7u6i Structure Viewer\n\n{iframe_code}\n")

print(f"✅ iframe added to: {target_md}")
